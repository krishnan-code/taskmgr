import { ReactNode, InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes, forwardRef } from 'react'
import { X } from 'lucide-react'
import clsx from 'clsx'

// ── Button ─────────────────────────────────────────────────────────────────
interface BtnProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost'
  size?: 'sm' | 'md'
  loading?: boolean
  children: ReactNode
}

export function Button({ variant = 'primary', size = 'md', loading, children, className, disabled, ...props }: BtnProps) {
  const base = 'inline-flex items-center gap-2 font-semibold transition-all duration-150 cursor-pointer rounded-lg border-0'
  const sizes = { sm: 'px-3 py-1.5 text-xs', md: 'px-4 py-2 text-sm' }
  const variants = {
    primary: 'bg-accent text-white hover:bg-purple-700 hover:-translate-y-px disabled:opacity-50',
    secondary: 'bg-surface2 text-muted border border-border hover:text-white hover:border-white',
    danger: 'bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20',
    ghost: 'bg-transparent text-muted hover:text-white hover:bg-surface2',
  }
  return (
    <button className={clsx(base, sizes[size], variants[variant], className)} disabled={disabled || loading} {...props}>
      {loading && <Spinner size="sm" />}
      {children}
    </button>
  )
}

// ── Input ──────────────────────────────────────────────────────────────────
interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className, ...props }, ref) => (
    <div className="w-full">
      {label && <label className="label">{label}</label>}
      <input
        ref={ref}
        className={clsx('input', error && 'border-red-500', className)}
        {...props}
      />
      {error && <p className="mt-1 text-xs text-red-400 font-mono">{error}</p>}
    </div>
  )
)
Input.displayName = 'Input'

// ── Select ─────────────────────────────────────────────────────────────────
interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string
  error?: string
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, error, children, className, ...props }, ref) => (
    <div className="w-full">
      {label && <label className="label">{label}</label>}
      <select ref={ref} className={clsx('input', error && 'border-red-500', className)} {...props}>
        {children}
      </select>
      {error && <p className="mt-1 text-xs text-red-400 font-mono">{error}</p>}
    </div>
  )
)
Select.displayName = 'Select'

// ── Textarea ───────────────────────────────────────────────────────────────
interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  error?: string
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, className, ...props }, ref) => (
    <div className="w-full">
      {label && <label className="label">{label}</label>}
      <textarea ref={ref} className={clsx('input min-h-[80px] resize-y', error && 'border-red-500', className)} {...props} />
      {error && <p className="mt-1 text-xs text-red-400 font-mono">{error}</p>}
    </div>
  )
)
Textarea.displayName = 'Textarea'

// ── Badge ──────────────────────────────────────────────────────────────────
export function StatusBadge({ status }: { status: string }) {
  const labels: Record<string, string> = { not_started: 'Not Started', in_progress: 'In Progress', done: 'Done', blocked: 'Blocked' }
  return <span className={`badge-${status}`}>{labels[status] ?? status}</span>
}

export function PriorityBadge({ priority }: { priority: string }) {
  return <span className={`badge-${priority}`}>{priority.charAt(0).toUpperCase() + priority.slice(1)}</span>
}

// ── Spinner ────────────────────────────────────────────────────────────────
export function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'w-3 h-3', md: 'w-5 h-5', lg: 'w-8 h-8' }
  return (
    <div className={clsx('border-2 border-muted border-t-accent rounded-full animate-spin', sizes[size])} />
  )
}

// ── Modal ──────────────────────────────────────────────────────────────────
interface ModalProps {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  size?: 'sm' | 'md' | 'lg'
}

export function Modal({ open, onClose, title, children, size = 'md' }: ModalProps) {
  if (!open) return null
  const widths = { sm: 'max-w-md', md: 'max-w-xl', lg: 'max-w-3xl' }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div
        className={clsx('bg-surface border border-border rounded-2xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto', widths[size])}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-extrabold">{title}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted hover:text-white hover:bg-surface2 transition-colors">
            <X size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

// ── Empty State ────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, description }: { icon: string; title: string; description?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="text-5xl mb-4">{icon}</div>
      <p className="font-bold text-lg mb-1">{title}</p>
      {description && <p className="text-muted text-sm font-mono">{description}</p>}
    </div>
  )
}

// ── Progress Bar ───────────────────────────────────────────────────────────
export function ProgressBar({ value, max }: { value: number; max: number }) {
  const pct = max === 0 ? 0 : Math.round((value / max) * 100)
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-surface2 rounded-full h-1.5 overflow-hidden">
        <div className="h-full rounded-full bg-gradient-to-r from-accent to-accent2 transition-all duration-300" style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-mono text-muted w-8 text-right">{pct}%</span>
    </div>
  )
}

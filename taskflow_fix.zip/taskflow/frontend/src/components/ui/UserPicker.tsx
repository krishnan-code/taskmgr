import { useState, useRef, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Search, X, UserCircle } from 'lucide-react'
import { usersApi } from '../../api/services'

interface UserMini {
  id: string; name: string; email: string
  role: string; job_title?: string; profile_photo_url?: string
}

interface Props {
  value?: UserMini | null
  onChange: (user: UserMini | null) => void
  label?: string
  placeholder?: string
  excludeIds?: string[]
  disabled?: boolean
}

export function UserPicker({ value, onChange, label, placeholder = 'Search users...', excludeIds = [], disabled }: Props) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const ref = useRef<HTMLDivElement>(null)

  const { data } = useQuery({
    queryKey: ['users', 'picker', search],
    queryFn: () => usersApi.list({ limit: 20 }),
    enabled: open,
  })

  const users = (data?.data ?? []).filter(u =>
    !excludeIds.includes(u.id) &&
    (u.name.toLowerCase().includes(search.toLowerCase()) ||
     u.email.toLowerCase().includes(search.toLowerCase()))
  )

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  return (
    <div ref={ref} className="relative">
      {label && <label className="label">{label}</label>}
      <div
        onClick={() => !disabled && setOpen(!open)}
        className={`input flex items-center gap-2 cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-accent/50'}`}
      >
        {value ? (
          <>
            <div className="w-5 h-5 rounded-full bg-accent/20 text-accent text-xs font-bold flex items-center justify-center flex-shrink-0">
              {value.name.charAt(0).toUpperCase()}
            </div>
            <span className="flex-1 text-sm font-semibold">{value.name}</span>
            <span className="text-xs font-mono text-muted">{value.role}</span>
            <button type="button" onClick={(e) => { e.stopPropagation(); onChange(null) }}
              className="text-muted hover:text-red-400 transition-colors">
              <X size={12} />
            </button>
          </>
        ) : (
          <>
            <UserCircle size={14} className="text-muted" />
            <span className="text-muted text-sm">{placeholder}</span>
          </>
        )}
      </div>
      {open && (
        <div className="absolute top-full mt-1 left-0 right-0 z-50 bg-surface border border-border rounded-xl shadow-xl overflow-hidden">
          <div className="p-2 border-b border-border flex items-center gap-2">
            <Search size={12} className="text-muted flex-shrink-0" />
            <input
              autoFocus
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by name or email..."
              className="flex-1 bg-transparent text-sm outline-none text-white placeholder:text-muted"
            />
          </div>
          <div className="max-h-52 overflow-y-auto">
            {users.length === 0 ? (
              <p className="text-center py-4 text-xs font-mono text-muted">No users found</p>
            ) : users.map(u => (
              <button key={u.id} type="button"
                onClick={() => { onChange(u as any); setOpen(false); setSearch('') }}
                className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-surface2 transition-colors text-left">
                <div className="w-7 h-7 rounded-full bg-accent/20 text-accent text-xs font-bold flex items-center justify-center flex-shrink-0">
                  {u.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{u.name}</p>
                  <p className="text-xs font-mono text-muted truncate">{u.email}</p>
                </div>
                <span className="text-xs font-mono text-muted px-1.5 py-0.5 bg-surface3 rounded flex-shrink-0">{u.role}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}


// Multi user picker for participants
interface MultiProps {
  value: UserMini[]
  onChange: (users: UserMini[]) => void
  label?: string
  roleLabels?: Record<string, string>
}

const ROLES = ['lead', 'participant', 'supporter']
const ROLE_COLORS: Record<string, string> = {
  lead: 'bg-accent/15 text-accent border-accent/30',
  participant: 'bg-accent2/15 text-accent2 border-accent2/30',
  supporter: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
}

export function MultiUserPicker({ value, onChange, label }: MultiProps) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [roleMap, setRoleMap] = useState<Record<string, string>>({})
  const ref = useRef<HTMLDivElement>(null)

  const { data } = useQuery({
    queryKey: ['users', 'picker', search],
    queryFn: () => usersApi.list({ limit: 20 }),
    enabled: open,
  })

  const existingIds = value.map(u => u.id)
  const users = (data?.data ?? []).filter(u =>
    !existingIds.includes(u.id) &&
    (u.name.toLowerCase().includes(search.toLowerCase()) ||
     u.email.toLowerCase().includes(search.toLowerCase()))
  )

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const addUser = (user: UserMini, role = 'participant') => {
    onChange([...value, { ...user, _role: role } as any])
    setRoleMap(r => ({ ...r, [user.id]: role }))
    setSearch('')
  }

  const removeUser = (id: string) => {
    onChange(value.filter(u => u.id !== id))
  }

  return (
    <div ref={ref} className="relative">
      {label && <label className="label">{label}</label>}
      {/* Selected users */}
      {value.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {value.map((u: any) => {
            const role = u._role || roleMap[u.id] || 'participant'
            return (
              <span key={u.id} className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-mono border ${ROLE_COLORS[role]}`}>
                <span className="font-bold">{u.name}</span>
                <span className="opacity-70">· {role}</span>
                <button type="button" onClick={() => removeUser(u.id)} className="opacity-60 hover:opacity-100 ml-0.5">
                  <X size={10} />
                </button>
              </span>
            )
          })}
        </div>
      )}
      {/* Add button */}
      <button type="button" onClick={() => setOpen(!open)}
        className="input flex items-center gap-2 w-full text-left hover:border-accent/50 transition-colors">
        <UserCircle size={14} className="text-muted" />
        <span className="text-muted text-sm">Add participant or supporter...</span>
      </button>
      {open && (
        <div className="absolute top-full mt-1 left-0 right-0 z-50 bg-surface border border-border rounded-xl shadow-xl overflow-hidden">
          <div className="p-2 border-b border-border flex items-center gap-2">
            <Search size={12} className="text-muted flex-shrink-0" />
            <input autoFocus type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search..." className="flex-1 bg-transparent text-sm outline-none text-white placeholder:text-muted" />
          </div>
          {users.length === 0
            ? <p className="text-center py-4 text-xs font-mono text-muted">No users found</p>
            : users.map(u => (
              <div key={u.id} className="flex items-center gap-2 px-2 py-1.5 hover:bg-surface2">
                <div className="w-6 h-6 rounded-full bg-accent/20 text-accent text-xs font-bold flex items-center justify-center flex-shrink-0">
                  {u.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate">{u.name}</p>
                  <p className="text-xs font-mono text-muted truncate">{u.role}</p>
                </div>
                <div className="flex gap-1">
                  {ROLES.map(role => (
                    <button key={role} type="button"
                      onClick={() => { addUser(u as any, role); setOpen(false) }}
                      className={`px-1.5 py-0.5 rounded text-xs font-mono border transition-colors hover:opacity-100 ${ROLE_COLORS[role]}`}>
                      {role}
                    </button>
                  ))}
                </div>
              </div>
            ))
          }
        </div>
      )}
    </div>
  )
}

import { ReactNode } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { LayoutDashboard, CheckSquare, FolderKanban, BarChart2, LayoutGrid, LogOut, Zap, Crown, Building2, Bell, UserCircle, MapPin } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'
import { useQuery } from '@tanstack/react-query'
import { notificationsApi } from '../../api/org'
import clsx from 'clsx'

const nav = [
  { to: '/dashboard',     icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/tasks',         icon: CheckSquare,     label: 'Tasks'     },
  { to: '/projects',      icon: FolderKanban,    label: 'Projects'  },
  { to: '/gantt',     icon: BarChart2,        label: 'Gantt'     },
  { to: '/kanban',   icon: LayoutGrid,      label: 'Kanban'    },
]

export function AppLayout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const { data: countData } = useQuery({
    queryKey: ['notifications', 'count'],
    queryFn: () => notificationsApi.unreadCount(),
    refetchInterval: 30_000,
  })
  const unreadCount = countData?.data ?? 0

  const linkCls = (isActive: boolean, color = 'accent') =>
    clsx('flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all',
      isActive
        ? color === 'red'    ? 'bg-red-500/15 text-red-400'
        : color === 'accent2'? 'bg-accent2/15 text-accent2'
        : 'bg-accent/15 text-accent'
        : color === 'red'    ? 'text-muted hover:text-red-400 hover:bg-red-500/10'
        : color === 'accent2'? 'text-muted hover:text-accent2 hover:bg-accent2/10'
        : 'text-muted hover:text-white hover:bg-surface2')

  return (
    <div className="flex h-screen overflow-hidden bg-bg">
      <aside className="w-56 flex-shrink-0 flex flex-col bg-surface border-r border-border">

        {/* Logo */}
        <div className="px-5 py-5 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center">
              <Zap size={14} className="text-white" />
            </div>
            <span className="font-extrabold text-base tracking-tight">Task<span className="text-accent">Flow</span></span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {nav.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} className={({ isActive }) => linkCls(isActive)}>
              <Icon size={16} />{label}
            </NavLink>
          ))}

          {/* Notifications */}
          <NavLink to="/notifications" className={({ isActive }) => linkCls(isActive)}>
            <Bell size={16} />
            <span className="flex-1">Notifications</span>
            {unreadCount > 0 && (
              <span className="bg-accent text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </NavLink>

          {/* Profile */}
          <NavLink to="/profile" className={({ isActive }) => linkCls(isActive)}>
            <UserCircle size={16} />My Profile
          </NavLink>

          {/* Admin / Director only */}
          {(user?.role === 'admin' || user?.role === 'director') && (
            <>
              <div className="my-2 border-t border-border" />
              {user?.role === 'admin' && (
                <NavLink to="/admin" className={({ isActive }) => linkCls(isActive, 'red')}>
                  <Crown size={16} />Admin Panel
                </NavLink>
              )}
              <NavLink to="/org" className={({ isActive }) => linkCls(isActive, 'accent2')}>
                <Building2 size={16} />Org Structure
              </NavLink>
              <NavLink to="/branches" className={({ isActive }) => linkCls(isActive, 'accent2')}>
                <MapPin size={16} />Branches & Holidays
              </NavLink>
            </>
          )}
        </nav>

        {/* User footer */}
        <div className="p-3 border-t border-border">
          <div className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer hover:bg-surface2 transition-colors"
            onClick={() => navigate('/profile')}>
            <div className="w-7 h-7 rounded-full bg-accent/20 flex items-center justify-center text-accent text-xs font-bold flex-shrink-0">
              {user?.name?.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold truncate">{user?.name}</p>
              <p className="text-xs text-muted truncate font-mono">{user?.role}</p>
            </div>
            <button onClick={(e) => { e.stopPropagation(); logout(); navigate('/login') }}
              className="text-muted hover:text-red-400 transition-colors" title="Logout">
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">{children}</main>
    </div>
  )
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">{title}</h1>
        {subtitle && <p className="text-muted text-sm font-mono mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-3">{actions}</div>}
    </div>
  )
}

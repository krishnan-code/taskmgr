import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider } from './context/AuthContext'
import { ProtectedRoute } from './components/auth/ProtectedRoute'
import { LoginPage, RegisterPage } from './pages/AuthPages'
import { DashboardPage } from './pages/DashboardPage'
import { TasksPage } from './pages/TasksPage'
import { TaskDetailPage } from './pages/TaskDetailPage'
import { ProjectsPage } from './pages/ProjectsPage'
import { GanttPage } from './pages/GanttPage'
import { AdminPage } from './pages/AdminPage'
import { OrgPage } from './pages/OrgPage'
import { NotificationsPage } from './pages/NotificationsPage'
import { ProfilePage } from './pages/ProfilePage'
import { BranchHolidayPage } from './pages/BranchHolidayPage'
import { KanbanPage } from './pages/KanbanPage'

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30_000 } },
})

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login"    element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/dashboard"       element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
            <Route path="/tasks"           element={<ProtectedRoute><TasksPage /></ProtectedRoute>} />
            <Route path="/tasks/:id"       element={<ProtectedRoute><TaskDetailPage /></ProtectedRoute>} />
            <Route path="/projects"        element={<ProtectedRoute><ProjectsPage /></ProtectedRoute>} />
            <Route path="/gantt"           element={<ProtectedRoute><GanttPage /></ProtectedRoute>} />
            <Route path="/admin"           element={<ProtectedRoute><AdminPage /></ProtectedRoute>} />
            <Route path="/org"             element={<ProtectedRoute><OrgPage /></ProtectedRoute>} />
            <Route path="/notifications"   element={<ProtectedRoute><NotificationsPage /></ProtectedRoute>} />
            <Route path="/profile"         element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
            <Route path="/branches"        element={<ProtectedRoute><BranchHolidayPage /></ProtectedRoute>} />
            <Route path="/kanban"          element={<ProtectedRoute><KanbanPage /></ProtectedRoute>} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </QueryClientProvider>
  )
}

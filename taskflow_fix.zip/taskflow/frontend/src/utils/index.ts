import { format, formatDistanceToNow } from 'date-fns'

export function formatTime(seconds: number): string {
  const h = Math.floor(seconds / 3600).toString().padStart(2, '0')
  const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0')
  const s = Math.floor(seconds % 60).toString().padStart(2, '0')
  return `${h}:${m}:${s}`
}

export function formatDate(date?: string): string {
  if (!date) return '—'
  return format(new Date(date), 'MMM d, yyyy')
}

export function timeAgo(date: string): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true })
}

export function statusLabel(status: string): string {
  return { not_started: 'Not Started', in_progress: 'In Progress', done: 'Done', blocked: 'Blocked' }[status] ?? status
}

export function priorityLabel(p: string): string {
  return p.charAt(0).toUpperCase() + p.slice(1)
}

export function getApiError(err: unknown): string {
  if (err && typeof err === 'object' && 'response' in err) {
    const res = (err as { response: { data: { message?: string } } }).response
    return res?.data?.message ?? 'Something went wrong'
  }
  return 'Something went wrong'
}

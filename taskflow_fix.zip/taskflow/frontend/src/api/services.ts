import api from './client'
import type {
  ApiResponse, PaginatedResponse,
  User, TokenResponse, Project, Task, TaskListItem,
  Subtask, TimeLog, Ticket,
  LoginForm, RegisterForm, TaskForm, SubtaskForm,
} from '../types'

// ── Users ─────────────────────────────────────────────────────────────────
export const usersApi = {
  list: (params?: { limit?: number; offset?: number }) =>
    api.get<PaginatedResponse<User>>('/users', { params }).then(r => r.data),
  get: (id: string) =>
    api.get<ApiResponse<User>>(`/users/${id}`).then(r => r.data),
  create: (data: { name: string; email: string; password: string; role: UserRole }) =>
    api.post<ApiResponse<User>>('/users', data).then(r => r.data),
  updateRole: (id: string, role: UserRole) =>
    api.patch<ApiResponse<User>>(`/users/${id}/role`, { role }).then(r => r.data),
  updateStatus: (id: string, is_active: boolean) =>
    api.patch<ApiResponse<User>>(`/users/${id}/status`, { is_active }).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/users/${id}`).then(r => r.data),
}

// ── Auth ──────────────────────────────────────────────────────────────────
export const authApi = {
  login: (data: LoginForm) =>
    api.post<ApiResponse<TokenResponse>>('/auth/login', data).then(r => r.data),
  register: (data: RegisterForm) =>
    api.post<ApiResponse<User>>('/auth/register', data).then(r => r.data),
  me: () =>
    api.get<ApiResponse<User>>('/auth/me').then(r => r.data),
  refresh: (refresh_token: string) =>
    api.post<ApiResponse<TokenResponse>>('/auth/refresh', { refresh_token }).then(r => r.data),
}

// ── Projects ──────────────────────────────────────────────────────────────
export const projectsApi = {
  list: (params?: { limit?: number; offset?: number }) =>
    api.get<PaginatedResponse<Project>>('/projects', { params }).then(r => r.data),
  get: (id: string) =>
    api.get<ApiResponse<Project>>(`/projects/${id}`).then(r => r.data),
  create: (data: { name: string; description?: string }) =>
    api.post<ApiResponse<Project>>('/projects', data).then(r => r.data),
  update: (id: string, data: Partial<{ name: string; description: string }>) =>
    api.put<ApiResponse<Project>>(`/projects/${id}`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/projects/${id}`).then(r => r.data),
}

// ── Tasks ─────────────────────────────────────────────────────────────────
export const tasksApi = {
  list: (params?: {
    limit?: number; offset?: number;
    status?: string; priority?: string;
    project_id?: string; assignee_id?: string;
  }) =>
    api.get<PaginatedResponse<TaskListItem>>('/tasks', { params }).then(r => r.data),
  get: (id: string) =>
    api.get<ApiResponse<Task>>(`/tasks/${id}`).then(r => r.data),
  create: (data: TaskForm) =>
    api.post<ApiResponse<Task>>('/tasks', data).then(r => r.data),
  update: (id: string, data: Partial<TaskForm>) =>
    api.put<ApiResponse<Task>>(`/tasks/${id}`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/tasks/${id}`).then(r => r.data),
}

// ── Subtasks ──────────────────────────────────────────────────────────────
export const subtasksApi = {
  list: (taskId: string) =>
    api.get<ApiResponse<Subtask[]>>(`/tasks/${taskId}/subtasks`).then(r => r.data),
  create: (taskId: string, data: SubtaskForm) =>
    api.post<ApiResponse<Subtask>>(`/tasks/${taskId}/subtasks`, data).then(r => r.data),
  update: (taskId: string, subtaskId: string, data: Partial<SubtaskForm & { done: boolean }>) =>
    api.put<ApiResponse<Subtask>>(`/tasks/${taskId}/subtasks/${subtaskId}`, data).then(r => r.data),
  delete: (taskId: string, subtaskId: string) =>
    api.delete<ApiResponse<null>>(`/tasks/${taskId}/subtasks/${subtaskId}`).then(r => r.data),
}

// ── Time Tracking ─────────────────────────────────────────────────────────
export const timeApi = {
  start: (taskId: string, subtaskId?: string) =>
    api.post<ApiResponse<TimeLog>>(`/tasks/${taskId}/timer/start`, { subtask_id: subtaskId }).then(r => r.data),
  stop: (taskId: string, timeLogId: string) =>
    api.post<ApiResponse<TimeLog>>(`/tasks/${taskId}/timer/stop`, { time_log_id: timeLogId }).then(r => r.data),
  logs: (taskId: string) =>
    api.get<ApiResponse<TimeLog[]>>(`/tasks/${taskId}/time-logs`).then(r => r.data),
  summary: (taskId: string) =>
    api.get(`/tasks/${taskId}/time-summary`).then(r => r.data),
}

// ── Tickets ───────────────────────────────────────────────────────────────
export const ticketsApi = {
  list: (taskId?: string) =>
    api.get<ApiResponse<Ticket[]>>('/tickets', { params: taskId ? { task_id: taskId } : {} }).then(r => r.data),
  create: (data: { task_id: string; title?: string; priority?: string }) =>
    api.post<ApiResponse<Ticket>>('/tickets', data).then(r => r.data),
  sync: (id: string) =>
    api.get<ApiResponse<Ticket>>(`/tickets/${id}/sync`).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/tickets/${id}`).then(r => r.data),
}

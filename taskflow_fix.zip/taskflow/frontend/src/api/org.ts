import api from './client'
import type { ApiResponse, PaginatedResponse } from '../types'

// ── Types ──────────────────────────────────────────────────────────────────
export interface Vertical {
  id: string; name: string; description?: string
  is_ticketing_enabled: boolean; is_active: boolean
  department_count: number; created_at: string
}

export interface Department {
  id: string; name: string; vertical_id: string
  parent_id?: string; level: string; head_user_id?: string
  is_ticketing_enabled: boolean; is_active: boolean
  created_at: string; children: Department[]
}

export interface Designation {
  id: string; title: string; department_id?: string
  level_rank: number; level_name: string
  is_hod_level: boolean; is_director_level: boolean
  is_active: boolean; created_at: string
}

export interface SLAPolicy {
  id: string; name: string; priority: string
  response_minutes: number; resolution_minutes: number
  response_label: string; resolution_label: string
  is_active: boolean; created_at: string
}

export interface Group {
  id: string; name: string; description?: string
  created_by?: string; is_active: boolean
  member_count: number; created_at: string
}

export interface GroupDetail extends Group {
  members: GroupMember[]
}

export interface GroupMember {
  id: string; user_id: string; user_name: string
  user_email: string; user_department: string; created_at: string
}

export interface Notification {
  id: string; type: string; title: string; body?: string
  reference_type?: string; reference_id?: string
  is_read: boolean; created_at: string
}

// ── Verticals ──────────────────────────────────────────────────────────────
export const verticalsApi = {
  list: (p?: { limit?: number; offset?: number }) =>
    api.get<PaginatedResponse<Vertical>>('/verticals', { params: p }).then(r => r.data),
  get: (id: string) =>
    api.get<ApiResponse<Vertical>>(`/verticals/${id}`).then(r => r.data),
  create: (data: { name: string; description?: string; is_ticketing_enabled?: boolean }) =>
    api.post<ApiResponse<Vertical>>('/verticals', data).then(r => r.data),
  update: (id: string, data: Partial<Vertical>) =>
    api.put<ApiResponse<Vertical>>(`/verticals/${id}`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/verticals/${id}`).then(r => r.data),
}

// ── Departments ────────────────────────────────────────────────────────────
export const departmentsApi = {
  list: (params?: { vertical_id?: string; tree?: boolean }) =>
    api.get<ApiResponse<Department[]>>('/departments', { params }).then(r => r.data),
  get: (id: string) =>
    api.get<ApiResponse<Department>>(`/departments/${id}`).then(r => r.data),
  create: (data: Partial<Department> & { name: string; vertical_id: string }) =>
    api.post<ApiResponse<Department>>('/departments', data).then(r => r.data),
  update: (id: string, data: Partial<Department>) =>
    api.put<ApiResponse<Department>>(`/departments/${id}`, data).then(r => r.data),
  transfer: (id: string, data: { vertical_id?: string; parent_id?: string }) =>
    api.patch<ApiResponse<Department>>(`/departments/${id}/transfer`, data).then(r => r.data),
  toggleModule: (id: string, module: string, is_enabled: boolean) =>
    api.patch<ApiResponse<null>>(`/departments/${id}/modules`, { module, is_enabled }).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/departments/${id}`).then(r => r.data),
}

// ── Designations ───────────────────────────────────────────────────────────
export const designationsApi = {
  list: (p?: { limit?: number; offset?: number; department_id?: string }) =>
    api.get<PaginatedResponse<Designation>>('/designations', { params: p }).then(r => r.data),
  create: (data: { title: string; level_rank: number; department_id?: string; is_hod_level?: boolean; is_director_level?: boolean }) =>
    api.post<ApiResponse<Designation>>('/designations', data).then(r => r.data),
  update: (id: string, data: Partial<Designation>) =>
    api.put<ApiResponse<Designation>>(`/designations/${id}`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/designations/${id}`).then(r => r.data),
}

// ── SLA Policies ───────────────────────────────────────────────────────────
export const slaApi = {
  list: () => api.get<ApiResponse<SLAPolicy[]>>('/sla-policies').then(r => r.data),
  update: (id: string, data: { name?: string; response_minutes?: number; resolution_minutes?: number }) =>
    api.put<ApiResponse<SLAPolicy>>(`/sla-policies/${id}`, data).then(r => r.data),
}

// ── Groups ─────────────────────────────────────────────────────────────────
export const groupsApi = {
  list: (p?: { limit?: number; offset?: number }) =>
    api.get<PaginatedResponse<Group>>('/groups', { params: p }).then(r => r.data),
  get: (id: string) =>
    api.get<ApiResponse<GroupDetail>>(`/groups/${id}`).then(r => r.data),
  create: (data: { name: string; description?: string; member_ids?: string[] }) =>
    api.post<ApiResponse<GroupDetail>>('/groups', data).then(r => r.data),
  update: (id: string, data: { name?: string; description?: string }) =>
    api.put<ApiResponse<Group>>(`/groups/${id}`, data).then(r => r.data),
  addMembers: (id: string, user_ids: string[]) =>
    api.post<ApiResponse<GroupDetail>>(`/groups/${id}/members`, { user_ids }).then(r => r.data),
  removeMember: (id: string, user_id: string) =>
    api.delete<ApiResponse<null>>(`/groups/${id}/members/${user_id}`).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/groups/${id}`).then(r => r.data),
}

// ── Notifications ──────────────────────────────────────────────────────────
export const notificationsApi = {
  list: (p?: { limit?: number; offset?: number; unread_only?: boolean }) =>
    api.get<PaginatedResponse<Notification>>('/notifications', { params: p }).then(r => r.data),
  unreadCount: () =>
    api.get<ApiResponse<number>>('/notifications/unread-count').then(r => r.data),
  markRead: (id: string) =>
    api.patch<ApiResponse<null>>(`/notifications/${id}/read`).then(r => r.data),
  markAllRead: () =>
    api.patch<ApiResponse<null>>('/notifications/read-all').then(r => r.data),
}

// ── Branches ───────────────────────────────────────────────────────────────
export interface Branch {
  id: string; branch_code: string; name: string
  address?: string; city?: string; state?: string
  country?: string; pincode?: string; phone?: string; email?: string
  timezone: string; is_headquarters: boolean; is_active: boolean
  user_count: number; created_at: string
}

export interface Holiday {
  id: string; name: string; date: string
  holiday_type: 'global' | 'local'; branch_id?: string; branch_name?: string
  description?: string; is_recurring: boolean; is_active: boolean; created_at: string
}

export const branchesApi = {
  list: (p?: { limit?: number; offset?: number }) =>
    api.get<PaginatedResponse<Branch>>('/branches', { params: p }).then(r => r.data),
  get: (id: string) =>
    api.get<ApiResponse<Branch>>(`/branches/${id}`).then(r => r.data),
  create: (data: Partial<Branch> & { branch_code: string; name: string }) =>
    api.post<ApiResponse<Branch>>('/branches', data).then(r => r.data),
  update: (id: string, data: Partial<Branch>) =>
    api.put<ApiResponse<Branch>>(`/branches/${id}`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/branches/${id}`).then(r => r.data),
}

export const holidaysApi = {
  list: (p?: { limit?: number; offset?: number; holiday_type?: string; branch_id?: string; year?: number }) =>
    api.get<PaginatedResponse<Holiday>>('/holidays', { params: p }).then(r => r.data),
  upcoming: (limit = 5) =>
    api.get<ApiResponse<Holiday[]>>(`/holidays/upcoming?limit=${limit}`).then(r => r.data),
  calendar: (year: number, branch_id?: string) =>
    api.get<ApiResponse<Holiday[]>>(`/holidays/calendar/${year}${branch_id ? `?branch_id=${branch_id}` : ''}`).then(r => r.data),
  create: (data: Partial<Holiday> & { name: string; date: string }) =>
    api.post<ApiResponse<Holiday>>('/holidays', data).then(r => r.data),
  update: (id: string, data: Partial<Holiday>) =>
    api.put<ApiResponse<Holiday>>(`/holidays/${id}`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete<ApiResponse<null>>(`/holidays/${id}`).then(r => r.data),
}

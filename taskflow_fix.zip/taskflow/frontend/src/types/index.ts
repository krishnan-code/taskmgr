// ── Enums ──────────────────────────────────────────────────────────────────
export type TaskStatus = 'not_started' | 'in_progress' | 'blocked' | 'done'
export type TaskPriority = 'low' | 'medium' | 'high'
export type UserRole = 'admin' | 'manager' | 'member'
export type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed'

// ── User ───────────────────────────────────────────────────────────────────
export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  is_active: boolean
  created_at: string
}

// ── Auth ───────────────────────────────────────────────────────────────────
export interface TokenResponse {
  access_token: string
  refresh_token: string
  token_type: string
  user: User
}

// ── Project ────────────────────────────────────────────────────────────────
export interface Project {
  id: string
  name: string
  description?: string
  owner_id?: string
  created_at: string
  task_count: number
}

// ── Subtask ────────────────────────────────────────────────────────────────
export interface Subtask {
  id: string
  title: string
  done: boolean
  task_id: string
  assignee_id?: string
  due_date?: string
  created_at: string
  total_seconds: number
}

// ── Task ───────────────────────────────────────────────────────────────────
export interface Task {
  id: string
  title: string
  description?: string
  status: TaskStatus
  priority: TaskPriority
  start_date?: string
  due_date?: string
  project_id?: string
  assignee_id?: string
  notes?: string
  created_at: string
  updated_at?: string
  subtasks: Subtask[]
  total_seconds: number
}

export interface TaskListItem {
  id: string
  title: string
  status: TaskStatus
  priority: TaskPriority
  start_date?: string
  due_date?: string
  assignee_id?: string
  project_id?: string
  subtask_count: number
  subtask_done_count: number
  total_seconds: number
  created_at: string
}

// ── Time Log ───────────────────────────────────────────────────────────────
export interface TimeLog {
  id: string
  task_id: string
  subtask_id?: string
  user_id?: string
  started_at: string
  ended_at?: string
  duration_seconds: number
  note?: string
}

// ── Ticket ─────────────────────────────────────────────────────────────────
export interface Ticket {
  id: string
  task_id: string
  external_ticket_id: string
  external_url?: string
  title?: string
  status: TicketStatus
  priority?: string
  reporter?: string
  synced_at?: string
  created_at: string
}

// ── API Response envelopes ─────────────────────────────────────────────────
export interface ApiResponse<T> {
  success: boolean
  message: string
  data: T
}

export interface PaginationMeta {
  total: number
  limit: number
  offset: number
  has_next: boolean
  has_prev: boolean
}

export interface PaginatedResponse<T> {
  success: boolean
  message: string
  data: T[]
  meta: PaginationMeta
}

// ── Forms ──────────────────────────────────────────────────────────────────
export interface LoginForm {
  email: string
  password: string
}

export interface RegisterForm {
  name: string
  email: string
  password: string
}

export interface TaskForm {
  title: string
  description?: string
  status: TaskStatus
  priority: TaskPriority
  start_date?: string
  due_date?: string
  project_id?: string
  assignee_id?: string
  notes?: string
}

export interface SubtaskForm {
  title: string
  due_date?: string
}

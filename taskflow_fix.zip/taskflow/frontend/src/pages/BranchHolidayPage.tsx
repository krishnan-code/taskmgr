import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { Plus, Building, Globe, MapPin, Trash2, Calendar } from 'lucide-react'
import { branchesApi, holidaysApi, type Branch, type Holiday } from '../api/org'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, Modal, Input, Select, Textarea, Spinner, EmptyState, StatusBadge } from '../components/ui'
import { getApiError, formatDate } from '../utils'

const TIMEZONES = ['Asia/Kolkata', 'Asia/Dubai', 'Asia/Singapore', 'Europe/London', 'America/New_York']
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

function HolidayTypeBadge({ type, branch_name }: { type: string; branch_name?: string }) {
  if (type === 'global') return (
    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-accent/15 text-accent border border-accent/30">
      <Globe size={10} /> Global
    </span>
  )
  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
      <MapPin size={10} /> {branch_name ?? 'Local'}
    </span>
  )
}

export function BranchHolidayPage() {
  const qc = useQueryClient()
  const [tab, setTab] = useState<'branches' | 'holidays'>('branches')
  const [showBranchModal, setShowBranchModal] = useState(false)
  const [showHolidayModal, setShowHolidayModal] = useState(false)
  const [yearFilter, setYearFilter] = useState(new Date().getFullYear())
  const [typeFilter, setTypeFilter] = useState('')
  const [error, setError] = useState('')

  // Queries
  const { data: branchData, isLoading: branchLoading } = useQuery({ queryKey: ['branches'], queryFn: () => branchesApi.list({ limit: 50 }) })
  const { data: holidayData, isLoading: holidayLoading } = useQuery({
    queryKey: ['holidays', yearFilter, typeFilter],
    queryFn: () => holidaysApi.list({ limit: 100, year: yearFilter, holiday_type: typeFilter || undefined }),
  })

  const branches = branchData?.data ?? []
  const holidays = holidayData?.data ?? []

  // Branch form
  const { register: rb, handleSubmit: hsb, reset: rsb, formState: { errors: eb } } = useForm<Partial<Branch>>({ defaultValues: { country: 'India', timezone: 'Asia/Kolkata' } })
  const createBranch = useMutation({
    mutationFn: (d: any) => branchesApi.create(d),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['branches'] }); setShowBranchModal(false); rsb(); setError('') },
    onError: (e) => setError(getApiError(e)),
  })
  const deleteBranch = useMutation({
    mutationFn: branchesApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['branches'] }),
    onError: (e) => alert(getApiError(e)),
  })

  // Holiday form
  const { register: rh, handleSubmit: hsh, reset: rsh, watch: wh } = useForm<Partial<Holiday>>({ defaultValues: { holiday_type: 'global', is_recurring: true } })
  const holidayType = wh('holiday_type')
  const createHoliday = useMutation({
    mutationFn: (d: any) => holidaysApi.create(d),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['holidays'] }); setShowHolidayModal(false); rsh(); setError('') },
    onError: (e) => setError(getApiError(e)),
  })
  const deleteHoliday = useMutation({
    mutationFn: holidaysApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['holidays'] }),
  })

  // Group holidays by month for calendar view
  const holidaysByMonth = MONTHS.map((month, i) => ({
    month,
    holidays: holidays.filter(h => new Date(h.date).getMonth() === i)
  }))

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader
          title="Branches & Holidays"
          subtitle="Manage office locations, branch codes and org calendar"
          actions={
            tab === 'branches'
              ? <Button onClick={() => setShowBranchModal(true)}><Plus size={14} /> Add Branch</Button>
              : <Button onClick={() => setShowHolidayModal(true)}><Plus size={14} /> Add Holiday</Button>
          }
        />

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-surface2 p-1 rounded-lg w-fit">
          <button onClick={() => setTab('branches')} className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold transition-all ${tab === 'branches' ? 'bg-accent text-white' : 'text-muted hover:text-white'}`}>
            <Building size={14} /> Branches
          </button>
          <button onClick={() => setTab('holidays')} className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold transition-all ${tab === 'holidays' ? 'bg-accent text-white' : 'text-muted hover:text-white'}`}>
            <Calendar size={14} /> Holidays
          </button>
        </div>

        {/* ── BRANCHES TAB ──────────────────────────────────────────────────── */}
        {tab === 'branches' && (
          branchLoading ? <div className="flex justify-center py-16"><Spinner size="lg" /></div>
          : branches.length === 0
          ? <EmptyState icon="🏢" title="No branches yet" description="Add your first branch to get started" />
          : (
            <div className="grid grid-cols-3 gap-4">
              {branches.map(b => (
                <div key={b.id} className="card group hover:border-accent/30 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-accent/15 text-accent border border-accent/30 rounded font-mono text-xs font-bold">{b.branch_code}</span>
                      {b.is_headquarters && <span className="px-2 py-0.5 bg-amber-500/15 text-amber-400 border border-amber-500/30 rounded font-mono text-xs font-bold">HQ</span>}
                    </div>
                    <button onClick={() => { if (confirm('Deactivate this branch?')) deleteBranch.mutate(b.id) }}
                      className="opacity-0 group-hover:opacity-100 text-muted hover:text-red-400 transition-all p-1 rounded hover:bg-red-500/10">
                      <Trash2 size={13} />
                    </button>
                  </div>
                  <h3 className="font-bold text-base mb-1">{b.name}</h3>
                  <div className="space-y-1 mt-3">
                    {b.city && <p className="text-xs font-mono text-muted flex items-center gap-1.5"><MapPin size={10} />{b.city}{b.state ? `, ${b.state}` : ''}</p>}
                    {b.phone && <p className="text-xs font-mono text-muted">📞 {b.phone}</p>}
                    {b.email && <p className="text-xs font-mono text-muted truncate">✉️ {b.email}</p>}
                  </div>
                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                    <span className="text-xs font-mono text-muted">👥 {b.user_count} users</span>
                    <span className="text-xs font-mono text-muted">{b.timezone}</span>
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        {/* ── HOLIDAYS TAB ──────────────────────────────────────────────────── */}
        {tab === 'holidays' && (
          <div>
            {/* Filters */}
            <div className="flex gap-3 mb-6">
              <div className="flex items-center gap-2">
                <button onClick={() => setYearFilter(y => y - 1)} className="p-2 rounded-lg bg-surface2 border border-border text-muted hover:text-white transition-colors text-sm">‹</button>
                <span className="font-bold font-mono w-14 text-center">{yearFilter}</span>
                <button onClick={() => setYearFilter(y => y + 1)} className="p-2 rounded-lg bg-surface2 border border-border text-muted hover:text-white transition-colors text-sm">›</button>
              </div>
              <select className="input w-40" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
                <option value="">All Types</option>
                <option value="global">Global Only</option>
                <option value="local">Local Only</option>
              </select>
              <span className="text-xs font-mono text-muted self-center">{holidays.length} holiday{holidays.length !== 1 ? 's' : ''}</span>
            </div>

            {holidayLoading ? <div className="flex justify-center py-16"><Spinner size="lg" /></div>
            : holidays.length === 0
            ? <EmptyState icon="📅" title="No holidays found" description="Add holidays to populate the org calendar" />
            : (
              <div className="grid grid-cols-3 gap-4">
                {holidaysByMonth.filter(m => m.holidays.length > 0).map(({ month, holidays: mh }) => (
                  <div key={month} className="card">
                    <h3 className="font-bold text-xs font-mono uppercase tracking-widest text-muted mb-3">{month} {yearFilter}</h3>
                    <div className="space-y-2">
                      {mh.map(h => (
                        <div key={h.id} className="flex items-center gap-3 group">
                          <div className="w-8 h-8 rounded-lg bg-surface2 flex items-center justify-center text-xs font-bold font-mono text-accent flex-shrink-0">
                            {new Date(h.date).getDate()}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold truncate">{h.name}</p>
                            <HolidayTypeBadge type={h.holiday_type} branch_name={h.branch_name} />
                          </div>
                          <button onClick={() => deleteHoliday.mutate(h.id)}
                            className="opacity-0 group-hover:opacity-100 text-muted hover:text-red-400 transition-all">
                            <Trash2 size={12} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Add Branch Modal ──────────────────────────────────────────────── */}
      <Modal open={showBranchModal} onClose={() => { setShowBranchModal(false); setError('') }} title="Add Branch" size="md">
        <form onSubmit={hsb(d => createBranch.mutate(d))} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Branch Code *" placeholder="e.g. CHN-001" {...rb('branch_code', { required: 'Required' })} />
            <Input label="Branch Name *" placeholder="e.g. Chennai HQ" {...rb('name', { required: 'Required' })} />
          </div>
          <Textarea label="Address" placeholder="Full address..." {...rb('address')} />
          <div className="grid grid-cols-3 gap-4">
            <Input label="City" placeholder="Chennai" {...rb('city')} />
            <Input label="State" placeholder="Tamil Nadu" {...rb('state')} />
            <Input label="Pincode" placeholder="600001" {...rb('pincode')} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Phone" placeholder="+91 44 1234 5678" {...rb('phone')} />
            <Input label="Email" type="email" placeholder="branch@company.com" {...rb('email')} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Select label="Timezone" {...rb('timezone')}>
              {TIMEZONES.map(t => <option key={t} value={t}>{t}</option>)}
            </Select>
            <Input label="Country" placeholder="India" {...rb('country')} />
          </div>
          <label className="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" className="w-4 h-4 rounded accent-amber-400" {...rb('is_headquarters')} />
            <span className="text-sm font-mono text-muted">Mark as Headquarters</span>
          </label>
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="secondary" onClick={() => setShowBranchModal(false)}>Cancel</Button>
            <Button type="submit" loading={createBranch.isPending}>Create Branch</Button>
          </div>
        </form>
      </Modal>

      {/* ── Add Holiday Modal ─────────────────────────────────────────────── */}
      <Modal open={showHolidayModal} onClose={() => { setShowHolidayModal(false); setError('') }} title="Add Holiday" size="sm">
        <form onSubmit={hsh(d => createHoliday.mutate(d))} className="space-y-4">
          <Input label="Holiday Name *" placeholder="e.g. Pongal, Republic Day" {...rh('name', { required: 'Required' })} />
          <Input label="Date *" type="date" {...rh('date', { required: 'Required' })} />
          <Select label="Type" {...rh('holiday_type')}>
            <option value="global">🌐 Global — All Branches</option>
            <option value="local">📍 Local — Specific Branch</option>
          </Select>
          {holidayType === 'local' && (
            <Select label="Branch *" {...rh('branch_id', { required: holidayType === 'local' })}>
              <option value="">Select branch...</option>
              {branches.map(b => <option key={b.id} value={b.id}>{b.branch_code} — {b.name}</option>)}
            </Select>
          )}
          <Textarea label="Description (optional)" placeholder="Brief description..." {...rh('description')} />
          <label className="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" className="w-4 h-4 rounded accent-accent" defaultChecked {...rh('is_recurring')} />
            <span className="text-sm font-mono text-muted">Recurring yearly (auto-repeat)</span>
          </label>
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="secondary" onClick={() => setShowHolidayModal(false)}>Cancel</Button>
            <Button type="submit" loading={createHoliday.isPending}>Add Holiday</Button>
          </div>
        </form>
      </Modal>
    </AppLayout>
  )
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Bell, CheckCheck } from 'lucide-react'
import { notificationsApi } from '../api/org'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, Spinner, EmptyState } from '../components/ui'
import { timeAgo } from '../utils'

const TYPE_ICONS: Record<string, string> = {
  task_assigned: '📋', task_accepted: '✅', task_rejected: '❌',
  task_due_soon: '⏰', task_overdue: '🔴', ticket_assigned: '🎫',
  ticket_comment: '💬', ticket_escalated: '🚨', sla_warning: '⚠️',
  sla_breached: '🔥', group_added: '👥', general: '📢',
}

export function NotificationsPage() {
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => notificationsApi.list({ limit: 50 }),
  })

  const markRead = useMutation({
    mutationFn: notificationsApi.markRead,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['notifications'] }); qc.invalidateQueries({ queryKey: ['notifications', 'count'] }) },
  })

  const markAll = useMutation({
    mutationFn: notificationsApi.markAllRead,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['notifications'] }); qc.invalidateQueries({ queryKey: ['notifications', 'count'] }) },
  })

  const notifications = data?.data ?? []
  const unread = notifications.filter(n => !n.is_read).length

  return (
    <AppLayout>
      <div className="p-8 max-w-2xl">
        <PageHeader
          title="Notifications"
          subtitle={unread > 0 ? `${unread} unread` : 'All caught up'}
          actions={unread > 0 && (
            <Button variant="secondary" size="sm" onClick={() => markAll.mutate()} loading={markAll.isPending}>
              <CheckCheck size={14} /> Mark all read
            </Button>
          )}
        />

        {isLoading ? (
          <div className="flex justify-center py-16"><Spinner size="lg" /></div>
        ) : notifications.length === 0 ? (
          <EmptyState icon="🔔" title="No notifications yet" description="Task assignments, SLA alerts and ticket updates will appear here" />
        ) : (
          <div className="space-y-2">
            {notifications.map(n => (
              <div
                key={n.id}
                onClick={() => !n.is_read && markRead.mutate(n.id)}
                className={`flex gap-4 p-4 rounded-xl border transition-all cursor-pointer ${n.is_read ? 'bg-surface border-border opacity-60' : 'bg-surface border-accent/30 hover:border-accent/60'}`}
              >
                <div className="text-2xl flex-shrink-0 mt-0.5">{TYPE_ICONS[n.type] ?? '📢'}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className={`text-sm font-semibold ${!n.is_read ? 'text-white' : 'text-muted'}`}>{n.title}</p>
                    {!n.is_read && <div className="w-2 h-2 rounded-full bg-accent flex-shrink-0 mt-1.5" />}
                  </div>
                  {n.body && <p className="text-xs text-muted font-mono mt-1 line-clamp-2">{n.body}</p>}
                  <p className="text-xs text-muted font-mono mt-2">{timeAgo(n.created_at)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  )
}

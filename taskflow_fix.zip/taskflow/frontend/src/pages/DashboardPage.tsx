import { useQuery } from '@tanstack/react-query'
import { CheckCircle2, Clock, AlertTriangle, FolderKanban, Plus } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { tasksApi, projectsApi } from '../api/services'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { StatusBadge, PriorityBadge, Spinner, Button } from '../components/ui'
import { formatDate, formatTime, timeAgo } from '../utils'
import { useAuth } from '../context/AuthContext'

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string | number; color: string }) {
  return (
    <div className={`card relative overflow-hidden`}>
      <div className={`absolute top-0 left-0 right-0 h-0.5 ${color}`} />
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-mono uppercase tracking-widest text-muted mb-2">{label}</p>
          <p className="text-3xl font-extrabold">{value}</p>
        </div>
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center bg-surface2`}>
          <Icon size={18} className="text-muted" />
        </div>
      </div>
    </div>
  )
}

export function DashboardPage() {
  const { user } = useAuth()
  const navigate = useNavigate()

  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['tasks', 'dashboard'],
    queryFn: () => tasksApi.list({ limit: 5 }),
  })

  const { data: projects } = useQuery({
    queryKey: ['projects', 'dashboard'],
    queryFn: () => projectsApi.list({ limit: 100 }),
  })

  const allTasks = tasks?.data ?? []
  const inProgress = allTasks.filter(t => t.status === 'in_progress').length
  const done = allTasks.filter(t => t.status === 'done').length
  const totalSecs = allTasks.reduce((a, t) => a + t.total_seconds, 0)

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader
          title={`Good day, ${user?.name?.split(' ')[0]} 👋`}
          subtitle="Here's what's happening with your projects"
          actions={
            <Button onClick={() => navigate('/tasks')} size="sm">
              <Plus size={14} /> New Task
            </Button>
          }
        />

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <StatCard icon={CheckCircle2} label="Total Tasks" value={tasks?.meta?.total ?? 0} color="bg-accent" />
          <StatCard icon={AlertTriangle} label="In Progress" value={inProgress} color="bg-accent2" />
          <StatCard icon={CheckCircle2} label="Completed" value={done} color="bg-emerald-500" />
          <StatCard icon={Clock} label="Total Logged" value={formatTime(totalSecs)} color="bg-amber-500" />
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Recent Tasks */}
          <div className="col-span-2 card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-sm uppercase tracking-widest text-muted">Recent Tasks</h2>
              <button onClick={() => navigate('/tasks')} className="text-xs font-mono text-accent hover:text-purple-400 transition-colors">View all →</button>
            </div>
            {tasksLoading ? (
              <div className="flex justify-center py-8"><Spinner /></div>
            ) : allTasks.length === 0 ? (
              <p className="text-muted text-sm font-mono text-center py-8">No tasks yet. Create your first task!</p>
            ) : (
              <div className="space-y-2">
                {allTasks.map(task => (
                  <div
                    key={task.id}
                    onClick={() => navigate(`/tasks/${task.id}`)}
                    className="flex items-center gap-4 p-3 rounded-lg bg-surface2 hover:bg-surface3 cursor-pointer transition-colors border border-transparent hover:border-border"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{task.title}</p>
                      <p className="text-xs text-muted font-mono mt-0.5">
                        {task.subtask_done_count}/{task.subtask_count} subtasks · {formatTime(task.total_seconds)}
                      </p>
                    </div>
                    <StatusBadge status={task.status} />
                    <PriorityBadge priority={task.priority} />
                    <span className="text-xs text-muted font-mono whitespace-nowrap">{formatDate(task.due_date)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Projects */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-sm uppercase tracking-widest text-muted">Projects</h2>
              <button onClick={() => navigate('/projects')} className="text-xs font-mono text-accent hover:text-purple-400 transition-colors">View all →</button>
            </div>
            <div className="space-y-2">
              {(projects?.data ?? []).slice(0, 6).map(p => (
                <div key={p.id} className="flex items-center gap-3 p-3 rounded-lg bg-surface2 hover:bg-surface3 cursor-pointer transition-colors" onClick={() => navigate(`/projects`)}>
                  <div className="w-8 h-8 rounded-lg bg-accent/15 flex items-center justify-center">
                    <FolderKanban size={14} className="text-accent" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{p.name}</p>
                    <p className="text-xs text-muted font-mono">{p.task_count} tasks</p>
                  </div>
                </div>
              ))}
              {(projects?.data ?? []).length === 0 && (
                <p className="text-muted text-sm font-mono text-center py-4">No projects yet</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}

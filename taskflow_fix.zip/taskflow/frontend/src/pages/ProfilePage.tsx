import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { User, Briefcase, Star, Shield } from 'lucide-react'
import { authApi } from '../api/services'
import api from '../api/client'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, Input, Select, Textarea, Spinner } from '../components/ui'
import { getApiError, formatDate } from '../utils'
import { useAuth } from '../context/AuthContext'

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']
const TABS = [
  { id: 'personal',    label: 'Personal',    icon: User      },
  { id: 'employment',  label: 'Employment',  icon: Briefcase },
  { id: 'professional',label: 'Professional',icon: Star      },
  { id: 'security',    label: 'Security',    icon: Shield    },
]

export function ProfilePage() {
  const { user: authUser } = useAuth()
  const qc = useQueryClient()
  const [tab, setTab] = useState('personal')
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => authApi.me(),
  })
  const user = data?.data

  const { register, handleSubmit, formState: { isDirty } } = useForm({ values: user ?? {} })

  const updateMutation = useMutation({
    mutationFn: (d: any) => api.patch('/api/v1/users/me', d).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['me'] })
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    },
    onError: (e) => setError(getApiError(e)),
  })

  if (isLoading) return <AppLayout><div className="flex justify-center py-16"><Spinner size="lg" /></div></AppLayout>

  return (
    <AppLayout>
      <div className="p-8 max-w-3xl">
        <div className="flex items-center gap-5 mb-8">
          {/* Avatar */}
          <div className="w-20 h-20 rounded-2xl bg-accent/20 flex items-center justify-center text-accent text-3xl font-extrabold flex-shrink-0">
            {user?.name?.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold">{user?.name}</h1>
            <p className="text-muted font-mono text-sm mt-0.5">{user?.job_title || user?.role}</p>
            <div className="flex gap-2 mt-2 flex-wrap">
              {user?.department_id && <span className="text-xs font-mono bg-surface2 border border-border px-2 py-0.5 rounded">🏬 Dept assigned</span>}
              {user?.work_location && <span className="text-xs font-mono bg-surface2 border border-border px-2 py-0.5 rounded">📍 {user.work_location}</span>}
              {user?.employment_type && <span className="text-xs font-mono bg-surface2 border border-border px-2 py-0.5 rounded">💼 {user.employment_type.replace('_', '-')}</span>}
              {user?.is_ldap_synced && <span className="text-xs font-mono bg-accent2/15 text-accent2 border border-accent2/30 px-2 py-0.5 rounded">LDAP</span>}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-surface2 p-1 rounded-lg w-fit">
          {TABS.map(t => {
            const Icon = t.icon
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold transition-all ${tab === t.id ? 'bg-accent text-white' : 'text-muted hover:text-white'}`}>
                <Icon size={14} />{t.label}
              </button>
            )
          })}
        </div>

        <form onSubmit={handleSubmit(d => updateMutation.mutate(d))}>
          {/* ── PERSONAL TAB ──────────────────────────────────────────────── */}
          {tab === 'personal' && (
            <div className="card space-y-4">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-2">Personal Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <Input label="Phone Number" placeholder="+91 99999 99999" {...register('phone_number')} />
                <Input label="Mobile Number" placeholder="+91 88888 88888" {...register('mobile_number')} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Input label="Date of Birth" type="date" {...register('date_of_birth')} />
                <Select label="Gender" {...register('gender')}>
                  <option value="">Select...</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                  <option value="prefer_not_to_say">Prefer not to say</option>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Select label="Blood Group" {...register('blood_group')}>
                  <option value="">Select...</option>
                  {BLOOD_GROUPS.map(g => <option key={g} value={g}>{g}</option>)}
                </Select>
              </div>
              <Textarea label="Address" placeholder="Full address..." rows={3} {...register('address')} />

              <div className="border-t border-border pt-4">
                <h4 className="text-xs font-mono uppercase tracking-widest text-muted mb-3">Emergency Contact</h4>
                <div className="grid grid-cols-3 gap-4">
                  <Input label="Name" placeholder="Contact name" {...register('emergency_contact_name')} />
                  <Input label="Phone" placeholder="+91 77777 77777" {...register('emergency_contact_phone')} />
                  <Input label="Relation" placeholder="e.g. Spouse, Parent" {...register('emergency_contact_relation')} />
                </div>
              </div>
            </div>
          )}

          {/* ── EMPLOYMENT TAB ────────────────────────────────────────────── */}
          {tab === 'employment' && (
            <div className="card space-y-4">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-2">Employment Details</h3>
              <div className="grid grid-cols-2 gap-4">
                <Input label="Employee ID" placeholder="EMP-001" {...register('employee_id')} />
                <Input label="Job Title" placeholder="e.g. Senior Engineer" {...register('job_title')} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Select label="Employment Type" {...register('employment_type')}>
                  <option value="">Select...</option>
                  <option value="full_time">Full Time</option>
                  <option value="contract">Contract</option>
                  <option value="intern">Intern</option>
                </Select>
                <Select label="Work Location" {...register('work_location')}>
                  <option value="">Select...</option>
                  <option value="office">Office</option>
                  <option value="remote">Remote</option>
                  <option value="hybrid">Hybrid</option>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Input label="Date of Joining" type="date" {...register('date_of_joining')} />
                <Input label="Shift Timing" placeholder="e.g. 9:00 AM - 6:00 PM" {...register('shift_timing')} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Input label="Probation End Date" type="date" {...register('probation_end_date')} />
                <Input label="Last Working Date" type="date" {...register('last_working_date')} />
              </div>

              {/* Read-only org info */}
              <div className="border-t border-border pt-4">
                <h4 className="text-xs font-mono uppercase tracking-widest text-muted mb-3">Organisation (Admin managed)</h4>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'Role', value: user?.role },
                    { label: 'Employee ID', value: user?.employee_id || '—' },
                    { label: 'LDAP Synced', value: user?.is_ldap_synced ? 'Yes' : 'No' },
                    { label: 'Account Since', value: user?.created_at ? formatDate(user.created_at) : '—' },
                  ].map(({ label, value }) => (
                    <div key={label} className="bg-surface2 border border-border rounded-lg p-3">
                      <p className="text-xs font-mono text-muted">{label}</p>
                      <p className="text-sm font-semibold mt-0.5">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── PROFESSIONAL TAB ──────────────────────────────────────────── */}
          {tab === 'professional' && (
            <div className="card space-y-4">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-2">Professional Profile</h3>
              <Textarea label="Bio / About" placeholder="Write a short bio..." rows={3} {...register('bio')} />

              <div>
                <label className="label">Skills / Expertise (comma-separated)</label>
                <input className="input" placeholder="Python, FastAPI, React, MySQL..."
                  defaultValue={(user?.skills ?? []).join(', ')}
                  onChange={e => {
                    const val = e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    ;(register('skills') as any).onChange({ target: { value: val } })
                  }}
                />
              </div>

              <div>
                <label className="label">Certifications (comma-separated)</label>
                <input className="input" placeholder="AWS Solutions Architect, PMP..."
                  defaultValue={(user?.certifications ?? []).join(', ')}
                  onChange={e => {
                    const val = e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    ;(register('certifications') as any).onChange({ target: { value: val } })
                  }}
                />
              </div>

              <div>
                <label className="label">Languages Spoken (comma-separated)</label>
                <input className="input" placeholder="English, Tamil, Hindi..."
                  defaultValue={(user?.languages ?? []).join(', ')}
                  onChange={e => {
                    const val = e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    ;(register('languages') as any).onChange({ target: { value: val } })
                  }}
                />
              </div>

              {/* Preview chips */}
              {(user?.skills ?? []).length > 0 && (
                <div>
                  <p className="label">Current Skills</p>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {(user?.skills ?? []).map((s: string) => (
                      <span key={s} className="px-2.5 py-1 bg-accent/15 text-accent border border-accent/30 rounded-full text-xs font-mono">{s}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── SECURITY TAB ──────────────────────────────────────────────── */}
          {tab === 'security' && (
            <div className="card space-y-4">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-2">Security</h3>
              {user?.is_ldap_synced ? (
                <div className="bg-accent2/10 border border-accent2/30 rounded-xl p-4">
                  <p className="font-semibold text-accent2 text-sm mb-1">🔒 LDAP Managed Account</p>
                  <p className="text-xs font-mono text-muted">Your password is managed by your organisation's Active Directory. Please contact your IT administrator to change it.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <Input label="Current Password" type="password" placeholder="••••••••" />
                  <Input label="New Password" type="password" placeholder="Min. 8 characters" />
                  <Input label="Confirm New Password" type="password" placeholder="••••••••" />
                  <Button type="button" variant="secondary">Change Password</Button>
                </div>
              )}
              <div className="border-t border-border pt-4">
                <h4 className="text-xs font-mono uppercase tracking-widest text-muted mb-3">Active Sessions</h4>
                <div className="bg-surface2 border border-border rounded-lg p-3 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold">Current Session</p>
                    <p className="text-xs font-mono text-muted mt-0.5">This device • Active now</p>
                  </div>
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                </div>
              </div>
            </div>
          )}

          {/* Save button */}
          {tab !== 'security' && (
            <div className="mt-4 flex items-center gap-3">
              {error && <p className="text-red-400 text-sm font-mono flex-1">{error}</p>}
              <Button type="submit" loading={updateMutation.isPending} className="ml-auto">
                {saved ? '✓ Saved' : 'Save Changes'}
              </Button>
            </div>
          )}
        </form>
      </div>
    </AppLayout>
  )
}

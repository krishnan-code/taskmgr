import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { ArrowLeft, Play, Square, Plus, Trash2, MessageSquare, Clock } from 'lucide-react'
import { tasksApi, subtasksApi, timeApi } from '../api/services'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, StatusBadge, PriorityBadge, Modal, Input, Select, Textarea, Spinner, ProgressBar, EmptyState } from '../components/ui'
import { formatDate, formatTime, getApiError } from '../utils'
import type { TaskForm, SubtaskForm } from '../types'

export function TaskDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const qc = useQueryClient()

  const [editOpen, setEditOpen] = useState(false)
  const [addSubOpen, setAddSubOpen] = useState(false)
  const [activeLogId, setActiveLogId] = useState<string | null>(null)
  const [elapsed, setElapsed] = useState(0)
  const [error, setError] = useState('')
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const { data, isLoading } = useQuery({
    queryKey: ['task', id],
    queryFn: () => tasksApi.get(id!),
    enabled: !!id,
  })

  const { data: logsData } = useQuery({
    queryKey: ['timelogs', id],
    queryFn: () => timeApi.logs(id!),
    enabled: !!id,
  })

  const task = data?.data
  const logs = logsData?.data ?? []

  // ── Edit task ────────────────────────────────────────────────────────────
  const { register: regEdit, handleSubmit: handleEdit, reset: resetEdit, formState: { errors: editErrors } } = useForm<TaskForm>()

  useEffect(() => {
    if (task) {
      resetEdit({
        title: task.title,
        description: task.description ?? '',
        status: task.status,
        priority: task.priority,
        start_date: task.start_date ?? '',
        due_date: task.due_date ?? '',
        notes: task.notes ?? '',
      })
    }
  }, [task])

  const updateMutation = useMutation({
    mutationFn: (d: Partial<TaskForm>) => tasksApi.update(id!, d),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['task', id] }); qc.invalidateQueries({ queryKey: ['tasks'] }); setEditOpen(false) },
    onError: (err) => setError(getApiError(err)),
  })

  const deleteMutation = useMutation({
    mutationFn: () => tasksApi.delete(id!),
    onSuccess: () => navigate('/tasks'),
  })

  // ── Subtasks ─────────────────────────────────────────────────────────────
  const { register: regSub, handleSubmit: handleSub, reset: resetSub } = useForm<SubtaskForm>()

  const addSubMutation = useMutation({
    mutationFn: (d: SubtaskForm) => subtasksApi.create(id!, d),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['task', id] }); setAddSubOpen(false); resetSub() },
  })

  const toggleSubMutation = useMutation({
    mutationFn: ({ stId, done }: { stId: string; done: boolean }) =>
      subtasksApi.update(id!, stId, { done }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['task', id] }),
  })

  const deleteSubMutation = useMutation({
    mutationFn: (stId: string) => subtasksApi.delete(id!, stId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['task', id] }),
  })

  // ── Timer ─────────────────────────────────────────────────────────────────
  const startTimer = async () => {
    if (!id) return
    try {
      const res = await timeApi.start(id)
      setActiveLogId(res.data.id)
      setElapsed(0)
      timerRef.current = setInterval(() => setElapsed(e => e + 1), 1000)
    } catch (err) { setError(getApiError(err)) }
  }

  const stopTimer = async () => {
    if (!id || !activeLogId) return
    try {
      await timeApi.stop(id, activeLogId)
      clearInterval(timerRef.current!)
      setActiveLogId(null)
      setElapsed(0)
      qc.invalidateQueries({ queryKey: ['task', id] })
      qc.invalidateQueries({ queryKey: ['timelogs', id] })
    } catch (err) { setError(getApiError(err)) }
  }

  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current) }, [])

  if (isLoading) return <AppLayout><div className="flex justify-center items-center h-64"><Spinner size="lg" /></div></AppLayout>
  if (!task) return <AppLayout><EmptyState icon="🔍" title="Task not found" /></AppLayout>

  const doneSubs = task.subtasks.filter(s => s.done).length

  return (
    <AppLayout>
      <div className="p-8 max-w-4xl">
        {/* Back + header */}
        <button onClick={() => navigate('/tasks')} className="flex items-center gap-2 text-muted hover:text-white font-mono text-sm mb-6 transition-colors">
          <ArrowLeft size={14} /> Back to Tasks
        </button>

        <PageHeader
          title={task.title}
          actions={
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" onClick={() => setEditOpen(true)}>Edit</Button>
              <Button variant="danger" size="sm" onClick={() => { if (confirm('Delete this task?')) deleteMutation.mutate() }}>Delete</Button>
            </div>
          }
        />

        {/* Meta badges */}
        <div className="flex items-center gap-3 mb-8 flex-wrap">
          <StatusBadge status={task.status} />
          <PriorityBadge priority={task.priority} />
          {task.due_date && (
            <span className="text-xs font-mono text-muted">Due {formatDate(task.due_date)}</span>
          )}
          <span className="text-xs font-mono text-accent2">{formatTime(task.total_seconds)} logged</span>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Left column */}
          <div className="col-span-2 space-y-6">
            {/* Description */}
            {task.description && (
              <div className="card">
                <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-3">Description</h3>
                <p className="text-sm text-white/80 leading-relaxed">{task.description}</p>
              </div>
            )}

            {/* Subtasks */}
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-mono uppercase tracking-widest text-muted">
                  Subtasks ({doneSubs}/{task.subtasks.length})
                </h3>
                <Button size="sm" variant="secondary" onClick={() => setAddSubOpen(true)}>
                  <Plus size={12} /> Add
                </Button>
              </div>
              {task.subtasks.length > 0 && (
                <div className="mb-4">
                  <ProgressBar value={doneSubs} max={task.subtasks.length} />
                </div>
              )}
              <div className="space-y-2">
                {task.subtasks.length === 0 ? (
                  <p className="text-muted text-sm font-mono text-center py-4">No subtasks yet</p>
                ) : (
                  task.subtasks.map(st => (
                    <div key={st.id} className="flex items-center gap-3 p-3 rounded-lg bg-surface2 border border-transparent hover:border-border transition-colors group">
                      <input
                        type="checkbox"
                        checked={st.done}
                        onChange={e => toggleSubMutation.mutate({ stId: st.id, done: e.target.checked })}
                        className="w-4 h-4 rounded accent-emerald-500 cursor-pointer"
                      />
                      <span className={`flex-1 text-sm font-mono ${st.done ? 'line-through text-muted' : ''}`}>{st.title}</span>
                      <span className="text-xs font-mono text-accent2">{formatTime(st.total_seconds)}</span>
                      <button
                        onClick={() => deleteSubMutation.mutate(st.id)}
                        className="opacity-0 group-hover:opacity-100 text-muted hover:text-red-400 transition-all"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Time Logs */}
            <div className="card">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-4 flex items-center gap-2">
                <Clock size={12} /> Time Logs
              </h3>
              {logs.length === 0 ? (
                <p className="text-muted text-sm font-mono text-center py-4">No time entries yet</p>
              ) : (
                <div className="space-y-1">
                  {logs.slice(0, 10).map(log => (
                    <div key={log.id} className="flex items-center justify-between py-2 border-b border-border last:border-0 font-mono text-xs">
                      <span className="text-muted">{new Date(log.started_at).toLocaleString()}</span>
                      <span className="text-accent2">{formatTime(log.duration_seconds)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Notes */}
            {task.notes && (
              <div className="card">
                <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-3 flex items-center gap-2">
                  <MessageSquare size={12} /> Notes
                </h3>
                <p className="text-sm text-white/80 leading-relaxed font-mono whitespace-pre-wrap">{task.notes}</p>
              </div>
            )}
          </div>

          {/* Right column — Timer */}
          <div className="space-y-4">
            <div className="card">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-4">Time Tracker</h3>
              <div className="text-center mb-4">
                <div className="text-4xl font-extrabold font-mono text-accent2 tabular-nums">
                  {activeLogId ? formatTime(elapsed) : formatTime(task.total_seconds)}
                </div>
                <p className="text-xs text-muted font-mono mt-1">
                  {activeLogId ? 'Timer running...' : 'Total logged'}
                </p>
              </div>
              {activeLogId ? (
                <Button variant="danger" className="w-full justify-center" onClick={stopTimer}>
                  <Square size={14} /> Stop Timer
                </Button>
              ) : (
                <Button className="w-full justify-center" onClick={startTimer}>
                  <Play size={14} /> Start Timer
                </Button>
              )}
            </div>

            {/* Info card */}
            <div className="card space-y-3">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-2">Details</h3>
              {[
                { label: 'Start Date', value: formatDate(task.start_date) },
                { label: 'Due Date', value: formatDate(task.due_date) },
                { label: 'Created', value: formatDate(task.created_at) },
              ].map(({ label, value }) => (
                <div key={label}>
                  <p className="text-xs font-mono text-muted">{label}</p>
                  <p className="text-sm font-mono text-accent2">{value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      <Modal open={editOpen} onClose={() => setEditOpen(false)} title="Edit Task" size="lg">
        <form onSubmit={handleEdit(d => updateMutation.mutate(d))} className="space-y-4">
          <Input label="Title *" error={editErrors.title?.message} {...regEdit('title', { required: 'Required' })} />
          <Textarea label="Description" {...regEdit('description')} />
          <div className="grid grid-cols-2 gap-4">
            <Select label="Status" {...regEdit('status')}>
              <option value="not_started">Not Started</option>
              <option value="in_progress">In Progress</option>
              <option value="done">Done</option>
              <option value="blocked">Blocked</option>
            </Select>
            <Select label="Priority" {...regEdit('priority')}>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Start Date" type="date" {...regEdit('start_date')} />
            <Input label="Due Date" type="date" {...regEdit('due_date')} />
          </div>
          <Textarea label="Notes" {...regEdit('notes')} />
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button type="submit" loading={updateMutation.isPending}>Save Changes</Button>
          </div>
        </form>
      </Modal>

      {/* Add Subtask Modal */}
      <Modal open={addSubOpen} onClose={() => setAddSubOpen(false)} title="Add Subtask" size="sm">
        <form onSubmit={handleSub(d => addSubMutation.mutate(d))} className="space-y-4">
          <Input label="Subtask title *" placeholder="What needs to be done?" {...regSub('title', { required: 'Required' })} />
          <Input label="Due Date" type="date" {...regSub('due_date')} />
          <div className="flex justify-end gap-3">
            <Button type="button" variant="secondary" onClick={() => setAddSubOpen(false)}>Cancel</Button>
            <Button type="submit" loading={addSubMutation.isPending}>Add Subtask</Button>
          </div>
        </form>
      </Modal>
    </AppLayout>
  )
}

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { Plus, Shield, ShieldOff, Trash2, UserCog, Crown, Users } from 'lucide-react'
import { usersApi } from '../api/services'
import { useAuth } from '../context/AuthContext'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, Modal, Input, Select, Spinner, EmptyState } from '../components/ui'
import { timeAgo, getApiError } from '../utils'
import type { UserRole } from '../types'

const ROLE_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  admin:   { label: 'Admin',   color: 'text-red-400 bg-red-500/15 border-red-500/30',    icon: Crown },
  manager: { label: 'Manager', color: 'text-amber-400 bg-amber-500/15 border-amber-500/30', icon: UserCog },
  member:  { label: 'Member',  color: 'text-accent2 bg-accent2/15 border-accent2/30',    icon: Users },
}

function RoleBadge({ role }: { role: string }) {
  const cfg = ROLE_CONFIG[role] ?? ROLE_CONFIG.member
  const Icon = cfg.icon
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold font-mono border ${cfg.color}`}>
      <Icon size={10} />
      {cfg.label}
    </span>
  )
}

interface CreateUserForm {
  name: string
  email: string
  password: string
  role: UserRole
}

export function AdminPage() {
  const { user: me } = useAuth()
  const qc = useQueryClient()
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [editRoleUser, setEditRoleUser] = useState<{ id: string; name: string; role: UserRole } | null>(null)
  const [error, setError] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => usersApi.list({ limit: 100 }),
  })

  const { register, handleSubmit, reset, formState: { errors } } = useForm<CreateUserForm>({
    defaultValues: { role: 'member' },
  })

  const createMutation = useMutation({
    mutationFn: usersApi.create,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['users'] }); setShowCreateModal(false); reset() },
    onError: (err) => setError(getApiError(err)),
  })

  const roleMutation = useMutation({
    mutationFn: ({ id, role }: { id: string; role: UserRole }) => usersApi.updateRole(id, role),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['users'] }); setEditRoleUser(null) },
    onError: (err) => setError(getApiError(err)),
  })

  const statusMutation = useMutation({
    mutationFn: ({ id, is_active }: { id: string; is_active: boolean }) => usersApi.updateStatus(id, is_active),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['users'] }),
  })

  const deleteMutation = useMutation({
    mutationFn: usersApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['users'] }),
  })

  const users = data?.data ?? []
  const activeCount = users.filter(u => u.is_active).length
  const adminCount = users.filter(u => u.role === 'admin').length

  // Only admins can access this page
  if (me?.role !== 'admin') {
    return (
      <AppLayout>
        <div className="p-8 flex flex-col items-center justify-center min-h-[60vh] text-center">
          <Crown size={48} className="text-muted mb-4" />
          <h2 className="text-xl font-extrabold mb-2">Admin Access Required</h2>
          <p className="text-muted font-mono text-sm">You need admin privileges to access this page.</p>
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader
          title="Admin Panel"
          subtitle="Manage users, roles and access permissions"
          actions={
            <Button onClick={() => setShowCreateModal(true)}>
              <Plus size={14} /> Add User
            </Button>
          }
        />

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { label: 'Total Users', value: users.length, color: 'bg-accent' },
            { label: 'Active Users', value: activeCount, color: 'bg-emerald-500' },
            { label: 'Admins', value: adminCount, color: 'bg-red-500' },
          ].map(s => (
            <div key={s.label} className="card relative overflow-hidden">
              <div className={`absolute top-0 left-0 right-0 h-0.5 ${s.color}`} />
              <p className="text-xs font-mono uppercase tracking-widest text-muted mb-1">{s.label}</p>
              <p className="text-3xl font-extrabold">{s.value}</p>
            </div>
          ))}
        </div>

        {/* User Table */}
        <div className="bg-surface border border-border rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-surface2 border-b border-border">
                {['User', 'Email', 'Role', 'Status', 'Joined', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-mono uppercase tracking-widest text-muted">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={6} className="py-12 text-center"><Spinner /></td></tr>
              ) : users.length === 0 ? (
                <tr><td colSpan={6}><EmptyState icon="👥" title="No users yet" /></td></tr>
              ) : users.map(user => (
                <tr key={user.id} className="border-b border-border hover:bg-surface2 transition-colors group">
                  {/* Avatar + Name */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${user.is_active ? 'bg-accent/20 text-accent' : 'bg-muted/20 text-muted'}`}>
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-semibold text-sm flex items-center gap-2">
                          {user.name}
                          {user.id === me?.id && (
                            <span className="text-xs font-mono text-muted">(you)</span>
                          )}
                        </p>
                      </div>
                    </div>
                  </td>

                  {/* Email */}
                  <td className="px-4 py-3 font-mono text-xs text-muted">{user.email}</td>

                  {/* Role */}
                  <td className="px-4 py-3"><RoleBadge role={user.role} /></td>

                  {/* Status */}
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold border ${user.is_active ? 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30' : 'text-muted bg-muted/10 border-muted/30'}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${user.is_active ? 'bg-emerald-400' : 'bg-muted'}`} />
                      {user.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>

                  {/* Joined */}
                  <td className="px-4 py-3 font-mono text-xs text-muted">{timeAgo(user.created_at)}</td>

                  {/* Actions */}
                  <td className="px-4 py-3">
                    {user.id !== me?.id ? (
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {/* Change role */}
                        <button
                          onClick={() => setEditRoleUser({ id: user.id, name: user.name, role: user.role })}
                          className="p-1.5 rounded hover:bg-surface3 text-muted hover:text-accent transition-colors"
                          title="Change Role"
                        >
                          <UserCog size={14} />
                        </button>
                        {/* Toggle active */}
                        <button
                          onClick={() => statusMutation.mutate({ id: user.id, is_active: !user.is_active })}
                          className={`p-1.5 rounded transition-colors text-muted ${user.is_active ? 'hover:text-amber-400 hover:bg-amber-500/10' : 'hover:text-emerald-400 hover:bg-emerald-500/10'}`}
                          title={user.is_active ? 'Deactivate' : 'Activate'}
                        >
                          {user.is_active ? <ShieldOff size={14} /> : <Shield size={14} />}
                        </button>
                        {/* Delete */}
                        <button
                          onClick={() => { if (confirm(`Delete ${user.name}? This cannot be undone.`)) deleteMutation.mutate(user.id) }}
                          className="p-1.5 rounded hover:bg-red-500/10 text-muted hover:text-red-400 transition-colors"
                          title="Delete User"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ) : (
                      <span className="text-xs text-muted font-mono opacity-0 group-hover:opacity-100">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Role permissions reference */}
        <div className="mt-8 card">
          <h3 className="text-xs font-mono uppercase tracking-widest text-muted mb-4">Role Permissions</h3>
          <div className="grid grid-cols-3 gap-4">
            {Object.entries(ROLE_CONFIG).map(([role, cfg]) => {
              const Icon = cfg.icon
              const perms: Record<string, string[]> = {
                admin: ['Manage all users', 'Change roles', 'Activate/deactivate users', 'Delete users', 'Create projects', 'All task operations'],
                manager: ['View all users', 'Create projects', 'Manage all tasks', 'Assign tasks to anyone'],
                member: ['View own tasks', 'Create tasks', 'Update own tasks', 'Start/stop timers'],
              }
              return (
                <div key={role} className={`p-4 rounded-lg border ${cfg.color}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <Icon size={16} />
                    <span className="font-bold text-sm">{cfg.label}</span>
                  </div>
                  <ul className="space-y-1.5">
                    {perms[role].map(p => (
                      <li key={p} className="text-xs font-mono flex items-center gap-1.5">
                        <span className="text-[10px]">✓</span> {p}
                      </li>
                    ))}
                  </ul>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Create User Modal */}
      <Modal open={showCreateModal} onClose={() => { setShowCreateModal(false); setError(''); reset() }} title="Add New User" size="sm">
        <form onSubmit={handleSubmit(d => createMutation.mutate(d))} className="space-y-4">
          <Input label="Full Name *" placeholder="John Doe" error={errors.name?.message} {...register('name', { required: 'Required' })} />
          <Input label="Email *" type="email" placeholder="john@example.com" error={errors.email?.message} {...register('email', { required: 'Required' })} />
          <Input label="Password *" type="password" placeholder="Min. 8 characters" error={errors.password?.message}
            {...register('password', { required: 'Required', minLength: { value: 8, message: 'Min 8 chars' } })} />
          <Select label="Role" {...register('role')}>
            <option value="member">Member</option>
            <option value="manager">Manager</option>
            <option value="admin">Admin</option>
          </Select>
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowCreateModal(false)}>Cancel</Button>
            <Button type="submit" loading={createMutation.isPending}>Create User</Button>
          </div>
        </form>
      </Modal>

      {/* Change Role Modal */}
      <Modal open={!!editRoleUser} onClose={() => setEditRoleUser(null)} title="Change Role" size="sm">
        {editRoleUser && (
          <div className="space-y-4">
            <p className="text-sm text-muted font-mono">Changing role for <strong className="text-white">{editRoleUser.name}</strong></p>
            <div className="grid grid-cols-3 gap-3">
              {(['member', 'manager', 'admin'] as UserRole[]).map(role => {
                const cfg = ROLE_CONFIG[role]
                const Icon = cfg.icon
                const isSelected = editRoleUser.role === role
                return (
                  <button
                    key={role}
                    onClick={() => setEditRoleUser({ ...editRoleUser, role })}
                    className={`p-3 rounded-lg border text-left transition-all ${isSelected ? cfg.color : 'border-border bg-surface2 text-muted hover:border-muted'}`}
                  >
                    <Icon size={16} className="mb-2" />
                    <p className="text-xs font-bold">{cfg.label}</p>
                  </button>
                )
              })}
            </div>
            {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="secondary" onClick={() => setEditRoleUser(null)}>Cancel</Button>
              <Button
                loading={roleMutation.isPending}
                onClick={() => roleMutation.mutate({ id: editRoleUser.id, role: editRoleUser.role })}
              >
                Save Role
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </AppLayout>
  )
}

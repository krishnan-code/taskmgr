import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { Zap } from 'lucide-react'
import { authApi } from '../api/services'
import { useAuth } from '../context/AuthContext'
import { Button, Input } from '../components/ui'
import { getApiError } from '../utils'
import type { LoginForm } from '../types'

export function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [error, setError] = useState('')
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginForm>()

  const onSubmit = async (data: LoginForm) => {
    try {
      setError('')
      const res = await authApi.login(data)
      login(res.data.access_token, res.data.refresh_token, res.data.user)
      navigate('/dashboard')
    } catch (err) {
      setError(getApiError(err))
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center">
            <Zap size={20} className="text-white" />
          </div>
          <span className="font-extrabold text-2xl tracking-tight">Task<span className="text-accent">Flow</span></span>
        </div>

        <div className="card">
          <h2 className="text-xl font-extrabold mb-1">Welcome back</h2>
          <p className="text-muted text-sm font-mono mb-6">Sign in to your workspace</p>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              error={errors.email?.message}
              {...register('email', { required: 'Email is required' })}
            />
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              error={errors.password?.message}
              {...register('password', { required: 'Password is required' })}
            />
            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-3 text-red-400 text-sm font-mono">
                {error}
              </div>
            )}
            <Button type="submit" className="w-full justify-center" loading={isSubmitting}>
              Sign In
            </Button>
          </form>

          <p className="mt-5 text-center text-sm text-muted font-mono">
            No account?{' '}
            <Link to="/register" className="text-accent hover:text-purple-400 transition-colors">
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}

// ── Register ─────────────────────────────────────────────────────────────────
interface RegisterForm { name: string; email: string; password: string }

export function RegisterPage() {
  const navigate = useNavigate()
  const [error, setError] = useState('')
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<RegisterForm>()

  const onSubmit = async (data: RegisterForm) => {
    try {
      setError('')
      await authApi.register(data)
      navigate('/login')
    } catch (err) {
      setError(getApiError(err))
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg p-4">
      <div className="w-full max-w-sm">
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center">
            <Zap size={20} className="text-white" />
          </div>
          <span className="font-extrabold text-2xl tracking-tight">Task<span className="text-accent">Flow</span></span>
        </div>

        <div className="card">
          <h2 className="text-xl font-extrabold mb-1">Create account</h2>
          <p className="text-muted text-sm font-mono mb-6">Start tracking your work</p>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input
              label="Full Name"
              placeholder="John Doe"
              error={errors.name?.message}
              {...register('name', { required: 'Name is required' })}
            />
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              error={errors.email?.message}
              {...register('email', { required: 'Email is required' })}
            />
            <Input
              label="Password"
              type="password"
              placeholder="Min. 8 characters"
              error={errors.password?.message}
              {...register('password', { required: 'Password required', minLength: { value: 8, message: 'Min 8 characters' } })}
            />
            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-3 text-red-400 text-sm font-mono">
                {error}
              </div>
            )}
            <Button type="submit" className="w-full justify-center" loading={isSubmitting}>
              Create Account
            </Button>
          </form>

          <p className="mt-5 text-center text-sm text-muted font-mono">
            Already have an account?{' '}
            <Link to="/login" className="text-accent hover:text-purple-400 transition-colors">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}

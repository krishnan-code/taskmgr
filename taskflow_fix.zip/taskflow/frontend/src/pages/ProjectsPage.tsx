import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { Plus, FolderKanban, Trash2 } from 'lucide-react'
import { projectsApi } from '../api/services'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, Modal, Input, Textarea, Spinner, EmptyState } from '../components/ui'
import { timeAgo, getApiError } from '../utils'

export function ProjectsPage() {
  const qc = useQueryClient()
  const [showModal, setShowModal] = useState(false)
  const [error, setError] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: () => projectsApi.list({ limit: 50 }),
  })

  const { register, handleSubmit, reset, formState: { errors } } = useForm<{ name: string; description?: string }>()

  const createMutation = useMutation({
    mutationFn: projectsApi.create,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['projects'] }); setShowModal(false); reset() },
    onError: (err) => setError(getApiError(err)),
  })

  const deleteMutation = useMutation({
    mutationFn: projectsApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['projects'] }),
  })

  const projects = data?.data ?? []

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader
          title="Projects"
          subtitle={`${data?.meta?.total ?? 0} projects`}
          actions={<Button onClick={() => setShowModal(true)}><Plus size={14} /> New Project</Button>}
        />

        {isLoading ? (
          <div className="flex justify-center py-16"><Spinner size="lg" /></div>
        ) : projects.length === 0 ? (
          <EmptyState icon="📁" title="No projects yet" description="Create a project to organise your tasks" />
        ) : (
          <div className="grid grid-cols-3 gap-4">
            {projects.map(project => (
              <div key={project.id} className="card group hover:border-accent/40 transition-colors cursor-pointer relative">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center">
                    <FolderKanban size={18} className="text-accent" />
                  </div>
                  <button
                    onClick={() => { if (confirm('Delete project?')) deleteMutation.mutate(project.id) }}
                    className="opacity-0 group-hover:opacity-100 text-muted hover:text-red-400 transition-all p-1.5 rounded hover:bg-red-500/10"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
                <h3 className="font-bold text-base mb-1">{project.name}</h3>
                {project.description && (
                  <p className="text-sm text-muted font-mono mb-3 line-clamp-2">{project.description}</p>
                )}
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                  <span className="text-xs font-mono text-muted">{project.task_count} tasks</span>
                  <span className="text-xs font-mono text-muted">{timeAgo(project.created_at)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal open={showModal} onClose={() => { setShowModal(false); setError(''); reset() }} title="New Project" size="sm">
        <form onSubmit={handleSubmit(d => createMutation.mutate(d))} className="space-y-4">
          <Input label="Project Name *" placeholder="e.g. Graylog Integration" error={errors.name?.message} {...register('name', { required: 'Name is required' })} />
          <Textarea label="Description" placeholder="What is this project about?" {...register('description')} />
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="secondary" onClick={() => setShowModal(false)}>Cancel</Button>
            <Button type="submit" loading={createMutation.isPending}>Create Project</Button>
          </div>
        </form>
      </Modal>
    </AppLayout>
  )
}

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { useForm, Controller } from 'react-hook-form'
import { Plus, CheckCircle2, Clock, AlertCircle, Ban, PauseCircle, ChevronDown, ChevronRight, Users, GitBranch } from 'lucide-react'
import api from '../api/client'
import { usersApi } from '../api/services'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, Modal, Input, Select, Textarea, Spinner, EmptyState } from '../components/ui'
import { UserPicker, MultiUserPicker } from '../components/ui/UserPicker'
import { useAuth } from '../context/AuthContext'
import { getApiError, timeAgo, formatDate } from '../utils'

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any; bg: string }> = {
  not_started:        { label: 'Not Started',        color: 'text-muted',      icon: Clock,         bg: 'bg-muted/10' },
  pending_acceptance: { label: 'Pending Acceptance',  color: 'text-amber-400',  icon: Clock,         bg: 'bg-amber-500/10' },
  rejected:           { label: 'Rejected',            color: 'text-red-400',    icon: Ban,           bg: 'bg-red-500/10' },
  in_progress:        { label: 'In Progress',         color: 'text-accent',     icon: GitBranch,     bg: 'bg-accent/10' },
  blocked:            { label: 'Blocked',             color: 'text-red-400',    icon: AlertCircle,   bg: 'bg-red-500/10' },
  on_hold:            { label: 'On Hold',             color: 'text-amber-400',  icon: PauseCircle,   bg: 'bg-amber-500/10' },
  done:               { label: 'Done',                color: 'text-emerald-400',icon: CheckCircle2,  bg: 'bg-emerald-500/10' },
}

const PRIORITY_COLORS: Record<string, string> = {
  low: 'bg-muted/20 text-muted', medium: 'bg-blue-500/20 text-blue-400',
  high: 'bg-amber-500/20 text-amber-400', critical: 'bg-red-500/20 text-red-400',
}

const COLUMN_ORDER = ['not_started', 'pending_acceptance', 'in_progress', 'blocked', 'on_hold', 'done', 'rejected']

function TaskCard({ task, onClick, onAccept, onReject, currentUserId }: any) {
  const isPendingMine = task.acceptance_status === 'pending' && task.assignee_id === currentUserId
  const progress = task.subtask_count > 0 ? Math.round((task.done_subtask_count / task.subtask_count) * 100) : null

  return (
    <div onClick={() => onClick(task.id)}
      className={`p-3 rounded-xl border cursor-pointer transition-all hover:border-accent/40 hover:-translate-y-0.5 ${isPendingMine ? 'border-amber-500/50 bg-amber-500/5' : 'border-border bg-surface'}`}>
      {isPendingMine && (
        <div className="flex gap-1.5 mb-2">
          <button type="button" onClick={e => { e.stopPropagation(); onAccept(task.id) }}
            className="flex-1 py-1 text-xs font-bold rounded bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors">
            ✓ Accept
          </button>
          <button type="button" onClick={e => { e.stopPropagation(); onReject(task) }}
            className="flex-1 py-1 text-xs font-bold rounded bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors">
            ✕ Reject
          </button>
        </div>
      )}
      <p className="text-sm font-semibold line-clamp-2 mb-2">{task.title}</p>
      <div className="flex items-center gap-1.5 flex-wrap">
        <span className={`text-xs font-mono font-bold px-1.5 py-0.5 rounded ${PRIORITY_COLORS[task.priority]}`}>{task.priority}</span>
        {task.due_date && (
          <span className={`text-xs font-mono ${new Date(task.due_date) < new Date() ? 'text-red-400' : 'text-muted'}`}>
            📅 {formatDate(task.due_date)}
          </span>
        )}
        {task.is_cross_department && (
          <span className="text-xs font-mono text-accent2 bg-accent2/10 px-1.5 py-0.5 rounded">↔ cross</span>
        )}
      </div>
      {progress !== null && (
        <div className="mt-2">
          <div className="h-1 bg-surface3 rounded-full overflow-hidden">
            <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${progress}%` }} />
          </div>
          <p className="text-xs font-mono text-muted mt-0.5">{task.done_subtask_count}/{task.subtask_count} subtasks</p>
        </div>
      )}
      <div className="flex items-center justify-between mt-2">
        {task.assignee && (
          <div className="flex items-center gap-1">
            <div className="w-5 h-5 rounded-full bg-accent/20 text-accent text-xs font-bold flex items-center justify-center">
              {task.assignee.name.charAt(0)}
            </div>
            <span className="text-xs font-mono text-muted truncate max-w-[80px]">{task.assignee.name}</span>
          </div>
        )}
        {task.participant_count > 0 && (
          <span className="text-xs font-mono text-muted flex items-center gap-1 ml-auto">
            <Users size={10} /> {task.participant_count}
          </span>
        )}
      </div>
    </div>
  )
}

function LaneColumn({ status, tasks, onCardClick, onAccept, onReject, currentUserId }: any) {
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.not_started
  const Icon = cfg.icon
  return (
    <div className="flex-shrink-0 w-64">
      <div className={`flex items-center gap-2 mb-3 px-2 py-1.5 rounded-lg ${cfg.bg}`}>
        <Icon size={13} className={cfg.color} />
        <span className={`text-xs font-mono font-bold uppercase tracking-wider ${cfg.color}`}>{cfg.label}</span>
        <span className={`ml-auto text-xs font-mono font-bold ${cfg.color} opacity-60`}>{tasks.length}</span>
      </div>
      <div className="space-y-2 min-h-[80px]">
        {tasks.map((t: any) => (
          <TaskCard key={t.id} task={t} onClick={onCardClick} onAccept={onAccept} onReject={onReject} currentUserId={currentUserId} />
        ))}
      </div>
    </div>
  )
}

function SwimLane({ laneName, columns, onCardClick, onAccept, onReject, currentUserId }: any) {
  const [collapsed, setCollapsed] = useState(false)
  const total = Object.values(columns).reduce((a: any, b: any) => a + b.length, 0)
  const isCross = laneName.includes('↔')
  const isGlobal = laneName.includes('🌐')

  return (
    <div className={`mb-6 rounded-2xl border overflow-hidden ${isCross ? 'border-accent2/30' : isGlobal ? 'border-accent/30' : 'border-border'}`}>
      <button onClick={() => setCollapsed(!collapsed)}
        className={`w-full flex items-center gap-3 px-5 py-3 text-left transition-colors ${isCross ? 'bg-accent2/5 hover:bg-accent2/10' : isGlobal ? 'bg-accent/5 hover:bg-accent/10' : 'bg-surface2 hover:bg-surface3'}`}>
        {collapsed ? <ChevronRight size={14} className="text-muted" /> : <ChevronDown size={14} className="text-muted" />}
        <span className="font-bold text-sm">{laneName}</span>
        <span className="text-xs font-mono text-muted ml-1">{total} task{total !== 1 ? 's' : ''}</span>
        {isCross && <span className="ml-auto text-xs font-mono text-accent2 bg-accent2/10 px-2 py-0.5 rounded-full">Cross-Department</span>}
        {isGlobal && <span className="ml-auto text-xs font-mono text-accent bg-accent/10 px-2 py-0.5 rounded-full">All Departments</span>}
      </button>
      {!collapsed && (
        <div className="p-4 overflow-x-auto">
          <div className="flex gap-4" style={{ minWidth: `${COLUMN_ORDER.length * 272}px` }}>
            {COLUMN_ORDER.map(status => (
              <LaneColumn key={status} status={status} tasks={columns[status] || []}
                onCardClick={onCardClick} onAccept={onAccept} onReject={onReject} currentUserId={currentUserId} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export function KanbanPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [showCreate, setShowCreate] = useState(false)
  const [rejectTask, setRejectTask] = useState<any>(null)
  const [rejectReason, setRejectReason] = useState('')
  const [error, setError] = useState('')

  const { data: lanesData, isLoading } = useQuery({
    queryKey: ['kanban'],
    queryFn: () => api.get('/api/v1/tasks/kanban/lanes').then(r => r.data),
    refetchInterval: 30_000,
  })

  const { data: usersData } = useQuery({ queryKey: ['users'], queryFn: () => usersApi.list({ limit: 100 }) })
  const allUsers = usersData?.data ?? []

  const { register, handleSubmit, reset, control, formState: { errors } } = useForm({
    defaultValues: { title: '', priority: 'medium', assignee: null as any, lead: null as any, participants: [] as any[] }
  })

  const createTask = useMutation({
    mutationFn: (d: any) => api.post('/api/v1/tasks', {
      title: d.title, description: d.description, priority: d.priority,
      due_date: d.due_date || undefined,
      assignee_id: d.assignee?.id || undefined,
      lead_user_id: d.lead?.id || undefined,
      participants: (d.participants || []).map((p: any) => ({ user_id: p.id, role: p._role || 'participant' })),
    }).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['kanban'] }); setShowCreate(false); reset(); setError('') },
    onError: (e) => setError(getApiError(e)),
  })

  const acceptTask = useMutation({
    mutationFn: (id: string) => api.patch(`/api/v1/tasks/${id}/accept`, { action: 'accept' }).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['kanban'] }),
  })

  const rejectMutation = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      api.patch(`/api/v1/tasks/${id}/accept`, { action: 'reject', reason }).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['kanban'] }); setRejectTask(null); setRejectReason('') },
  })

  const lanes = lanesData?.data?.lanes ?? {}
  const pendingCount = Object.values(lanes).reduce((total: number, lane: any) => 
    total + (lane.pending_acceptance?.filter((t: any) => t.assignee_id === user?.id)?.length ?? 0), 0)

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader
          title="Kanban Board"
          subtitle={`${Object.keys(lanes).length} swim lane${Object.keys(lanes).length !== 1 ? 's' : ''}${pendingCount > 0 ? ` · ${pendingCount} pending your acceptance` : ''}`}
          actions={<Button onClick={() => setShowCreate(true)}><Plus size={14} /> New Task</Button>}
        />

        {pendingCount > 0 && (
          <div className="mb-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center gap-3">
            <span className="text-amber-400 text-xl">⏳</span>
            <div>
              <p className="text-sm font-bold text-amber-400">{pendingCount} task{pendingCount !== 1 ? 's' : ''} pending your acceptance</p>
              <p className="text-xs font-mono text-muted">Review and accept or reject below</p>
            </div>
          </div>
        )}

        {isLoading
          ? <div className="flex justify-center py-16"><Spinner size="lg" /></div>
          : Object.keys(lanes).length === 0
          ? <EmptyState icon="📋" title="No tasks yet" description="Create your first task to get started" />
          : Object.entries(lanes).map(([laneName, columns]: [string, any]) => (
            <SwimLane key={laneName} laneName={laneName} columns={columns}
              onCardClick={(id: string) => navigate(`/tasks/${id}`)}
              onAccept={(id: string) => acceptTask.mutate(id)}
              onReject={(task: any) => setRejectTask(task)}
              currentUserId={user?.id}
            />
          ))
        }
      </div>

      {/* Create Task Modal */}
      <Modal open={showCreate} onClose={() => { setShowCreate(false); reset(); setError('') }} title="Create Task" size="md">
        <form onSubmit={handleSubmit(d => createTask.mutate(d))} className="space-y-4">
          <Input label="Title *" placeholder="What needs to be done?" {...register('title', { required: 'Required' })} error={errors.title?.message} />
          <Textarea label="Description" placeholder="More details..." rows={2} {...register('description')} />
          <div className="grid grid-cols-2 gap-4">
            <Select label="Priority" {...register('priority')}>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="critical">Critical</option>
            </Select>
            <Input label="Due Date" type="date" {...register('due_date')} />
          </div>
          <Controller name="lead" control={control} render={({ field }) => (
            <UserPicker label="Task Lead" value={field.value} onChange={field.onChange} placeholder="Select lead..." />
          )} />
          <Controller name="assignee" control={control} render={({ field }) => (
            <UserPicker label="Assignee" value={field.value} onChange={field.onChange} placeholder="Assign to..." />
          )} />
          <Controller name="participants" control={control} render={({ field }) => (
            <MultiUserPicker label="Participants & Supporters" value={field.value} onChange={field.onChange} />
          )} />
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button type="submit" loading={createTask.isPending}>Create Task</Button>
          </div>
        </form>
      </Modal>

      {/* Reject Modal */}
      <Modal open={!!rejectTask} onClose={() => { setRejectTask(null); setRejectReason('') }} title="Reject Task" size="sm">
        {rejectTask && (
          <div className="space-y-4">
            <div className="bg-surface2 rounded-lg p-3">
              <p className="text-sm font-bold">{rejectTask.title}</p>
            </div>
            <Textarea
              label="Reason for rejection *"
              placeholder="Please explain why you're rejecting this task..."
              rows={3}
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
            />
            <div className="flex justify-end gap-3">
              <Button type="button" variant="secondary" onClick={() => setRejectTask(null)}>Cancel</Button>
              <Button
                loading={rejectMutation.isPending}
                disabled={!rejectReason.trim()}
                onClick={() => rejectMutation.mutate({ id: rejectTask.id, reason: rejectReason })}
                className="bg-red-500 hover:bg-red-600"
              >
                Reject Task
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </AppLayout>
  )
}

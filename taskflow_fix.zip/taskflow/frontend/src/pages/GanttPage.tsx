import { useQuery } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { addDays, differenceInDays, format, startOfDay } from 'date-fns'
import { tasksApi } from '../api/services'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Spinner, EmptyState, StatusBadge } from '../components/ui'
import type { TaskListItem } from '../types'

const STATUS_COLORS: Record<string, string> = {
  not_started: 'bg-muted/40',
  in_progress: 'bg-gradient-to-r from-accent to-accent2',
  done: 'bg-emerald-500/50',
  blocked: 'bg-red-500/40',
}

const DAY_W = 44 // px per day
const ROW_H = 48

export function GanttPage() {
  const navigate = useNavigate()

  const { data, isLoading } = useQuery({
    queryKey: ['tasks', 'gantt'],
    queryFn: () => tasksApi.list({ limit: 100 }),
  })

  const tasks = (data?.data ?? []).filter(t => t.start_date || t.due_date)

  if (isLoading) {
    return <AppLayout><div className="flex justify-center py-16"><Spinner size="lg" /></div></AppLayout>
  }

  if (tasks.length === 0) {
    return (
      <AppLayout>
        <div className="p-8">
          <PageHeader title="Gantt Chart" subtitle="Timeline view of all tasks" />
          <EmptyState icon="📅" title="No tasks with dates" description="Add start or due dates to your tasks to see them on the Gantt chart" />
        </div>
      </AppLayout>
    )
  }

  // Determine date range
  const allDates: Date[] = []
  tasks.forEach(t => {
    if (t.start_date) allDates.push(new Date(t.start_date))
    if (t.due_date) allDates.push(new Date(t.due_date))
  })
  const minDate = startOfDay(addDays(new Date(Math.min(...allDates.map(d => d.getTime()))), -2))
  const maxDate = startOfDay(addDays(new Date(Math.max(...allDates.map(d => d.getTime()))), 3))
  const totalDays = differenceInDays(maxDate, minDate) + 1
  const days = Array.from({ length: totalDays }, (_, i) => addDays(minDate, i))
  const today = startOfDay(new Date())
  const todayOffset = differenceInDays(today, minDate)

  const getBar = (task: TaskListItem) => {
    const start = task.start_date ? startOfDay(new Date(task.start_date)) : startOfDay(new Date(task.due_date!))
    const end = task.due_date ? startOfDay(new Date(task.due_date)) : start
    const left = differenceInDays(start, minDate) * DAY_W
    const width = Math.max(DAY_W, (differenceInDays(end, start) + 1) * DAY_W)
    return { left, width }
  }

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader title="Gantt Chart" subtitle={`${tasks.length} tasks with dates`} />

        <div className="card overflow-hidden p-0">
          <div className="overflow-x-auto">
            <div style={{ minWidth: 220 + totalDays * DAY_W }}>
              {/* Header */}
              <div className="flex bg-surface2 border-b border-border sticky top-0 z-10">
                <div className="w-52 flex-shrink-0 px-4 py-3 text-xs font-mono uppercase tracking-widest text-muted border-r border-border">
                  Task
                </div>
                <div className="flex">
                  {days.map((day, i) => {
                    const isToday = day.getTime() === today.getTime()
                    const isWeekend = day.getDay() === 0 || day.getDay() === 6
                    return (
                      <div
                        key={i}
                        style={{ width: DAY_W, minWidth: DAY_W }}
                        className={`text-center py-3 border-r border-border text-xs font-mono ${isToday ? 'text-accent2 font-bold' : isWeekend ? 'text-muted/50' : 'text-muted'}`}
                      >
                        <div>{format(day, 'd')}</div>
                        <div className="text-[10px]">{format(day, 'EEE')}</div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Rows */}
              {tasks.map(task => {
                const { left, width } = getBar(task)
                return (
                  <div
                    key={task.id}
                    className="flex border-b border-border hover:bg-surface2/50 transition-colors group"
                    style={{ height: ROW_H }}
                  >
                    {/* Task name */}
                    <div
                      className="w-52 flex-shrink-0 px-4 flex items-center gap-2 border-r border-border cursor-pointer"
                      onClick={() => navigate(`/tasks/${task.id}`)}
                    >
                      <span className="text-sm font-semibold truncate flex-1">{task.title}</span>
                    </div>

                    {/* Bar area */}
                    <div className="flex-1 relative" style={{ height: ROW_H }}>
                      {/* Weekend shading */}
                      {days.map((day, i) => {
                        const isWeekend = day.getDay() === 0 || day.getDay() === 6
                        return isWeekend ? (
                          <div key={i} className="absolute top-0 bottom-0 bg-white/[0.02]" style={{ left: i * DAY_W, width: DAY_W }} />
                        ) : null
                      })}

                      {/* Grid lines */}
                      {days.map((_, i) => (
                        <div key={i} className="absolute top-0 bottom-0 w-px bg-border/40" style={{ left: i * DAY_W }} />
                      ))}

                      {/* Today marker */}
                      {todayOffset >= 0 && todayOffset < totalDays && (
                        <div className="absolute top-0 bottom-0 w-0.5 bg-accent2/70 z-10" style={{ left: todayOffset * DAY_W }} />
                      )}

                      {/* Bar */}
                      <div
                        className={`absolute top-1/2 -translate-y-1/2 h-6 rounded-md cursor-pointer hover:brightness-110 transition-all flex items-center px-2 overflow-hidden ${STATUS_COLORS[task.status]}`}
                        style={{ left, width }}
                        onClick={() => navigate(`/tasks/${task.id}`)}
                        title={task.title}
                      >
                        <span className="text-white/90 text-xs font-mono font-bold truncate">{task.title}</span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-6 px-4 py-3 border-t border-border bg-surface2">
            {Object.entries({ not_started: 'Not Started', in_progress: 'In Progress', done: 'Done', blocked: 'Blocked' }).map(([k, v]) => (
              <div key={k} className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-sm ${STATUS_COLORS[k]}`} />
                <span className="text-xs font-mono text-muted">{v}</span>
              </div>
            ))}
            <div className="flex items-center gap-2">
              <div className="w-0.5 h-4 bg-accent2" />
              <span className="text-xs font-mono text-muted">Today</span>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}

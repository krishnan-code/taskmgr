import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { Plus, ChevronRight, ChevronDown, Settings, Trash2, ArrowRightLeft, ToggleLeft, ToggleRight } from 'lucide-react'
import { verticalsApi, departmentsApi, designationsApi, slaApi, type Vertical, type Department } from '../api/org'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, Modal, Input, Select, Spinner, EmptyState } from '../components/ui'
import { getApiError, timeAgo } from '../utils'

const MODULES = ['tasks', 'kanban', 'gantt', 'calendar', 'tickets'] as const
const MODULE_LABELS: Record<string, string> = { tasks: 'Tasks', kanban: 'Kanban', gantt: 'Gantt', calendar: 'Calendar', tickets: 'Tickets 🎫' }
const LEVELS = ['department', 'sub_department', 'team']

// ── Dept Tree Node ─────────────────────────────────────────────────────────
function DeptNode({ dept, verticals, onEdit, onDelete, depth = 0 }: {
  dept: Department; verticals: Vertical[]; depth?: number
  onEdit: (d: Department) => void; onDelete: (id: string) => void
}) {
  const [open, setOpen] = useState(true)
  const hasChildren = dept.children && dept.children.length > 0
  return (
    <div>
      <div className={`flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-surface2 group transition-colors ${depth > 0 ? 'ml-' + (depth * 4) : ''}`}
        style={{ paddingLeft: `${12 + depth * 20}px` }}>
        <button onClick={() => setOpen(!open)} className="text-muted w-4">
          {hasChildren ? (open ? <ChevronDown size={12} /> : <ChevronRight size={12} />) : <span className="w-3 inline-block" />}
        </button>
        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${dept.is_ticketing_enabled ? 'bg-accent2' : 'bg-muted'}`} />
        <span className="flex-1 text-sm font-semibold">{dept.name}</span>
        <span className="text-xs font-mono text-muted px-2 py-0.5 bg-surface3 rounded">{dept.level}</span>
        {dept.is_ticketing_enabled && <span className="text-xs font-mono text-accent2">🎫</span>}
        <div className="opacity-0 group-hover:opacity-100 flex gap-1">
          <button onClick={() => onEdit(dept)} className="p-1 rounded hover:bg-surface3 text-muted hover:text-accent"><Settings size={12} /></button>
          <button onClick={() => onDelete(dept.id)} className="p-1 rounded hover:bg-red-500/10 text-muted hover:text-red-400"><Trash2 size={12} /></button>
        </div>
      </div>
      {open && hasChildren && dept.children.map(child => (
        <DeptNode key={child.id} dept={child} verticals={verticals} depth={depth + 1} onEdit={onEdit} onDelete={onDelete} />
      ))}
    </div>
  )
}

export function OrgPage() {
  const qc = useQueryClient()
  const [tab, setTab] = useState<'structure' | 'designations' | 'sla'>('structure')
  const [showVerticalModal, setShowVerticalModal] = useState(false)
  const [showDeptModal, setShowDeptModal] = useState(false)
  const [editDept, setEditDept] = useState<Department | null>(null)
  const [error, setError] = useState('')

  const { data: vertData } = useQuery({ queryKey: ['verticals'], queryFn: () => verticalsApi.list({ limit: 50 }) })
  const { data: deptData, isLoading: deptsLoading } = useQuery({ queryKey: ['departments', 'tree'], queryFn: () => departmentsApi.list({ tree: true }) })
  const { data: desigData } = useQuery({ queryKey: ['designations'], queryFn: () => designationsApi.list({ limit: 50 }) })
  const { data: slaData } = useQuery({ queryKey: ['sla'], queryFn: () => slaApi.list() })

  const verticals = vertData?.data ?? []
  const departments = deptData?.data ?? []
  const designations = desigData?.data ?? []
  const slas = slaData?.data ?? []

  // Vertical form
  const { register: rv, handleSubmit: hsv, reset: rsv, formState: { errors: ev } } = useForm<{ name: string; description: string; is_ticketing_enabled: boolean }>()
  const createVertical = useMutation({
    mutationFn: verticalsApi.create,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['verticals'] }); setShowVerticalModal(false); rsv() },
    onError: (e) => setError(getApiError(e)),
  })

  // Dept form
  const { register: rd, handleSubmit: hsd, reset: rsd, setValue: sdv, formState: { errors: ed } } = useForm<{
    name: string; vertical_id: string; parent_id: string; level: string; is_ticketing_enabled: boolean
  }>({ defaultValues: { level: 'department', is_ticketing_enabled: false } })

  const createDept = useMutation({
    mutationFn: (d: any) => departmentsApi.create(d),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['departments'] }); setShowDeptModal(false); rsd() },
    onError: (e) => setError(getApiError(e)),
  })
  const updateDept = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => departmentsApi.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['departments'] }); setEditDept(null) },
    onError: (e) => setError(getApiError(e)),
  })
  const deleteDept = useMutation({
    mutationFn: departmentsApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['departments'] }),
    onError: (e) => alert(getApiError(e)),
  })
  const toggleModule = useMutation({
    mutationFn: ({ id, module, enabled }: { id: string; module: string; enabled: boolean }) =>
      departmentsApi.toggleModule(id, module, enabled),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['departments'] }),
  })

  // SLA update
  const updateSLA = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => slaApi.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sla'] }),
  })

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader title="Organisation Structure" subtitle="Manage verticals, departments, designations and SLA policies" />

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-surface2 p-1 rounded-lg w-fit">
          {(['structure', 'designations', 'sla'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 py-2 rounded-md text-sm font-semibold transition-all ${tab === t ? 'bg-accent text-white' : 'text-muted hover:text-white'}`}>
              {t === 'structure' ? '🏢 Structure' : t === 'designations' ? '👤 Designations' : '⏱ SLA Policies'}
            </button>
          ))}
        </div>

        {/* STRUCTURE TAB */}
        {tab === 'structure' && (
          <div className="grid grid-cols-3 gap-6">
            {/* Verticals */}
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-sm uppercase tracking-widest text-muted">Verticals ({verticals.length})</h3>
                <Button size="sm" onClick={() => setShowVerticalModal(true)}><Plus size={12} /> Add</Button>
              </div>
              <div className="space-y-2">
                {verticals.map(v => (
                  <div key={v.id} className="flex items-center gap-3 p-3 rounded-lg bg-surface2 hover:bg-surface3 transition-colors">
                    <div className={`w-2 h-2 rounded-full ${v.is_ticketing_enabled ? 'bg-accent2' : 'bg-muted'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{v.name}</p>
                      <p className="text-xs font-mono text-muted">{v.department_count} dept{v.department_count !== 1 ? 's' : ''}</p>
                    </div>
                    {v.is_ticketing_enabled && <span className="text-xs text-accent2 font-mono">tickets</span>}
                  </div>
                ))}
                {verticals.length === 0 && <p className="text-muted text-xs font-mono text-center py-4">No verticals yet</p>}
              </div>
            </div>

            {/* Department Tree */}
            <div className="col-span-2 card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-sm uppercase tracking-widest text-muted">Departments ({departments.reduce((a, d) => a + 1 + (d.children?.length || 0), 0)})</h3>
                <Button size="sm" onClick={() => { rsd(); setShowDeptModal(true) }}><Plus size={12} /> Add Dept</Button>
              </div>
              {deptsLoading ? <Spinner /> : departments.length === 0
                ? <EmptyState icon="🏬" title="No departments yet" description="Create verticals first, then add departments" />
                : <div className="space-y-0.5">
                    {departments.map(dept => (
                      <DeptNode key={dept.id} dept={dept} verticals={verticals}
                        onEdit={(d) => { setEditDept(d); setShowDeptModal(true); sdv('name', d.name); sdv('vertical_id', d.vertical_id); sdv('level', d.level); sdv('is_ticketing_enabled', d.is_ticketing_enabled) }}
                        onDelete={(id) => { if (confirm('Deactivate this department?')) deleteDept.mutate(id) }}
                      />
                    ))}
                  </div>
              }
            </div>
          </div>
        )}

        {/* DESIGNATIONS TAB */}
        {tab === 'designations' && (
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-sm uppercase tracking-widest text-muted">Designations ({designations.length})</h3>
            </div>
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  {['Level', 'Title', 'Type', 'Rank'].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-xs font-mono uppercase tracking-widest text-muted">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {designations.map(d => (
                  <tr key={d.id} className="border-b border-border hover:bg-surface2">
                    <td className="px-4 py-3 font-mono text-xs text-accent2">{d.level_name}</td>
                    <td className="px-4 py-3 font-semibold text-sm">{d.title}</td>
                    <td className="px-4 py-3">
                      {d.is_director_level && <span className="badge bg-red-500/15 text-red-400 border border-red-500/30">Director</span>}
                      {d.is_hod_level && <span className="badge bg-amber-500/15 text-amber-400 border border-amber-500/30">HOD</span>}
                      {!d.is_director_level && !d.is_hod_level && <span className="text-muted text-xs font-mono">Staff</span>}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-muted">Rank {d.level_rank}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* SLA TAB */}
        {tab === 'sla' && (
          <div className="card">
            <h3 className="font-bold text-sm uppercase tracking-widest text-muted mb-4">SLA Policies</h3>
            <p className="text-xs font-mono text-muted mb-4">Changes apply to new tickets only. Existing tickets keep their original SLA.</p>
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  {['Priority', 'Name', 'Response Time', 'Resolution Time'].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-xs font-mono uppercase tracking-widest text-muted">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {slas.map(s => (
                  <tr key={s.id} className="border-b border-border hover:bg-surface2">
                    <td className="px-4 py-3">
                      <span className={`badge font-mono font-bold ${s.priority === 'P1' ? 'bg-red-500/15 text-red-400' : s.priority === 'P2' ? 'bg-amber-500/15 text-amber-400' : s.priority === 'P3' ? 'bg-blue-500/15 text-blue-400' : 'bg-muted/15 text-muted'}`}>
                        {s.priority}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-semibold text-sm">{s.name}</td>
                    <td className="px-4 py-3 font-mono text-accent2 text-sm">{s.response_label}</td>
                    <td className="px-4 py-3 font-mono text-accent2 text-sm">{s.resolution_label}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Vertical Modal */}
      <Modal open={showVerticalModal} onClose={() => { setShowVerticalModal(false); setError('') }} title="Add Vertical" size="sm">
        <form onSubmit={hsv(d => createVertical.mutate(d))} className="space-y-4">
          <Input label="Name *" placeholder="e.g. Sales" error={ev.name?.message} {...rv('name', { required: 'Required' })} />
          <Input label="Description" placeholder="Brief description..." {...rv('description')} />
          <label className="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" className="w-4 h-4 rounded accent-accent2" {...rv('is_ticketing_enabled')} />
            <span className="text-sm font-mono text-muted">Enable ticketing system for this vertical</span>
          </label>
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="secondary" onClick={() => setShowVerticalModal(false)}>Cancel</Button>
            <Button type="submit" loading={createVertical.isPending}>Create Vertical</Button>
          </div>
        </form>
      </Modal>

      {/* Add/Edit Dept Modal */}
      <Modal open={showDeptModal} onClose={() => { setShowDeptModal(false); setEditDept(null); setError('') }} title={editDept ? 'Edit Department' : 'Add Department'} size="sm">
        <form onSubmit={hsd(d => editDept ? updateDept.mutate({ id: editDept.id, data: d }) : createDept.mutate(d))} className="space-y-4">
          <Input label="Name *" placeholder="e.g. Customer Service" error={ed.name?.message} {...rd('name', { required: 'Required' })} />
          <Select label="Vertical *" error={ed.vertical_id?.message} {...rd('vertical_id', { required: 'Required' })}>
            <option value="">Select vertical...</option>
            {verticals.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
          </Select>
          <Select label="Level" {...rd('level')}>
            {LEVELS.map(l => <option key={l} value={l}>{l.replace('_', ' ')}</option>)}
          </Select>
          <label className="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" className="w-4 h-4 rounded accent-accent2" {...rd('is_ticketing_enabled')} />
            <span className="text-sm font-mono text-muted">Enable ticketing for this department</span>
          </label>
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="secondary" onClick={() => { setShowDeptModal(false); setEditDept(null) }}>Cancel</Button>
            <Button type="submit" loading={createDept.isPending || updateDept.isPending}>{editDept ? 'Save Changes' : 'Create Department'}</Button>
          </div>
        </form>
      </Modal>
    </AppLayout>
  )
}

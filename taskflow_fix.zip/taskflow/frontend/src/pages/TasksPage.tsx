import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { Plus, Search, ChevronRight, Trash2 } from 'lucide-react'
import { tasksApi, projectsApi } from '../api/services'
import { AppLayout, PageHeader } from '../components/layout/AppLayout'
import { Button, StatusBadge, PriorityBadge, Modal, Input, Select, Textarea, Spinner, EmptyState, ProgressBar } from '../components/ui'
import { formatDate, formatTime, getApiError } from '../utils'
import type { TaskForm, TaskStatus, TaskPriority } from '../types'

export function TasksPage() {
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [showModal, setShowModal] = useState(false)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [priorityFilter, setPriorityFilter] = useState('')
  const [error, setError] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['tasks', statusFilter, priorityFilter],
    queryFn: () => tasksApi.list({ limit: 50, status: statusFilter || undefined, priority: priorityFilter || undefined }),
  })

  const { data: projects } = useQuery({
    queryKey: ['projects'],
    queryFn: () => projectsApi.list({ limit: 100 }),
  })

  const createMutation = useMutation({
    mutationFn: tasksApi.create,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['tasks'] }); setShowModal(false); reset() },
    onError: (err) => setError(getApiError(err)),
  })

  const deleteMutation = useMutation({
    mutationFn: tasksApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  })

  const { register, handleSubmit, reset, formState: { errors } } = useForm<TaskForm>({
    defaultValues: { status: 'not_started', priority: 'medium' },
  })

  const tasks = (data?.data ?? []).filter(t =>
    !search || t.title.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <AppLayout>
      <div className="p-8">
        <PageHeader
          title="Tasks"
          subtitle={`${data?.meta?.total ?? 0} total tasks`}
          actions={<Button onClick={() => setShowModal(true)}><Plus size={14} /> New Task</Button>}
        />

        {/* Filters */}
        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input className="input pl-9" placeholder="Search tasks..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="input w-40" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="">All Status</option>
            <option value="not_started">Not Started</option>
            <option value="in_progress">In Progress</option>
            <option value="done">Done</option>
            <option value="blocked">Blocked</option>
          </select>
          <select className="input w-36" value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)}>
            <option value="">All Priority</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>

        {/* Table */}
        <div className="bg-surface border border-border rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-surface2 border-b border-border">
                {['Task', 'Status', 'Priority', 'Progress', 'Due Date', 'Time', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-mono uppercase tracking-widest text-muted">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={7} className="py-12 text-center"><Spinner /></td></tr>
              ) : tasks.length === 0 ? (
                <tr><td colSpan={7}><EmptyState icon="📋" title="No tasks found" description="Create your first task to get started" /></td></tr>
              ) : (
                tasks.map(task => (
                  <tr key={task.id} className="border-b border-border hover:bg-surface2 cursor-pointer transition-colors group">
                    <td className="px-4 py-3" onClick={() => navigate(`/tasks/${task.id}`)}>
                      <p className="font-semibold text-sm">{task.title}</p>
                      <p className="text-xs text-muted font-mono mt-0.5">{task.subtask_count} subtasks</p>
                    </td>
                    <td className="px-4 py-3" onClick={() => navigate(`/tasks/${task.id}`)}><StatusBadge status={task.status} /></td>
                    <td className="px-4 py-3" onClick={() => navigate(`/tasks/${task.id}`)}><PriorityBadge priority={task.priority} /></td>
                    <td className="px-4 py-3 w-36" onClick={() => navigate(`/tasks/${task.id}`)}>
                      {task.subtask_count > 0
                        ? <ProgressBar value={task.subtask_done_count} max={task.subtask_count} />
                        : <span className="text-muted text-xs font-mono">—</span>}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-muted whitespace-nowrap" onClick={() => navigate(`/tasks/${task.id}`)}>{formatDate(task.due_date)}</td>
                    <td className="px-4 py-3 font-mono text-xs text-accent2" onClick={() => navigate(`/tasks/${task.id}`)}>{formatTime(task.total_seconds)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => navigate(`/tasks/${task.id}`)} className="p-1.5 rounded hover:bg-surface3 text-muted hover:text-white transition-colors"><ChevronRight size={14} /></button>
                        <button onClick={(e) => { e.stopPropagation(); if(confirm('Delete task?')) deleteMutation.mutate(task.id) }} className="p-1.5 rounded hover:bg-red-500/10 text-muted hover:text-red-400 transition-colors"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Task Modal */}
      <Modal open={showModal} onClose={() => { setShowModal(false); setError(''); reset() }} title="New Task">
        <form onSubmit={handleSubmit(d => createMutation.mutate(d))} className="space-y-4">
          <Input label="Title *" placeholder="Task title" error={errors.title?.message} {...register('title', { required: 'Title is required' })} />
          <Textarea label="Description" placeholder="What needs to be done?" {...register('description')} />
          <div className="grid grid-cols-2 gap-4">
            <Select label="Status" {...register('status')}>
              <option value="not_started">Not Started</option>
              <option value="in_progress">In Progress</option>
              <option value="done">Done</option>
              <option value="blocked">Blocked</option>
            </Select>
            <Select label="Priority" {...register('priority')}>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Start Date" type="date" {...register('start_date')} />
            <Input label="Due Date" type="date" {...register('due_date')} />
          </div>
          <Select label="Project" {...register('project_id')}>
            <option value="">No project</option>
            {(projects?.data ?? []).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
          {error && <p className="text-red-400 text-sm font-mono">{error}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowModal(false)}>Cancel</Button>
            <Button type="submit" loading={createMutation.isPending}>Create Task</Button>
          </div>
        </form>
      </Modal>
    </AppLayout>
  )
}

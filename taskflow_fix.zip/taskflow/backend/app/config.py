from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # App
    app_name: str = "TaskFlow"
    app_env: str = "development"
    debug: bool = True
    allowed_origins: str = "http://localhost:3000,http://localhost:5173"

    # Database
    database_url: str = "mysql+pymysql://taskflow_user:taskflow_pass@db:3306/taskflow"

    # JWT
    secret_key: str = "change-me-to-a-very-long-random-secret-key"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    refresh_token_expire_days: int = 7

    # Ticketing System
    ticket_system_base_url: str = ""
    ticket_system_api_key: str = ""
    ticket_webhook_secret: str = ""

    @property
    def origins_list(self) -> list[str]:
        return [o.strip() for o in self.allowed_origins.split(",")]

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

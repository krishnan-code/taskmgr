from fastapi import Query
from dataclasses import dataclass


@dataclass
class PaginationParams:
    limit: int
    offset: int


def pagination(
    limit: int = Query(default=20, ge=1, le=100, description="Number of items per page"),
    offset: int = Query(default=0, ge=0, description="Number of items to skip"),
) -> PaginationParams:
    return PaginationParams(limit=limit, offset=offset)

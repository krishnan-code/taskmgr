"""
Seed default org structure:
- 3 Verticals (Sales, Operations & Finance, Service)
- 14 Departments
- 8 Designations
- 4 SLA Policies (P1-P4)
- Default module permissions per department
"""
import logging
from sqlalchemy.orm import Session
from app.models.vertical import Vertical
from app.models.department import Department, DepartmentLevel
from app.models.designation import Designation
from app.models.sla_policy import SLAPolicy, SLAPriority
from app.models.module_permission import ModulePermission, ModuleType

logger = logging.getLogger(__name__)

VERTICALS = [
    {"name": "Sales",                   "description": "Sales, Marketing and Pre-Sales",         "is_ticketing_enabled": False},
    {"name": "Operations & Finance",    "description": "Operations, Finance and Support depts",  "is_ticketing_enabled": False},
    {"name": "Service",                 "description": "Customer-facing service and projects",   "is_ticketing_enabled": True},
]

DEPARTMENTS = [
    # Sales vertical
    {"name": "Marketing",          "vertical": "Sales",                "is_ticketing_enabled": False},
    {"name": "Sales",              "vertical": "Sales",                "is_ticketing_enabled": False},
    {"name": "Pre-Sales",          "vertical": "Sales",                "is_ticketing_enabled": False},
    # Operations & Finance vertical
    {"name": "Admin",              "vertical": "Operations & Finance", "is_ticketing_enabled": False},
    {"name": "HR",                 "vertical": "Operations & Finance", "is_ticketing_enabled": False},
    {"name": "Accounts",           "vertical": "Operations & Finance", "is_ticketing_enabled": False},
    {"name": "Logistics",          "vertical": "Operations & Finance", "is_ticketing_enabled": False},
    {"name": "Training",           "vertical": "Operations & Finance", "is_ticketing_enabled": False},
    {"name": "Purchase",           "vertical": "Operations & Finance", "is_ticketing_enabled": False},
    # Service vertical
    {"name": "Customer Service",   "vertical": "Service",             "is_ticketing_enabled": True},
    {"name": "Project - Active",   "vertical": "Service",             "is_ticketing_enabled": True},
    {"name": "Project - Passive",  "vertical": "Service",             "is_ticketing_enabled": True},
    {"name": "Project - AV/BMS",   "vertical": "Service",             "is_ticketing_enabled": True},
    {"name": "FMS",                "vertical": "Service",             "is_ticketing_enabled": True},
]

DESIGNATIONS = [
    {"title": "Director",        "level_rank": 1, "is_director_level": True,  "is_hod_level": False},
    {"title": "HOD",             "level_rank": 2, "is_director_level": False, "is_hod_level": True},
    {"title": "Senior Manager",  "level_rank": 3, "is_director_level": False, "is_hod_level": False},
    {"title": "Manager",         "level_rank": 4, "is_director_level": False, "is_hod_level": False},
    {"title": "Team Lead",       "level_rank": 5, "is_director_level": False, "is_hod_level": False},
    {"title": "Engineer",        "level_rank": 6, "is_director_level": False, "is_hod_level": False},
    {"title": "Technician",      "level_rank": 7, "is_director_level": False, "is_hod_level": False},
    {"title": "Trainee",         "level_rank": 8, "is_director_level": False, "is_hod_level": False},
]

SLA_POLICIES = [
    {"name": "Critical", "priority": SLAPriority.P1, "response_minutes": 15,   "resolution_minutes": 240},
    {"name": "High",     "priority": SLAPriority.P2, "response_minutes": 60,   "resolution_minutes": 480},
    {"name": "Medium",   "priority": SLAPriority.P3, "response_minutes": 240,  "resolution_minutes": 1440},
    {"name": "Low",      "priority": SLAPriority.P4, "response_minutes": 480,  "resolution_minutes": 4320},
]


def seed_org_structure(db: Session):
    """Run seed only if tables are empty."""

    # ── Verticals ─────────────────────────────────────────────────────────────
    if db.query(Vertical).count() == 0:
        logger.info("🌱 Seeding verticals...")
        vertical_map = {}
        for v_data in VERTICALS:
            v = Vertical(**v_data)
            db.add(v)
            db.flush()
            vertical_map[v.name] = v.id
        db.commit()
        logger.info(f"   ✅ Created {len(VERTICALS)} verticals")
    else:
        vertical_map = {v.name: v.id for v in db.query(Vertical).all()}

    # ── Departments ───────────────────────────────────────────────────────────
    if db.query(Department).count() == 0:
        logger.info("🌱 Seeding departments...")
        dept_map = {}
        for i, d_data in enumerate(DEPARTMENTS):
            vertical_id = vertical_map.get(d_data["vertical"])
            if not vertical_id:
                logger.warning(f"   ⚠️  Vertical '{d_data['vertical']}' not found, skipping {d_data['name']}")
                continue
            dept = Department(
                name=d_data["name"],
                vertical_id=vertical_id,
                level=DepartmentLevel.department,
                is_ticketing_enabled=d_data["is_ticketing_enabled"],
                sort_order=i,
            )
            db.add(dept)
            db.flush()
            dept_map[dept.name] = dept.id

            # Auto-create module permissions
            for module in ModuleType:
                is_enabled = True
                if module == ModuleType.tickets:
                    is_enabled = d_data["is_ticketing_enabled"]
                mp = ModulePermission(department_id=dept.id, module=module, is_enabled=is_enabled)
                db.add(mp)

        db.commit()
        logger.info(f"   ✅ Created {len(DEPARTMENTS)} departments with module permissions")
    else:
        logger.info("   ⏭️  Departments already exist, skipping")

    # ── Designations ──────────────────────────────────────────────────────────
    if db.query(Designation).count() == 0:
        logger.info("🌱 Seeding designations...")
        for d_data in DESIGNATIONS:
            d = Designation(**d_data)
            db.add(d)
        db.commit()
        logger.info(f"   ✅ Created {len(DESIGNATIONS)} designations")
    else:
        logger.info("   ⏭️  Designations already exist, skipping")

    # ── SLA Policies ──────────────────────────────────────────────────────────
    if db.query(SLAPolicy).count() == 0:
        logger.info("🌱 Seeding SLA policies...")
        for s_data in SLA_POLICIES:
            s = SLAPolicy(**s_data)
            db.add(s)
        db.commit()
        logger.info(f"   ✅ Created {len(SLA_POLICIES)} SLA policies (P1-P4)")
    else:
        logger.info("   ⏭️  SLA policies already exist, skipping")

    logger.info("✅ Org structure seed complete")

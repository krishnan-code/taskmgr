import time
import logging
import uuid
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

logger = logging.getLogger("taskflow.access")


class LoggingMiddleware(BaseHTTPMiddleware):
    """
    Logs every HTTP request with:
    - Request ID (X-Request-ID header)
    - Method + path + query string
    - Client IP
    - Response status code
    - Duration in ms
    """

    def __init__(self, app: ASGIApp):
        super().__init__(app)

    async def dispatch(self, request: Request, call_next) -> Response:
        # Generate or inherit a request ID for tracing
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:8])
        start_time = time.perf_counter()

        # Log incoming request
        client_ip = request.client.host if request.client else "unknown"
        query = f"?{request.url.query}" if request.url.query else ""
        logger.info(
            f"[{request_id}] ▶ {request.method} {request.url.path}{query} "
            f"from {client_ip}"
        )

        # Process the request
        try:
            response = await call_next(request)
        except Exception as exc:
            duration_ms = (time.perf_counter() - start_time) * 1000
            logger.error(
                f"[{request_id}] ✗ {request.method} {request.url.path} "
                f"FAILED in {duration_ms:.1f}ms — {exc}"
            )
            raise

        duration_ms = (time.perf_counter() - start_time) * 1000
        status = response.status_code

        # Choose log level based on status code
        if status >= 500:
            log_fn = logger.error
            icon = "✗"
        elif status >= 400:
            log_fn = logger.warning
            icon = "⚠"
        else:
            log_fn = logger.info
            icon = "✔"

        log_fn(
            f"[{request_id}] {icon} {request.method} {request.url.path}{query} "
            f"→ {status} in {duration_ms:.1f}ms"
        )

        # Attach request ID to response headers for debugging
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Process-Time"] = f"{duration_ms:.1f}ms"
        return response


def setup_logging(log_level: str = "INFO"):
    """Configure structured logging for the entire application."""
    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # Quiet down noisy SQLAlchemy logs unless in DEBUG
    if log_level.upper() != "DEBUG":
        logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)  # We handle access logs ourselves

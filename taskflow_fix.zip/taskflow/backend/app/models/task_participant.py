from sqlalchemy import Column, String, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class ParticipantRole(str, enum.Enum):
    lead        = "lead"        # Single accountable owner
    participant = "participant" # Actively working on task
    supporter   = "supporter"  # Cross-dept resource helping out


class TaskParticipant(Base):
    __tablename__ = "task_participants"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    role = Column(Enum(ParticipantRole), nullable=False, default=ParticipantRole.participant)
    source_department_id = Column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    added_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    task = relationship("Task", back_populates="participants", foreign_keys=[task_id])
    user = relationship("User", foreign_keys=[user_id])
    source_department = relationship("Department", foreign_keys=[source_department_id])
    added_by_user = relationship("User", foreign_keys=[added_by])

    def __repr__(self):
        return f"<TaskParticipant task={self.task_id} user={self.user_id} role={self.role}>"

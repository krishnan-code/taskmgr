from sqlalchemy import Column, String, Text, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class AcceptanceAction(str, enum.Enum):
    assigned = "assigned"
    accepted = "accepted"
    rejected = "rejected"
    pending  = "pending"


class TaskAcceptanceLog(Base):
    __tablename__ = "task_acceptance_logs"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    from_user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    to_user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    action = Column(Enum(AcceptanceAction), nullable=False)
    reason = Column(Text, nullable=True)  # Required on rejection
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    task = relationship("Task", foreign_keys=[task_id])
    from_user = relationship("User", foreign_keys=[from_user_id])
    to_user = relationship("User", foreign_keys=[to_user_id])

    def __repr__(self):
        return f"<TaskAcceptanceLog task={self.task_id} action={self.action}>"

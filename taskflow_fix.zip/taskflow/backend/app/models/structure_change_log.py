from sqlalchemy import Column, String, Text, DateTime
from sqlalchemy.sql import func
import uuid
from app.database import Base


class StructureChangeLog(Base):
    """Audit trail for all org structure changes."""
    __tablename__ = "structure_change_log"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    entity_type = Column(String(50), nullable=False)   # vertical/department/designation/group/user
    entity_id = Column(String(36), nullable=False, index=True)
    action = Column(String(50), nullable=False)        # created/updated/deleted/transferred/restored
    changed_by_id = Column(String(36), nullable=True)
    old_value = Column(Text, nullable=True)            # JSON snapshot before
    new_value = Column(Text, nullable=True)            # JSON snapshot after
    note = Column(Text, nullable=True)
    changed_at = Column(DateTime(timezone=True), server_default=func.now())

    def __repr__(self):
        return f"<StructureChangeLog {self.entity_type} {self.action}>"

from sqlalchemy import Column, String, Text, Boolean, Integer, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class DepartmentLevel(str, enum.Enum):
    department = "department"
    sub_department = "sub_department"
    team = "team"


class Department(Base):
    __tablename__ = "departments"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(150), nullable=False)
    vertical_id = Column(String(36), ForeignKey("verticals.id", ondelete="CASCADE"), nullable=False, index=True)
    parent_id = Column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True, index=True)
    level = Column(Enum(DepartmentLevel), default=DepartmentLevel.department, nullable=False)
    head_user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    is_ticketing_enabled = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    vertical = relationship("Vertical", back_populates="departments")
    parent = relationship("Department", remote_side="Department.id", backref="children")
    head = relationship("User", foreign_keys=[head_user_id])
    module_permissions = relationship("ModulePermission", back_populates="department", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Department {self.name}>"

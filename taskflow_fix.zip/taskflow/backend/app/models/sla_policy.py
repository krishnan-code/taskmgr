from sqlalchemy import Column, String, Integer, Boolean, DateTime, Enum
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class SLAPriority(str, enum.Enum):
    P1 = "P1"  # Critical  - 15min response / 4h resolution
    P2 = "P2"  # High      - 1h response   / 8h resolution
    P3 = "P3"  # Medium    - 4h response   / 24h resolution
    P4 = "P4"  # Low       - 8h response   / 72h resolution


class SLAPolicy(Base):
    __tablename__ = "sla_policies"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False)
    priority = Column(Enum(SLAPriority), nullable=False, unique=True)
    response_minutes = Column(Integer, nullable=False)    # First response SLA
    resolution_minutes = Column(Integer, nullable=False)  # Full resolution SLA
    pause_on_holidays = Column(Boolean, default=True, nullable=False)
    working_hours_start = Column(String(10), nullable=True, default="09:00")  # e.g. 09:00
    working_hours_end = Column(String(10), nullable=True, default="18:00")    # e.g. 18:00
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    def __repr__(self):
        return f"<SLAPolicy {self.priority} {self.name}>"

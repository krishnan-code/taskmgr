from sqlalchemy import Column, String, Text, Boolean, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum
from app.database import Base


class ServiceType(str, enum.Enum):
    amc = "amc"
    fms = "fms"
    service = "service"
    other = "other"


class Customer(Base):
    """
    Separate customer accounts maintained in the ticketing system.
    Customers have their own login and can raise/view tickets.
    """
    __tablename__ = "customers"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(200), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    phone = Column(String(30), nullable=True)
    company = Column(String(200), nullable=True)
    address = Column(Text, nullable=True)
    service_type = Column(Enum(ServiceType), default=ServiceType.service, nullable=False)
    contract_number = Column(String(100), nullable=True)
    account_manager_id = Column(String(36), nullable=True)  # FK to internal user
    is_active = Column(Boolean, default=True, nullable=False)
    is_deleted = Column(Boolean, default=False, nullable=False)
    last_login_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    def __repr__(self):
        return f"<Customer {self.name} ({self.email})>"

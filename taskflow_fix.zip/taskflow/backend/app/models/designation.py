from sqlalchemy import Column, String, Integer, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from app.database import Base


class Designation(Base):
    __tablename__ = "designations"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(150), nullable=False)
    department_id = Column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True, index=True)
    # 1=Director, 2=HOD, 3=Manager(senior), 4=Manager, 5=TeamLead, 6=Engineer, 7=Technician, 8=Trainee
    level_rank = Column(Integer, nullable=False)
    is_hod_level = Column(Boolean, default=False)
    is_director_level = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    department = relationship("Department", foreign_keys=[department_id])

    def __repr__(self):
        return f"<Designation {self.title} rank={self.level_rank}>"

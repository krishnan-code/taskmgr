from sqlalchemy import Column, String, Boolean, Text, Date, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class HolidayType(str, enum.Enum):
    global_holiday = "global"    # Applies to all branches
    local_holiday  = "local"     # Applies to specific branch only


class Holiday(Base):
    __tablename__ = "holidays"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(150), nullable=False)
    date = Column(Date, nullable=False, index=True)
    holiday_type = Column(Enum(HolidayType), nullable=False, default=HolidayType.global_holiday)
    branch_id = Column(String(36), ForeignKey("branches.id", ondelete="CASCADE"), nullable=True, index=True)
    description = Column(Text, nullable=True)
    is_recurring = Column(Boolean, default=True, nullable=False)  # Auto-repeat yearly
    is_active = Column(Boolean, default=True, nullable=False)
    created_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    branch = relationship("Branch", back_populates="holidays")
    creator = relationship("User", foreign_keys=[created_by])

    def __repr__(self):
        return f"<Holiday {self.name} {self.date}>"

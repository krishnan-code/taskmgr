from sqlalchemy import Column, String, Boolean, Enum, DateTime, ForeignKey, Date, Text, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class UserRole(str, enum.Enum):
    admin = "admin"
    director = "director"
    hod = "hod"
    manager = "manager"
    member = "member"


class EmploymentType(str, enum.Enum):
    full_time = "full_time"
    contract = "contract"
    intern = "intern"


class WorkLocation(str, enum.Enum):
    office = "office"
    remote = "remote"
    hybrid = "hybrid"


class Gender(str, enum.Enum):
    male = "male"
    female = "female"
    other = "other"
    prefer_not_to_say = "prefer_not_to_say"


class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=True)  # nullable for LDAP users
    role = Column(Enum(UserRole), default=UserRole.member, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    # ── Org fields ────────────────────────────────────────────────────────────
    branch_id = Column(String(36), ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    employee_id = Column(String(50), nullable=True, unique=True)
    job_title = Column(String(150), nullable=True)
    department_id = Column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True, index=True)
    designation_id = Column(String(36), ForeignKey("designations.id", ondelete="SET NULL"), nullable=True)
    reporting_manager_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    reporting_head_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    hod_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    is_hod = Column(Boolean, default=False)
    is_director = Column(Boolean, default=False)

    # ── Personal fields ───────────────────────────────────────────────────────
    phone_number = Column(String(20), nullable=True)
    mobile_number = Column(String(20), nullable=True)
    date_of_birth = Column(Date, nullable=True)
    gender = Column(Enum(Gender), nullable=True)
    address = Column(Text, nullable=True)
    emergency_contact_name = Column(String(100), nullable=True)
    emergency_contact_phone = Column(String(20), nullable=True)
    emergency_contact_relation = Column(String(50), nullable=True)
    profile_photo_url = Column(String(500), nullable=True)
    blood_group = Column(String(10), nullable=True)  # A+, B+, O+, AB+, A-, B-, O-, AB-

    # ── Employment fields ─────────────────────────────────────────────────────
    date_of_joining = Column(Date, nullable=True)
    employment_type = Column(Enum(EmploymentType), nullable=True)
    work_location = Column(Enum(WorkLocation), nullable=True)
    shift_timing = Column(String(100), nullable=True)   # e.g. "9:00 AM - 6:00 PM"
    probation_end_date = Column(Date, nullable=True)
    last_working_date = Column(Date, nullable=True)

    # ── Professional fields ───────────────────────────────────────────────────
    skills = Column(JSON, nullable=True)         # ["Python", "FastAPI", "React"]
    certifications = Column(JSON, nullable=True) # ["AWS Solutions Architect", "PMP"]
    languages = Column(JSON, nullable=True)      # ["English", "Tamil", "Hindi"]
    bio = Column(Text, nullable=True)

    # ── LDAP fields (future) ──────────────────────────────────────────────────
    is_ldap_synced = Column(Boolean, default=False)
    ldap_dn = Column(String(500), nullable=True)
    ldap_username = Column(String(100), nullable=True)
    last_ldap_sync = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # ── Relationships ─────────────────────────────────────────────────────────
    branch = relationship("Branch", back_populates="users", foreign_keys="User.branch_id")
    department = relationship("Department", foreign_keys=[department_id])
    designation = relationship("Designation", foreign_keys=[designation_id])
    reporting_manager = relationship("User", foreign_keys=[reporting_manager_id], remote_side="User.id")
    reporting_head = relationship("User", foreign_keys=[reporting_head_id], remote_side="User.id")
    hod = relationship("User", foreign_keys=[hod_id], remote_side="User.id")
    assigned_tasks = relationship("Task", back_populates="assignee", foreign_keys="Task.assignee_id")
    owned_projects = relationship("Project", back_populates="owner")
    time_logs = relationship("TimeLog", back_populates="user")
    comments = relationship("Comment", back_populates="author")

    def __repr__(self):
        return f"<User {self.email}>"

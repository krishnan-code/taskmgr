from sqlalchemy import Column, String, Boolean, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class ModuleType(str, enum.Enum):
    tasks = "tasks"
    kanban = "kanban"
    gantt = "gantt"
    calendar = "calendar"
    tickets = "tickets"


class ModulePermission(Base):
    __tablename__ = "module_permissions"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    department_id = Column(String(36), ForeignKey("departments.id", ondelete="CASCADE"), nullable=False, index=True)
    module = Column(Enum(ModuleType), nullable=False)
    is_enabled = Column(Boolean, default=True, nullable=False)
    updated_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    department = relationship("Department", back_populates="module_permissions")

    def __repr__(self):
        return f"<ModulePermission dept={self.department_id} module={self.module} enabled={self.is_enabled}>"

from sqlalchemy import Column, String, Text, Enum, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum

from app.database import Base


class TicketStatus(str, enum.Enum):
    open = "open"
    in_progress = "in_progress"
    resolved = "resolved"
    closed = "closed"


class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    external_ticket_id = Column(String(200), nullable=False)  # ID from your ticket system
    external_url = Column(String(500), nullable=True)         # Link to ticket in external system
    title = Column(String(300), nullable=True)
    status = Column(Enum(TicketStatus), default=TicketStatus.open, nullable=False)
    priority = Column(String(50), nullable=True)
    reporter = Column(String(200), nullable=True)
    extra_data = Column(Text, nullable=True)                  # JSON blob for custom fields
    synced_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationship
    task = relationship("Task", back_populates="tickets")

    def __repr__(self):
        return f"<Ticket {self.external_ticket_id} -> task={self.task_id}>"

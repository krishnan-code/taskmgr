from sqlalchemy import Column, String, Text, Boolean, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class NotificationType(str, enum.Enum):
    task_assigned = "task_assigned"
    task_accepted = "task_accepted"
    task_rejected = "task_rejected"
    task_due_soon = "task_due_soon"
    task_overdue = "task_overdue"
    ticket_assigned = "ticket_assigned"
    ticket_comment = "ticket_comment"
    ticket_escalated = "ticket_escalated"
    sla_warning = "sla_warning"
    sla_breached = "sla_breached"
    group_added = "group_added"
    general = "general"


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    type = Column(Enum(NotificationType), nullable=False)
    title = Column(String(255), nullable=False)
    body = Column(Text, nullable=True)
    reference_type = Column(String(50), nullable=True)   # "task" | "ticket" | "group"
    reference_id = Column(String(36), nullable=True)
    is_read = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", foreign_keys=[user_id])

    def __repr__(self):
        return f"<Notification {self.type} user={self.user_id}>"

from sqlalchemy import Column, String, Boolean, Text, Date, ForeignKey, DateTime, Enum, Integer
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid, enum
from app.database import Base


class TaskStatus(str, enum.Enum):
    not_started = "not_started"
    pending_acceptance = "pending_acceptance"
    accepted = "accepted"
    rejected = "rejected"
    in_progress = "in_progress"
    blocked = "blocked"
    on_hold = "on_hold"
    done = "done"


class TaskPriority(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class AcceptanceStatus(str, enum.Enum):
    not_required = "not_required"
    pending = "pending"
    accepted = "accepted"
    rejected = "rejected"


class ParticipantRole(str, enum.Enum):
    lead = "lead"
    participant = "participant"
    supporter = "supporter"


class Task(Base):
    __tablename__ = "tasks"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(300), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(Enum(TaskStatus), default=TaskStatus.not_started, nullable=False)
    priority = Column(Enum(TaskPriority), default=TaskPriority.medium, nullable=False)
    start_date = Column(Date, nullable=True)
    due_date = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)

    # Ownership
    project_id = Column(String(36), ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True)
    assignee_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    lead_user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

    # Org context
    department_id = Column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True, index=True)
    vertical_id = Column(String(36), ForeignKey("verticals.id", ondelete="SET NULL"), nullable=True)
    is_all_departments = Column(Boolean, default=False)
    is_cross_department = Column(Boolean, default=False)
    group_id = Column(String(36), ForeignKey("groups.id", ondelete="SET NULL"), nullable=True)

    # Acceptance workflow
    acceptance_status = Column(Enum(AcceptanceStatus), default=AcceptanceStatus.not_required, nullable=False)
    accepted_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    accepted_at = Column(DateTime(timezone=True), nullable=True)
    rejection_reason = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    project = relationship("Project", back_populates="tasks")
    assignee = relationship("User", foreign_keys=[assignee_id], back_populates="assigned_tasks")
    lead = relationship("User", foreign_keys=[lead_user_id])
    creator = relationship("User", foreign_keys=[created_by])
    accepted_by_user = relationship("User", foreign_keys=[accepted_by])
    department = relationship("Department", foreign_keys=[department_id])
    vertical = relationship("Vertical", foreign_keys=[vertical_id])
    group = relationship("Group", foreign_keys=[group_id])
    subtasks = relationship("Subtask", back_populates="task", cascade="all, delete-orphan")
    time_logs = relationship("TimeLog", back_populates="task", cascade="all, delete-orphan")
    comments = relationship("Comment", back_populates="task", cascade="all, delete-orphan")
    participants = relationship("TaskParticipant", back_populates="task", cascade="all, delete-orphan")
    acceptance_logs = relationship("TaskAcceptanceLog", back_populates="task", cascade="all, delete-orphan")


class Subtask(Base):
    __tablename__ = "subtasks"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(300), nullable=False)
    done = Column(Boolean, default=False, nullable=False)
    task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    assignee_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    due_date = Column(Date, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    task = relationship("Task", back_populates="subtasks")
    assignee = relationship("User", foreign_keys=[assignee_id])


class TaskParticipant(Base):
    __tablename__ = "task_participants"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    role = Column(Enum(ParticipantRole), default=ParticipantRole.participant, nullable=False)
    source_department_id = Column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    added_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    task = relationship("Task", back_populates="participants")
    user = relationship("User", foreign_keys=[user_id])
    source_department = relationship("Department", foreign_keys=[source_department_id])


class TaskAcceptanceLog(Base):
    __tablename__ = "task_acceptance_logs"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    from_user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    to_user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    action = Column(String(50), nullable=False)  # assigned/accepted/rejected
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    task = relationship("Task", back_populates="acceptance_logs")
    from_user = relationship("User", foreign_keys=[from_user_id])
    to_user = relationship("User", foreign_keys=[to_user_id])

from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime
from app.models.task import TaskStatus, TaskPriority, AcceptanceStatus
from app.models.task_participant import ParticipantRole


class ParticipantOut(BaseModel):
    id: str
    user_id: str
    role: ParticipantRole
    user_name: str = ""
    user_email: str = ""
    user_avatar: str = ""
    department_name: str = ""


class SubtaskCreate(BaseModel):
    title: str
    assignee_id: Optional[str] = None
    due_date: Optional[date] = None


class SubtaskUpdate(BaseModel):
    title: Optional[str] = None
    done: Optional[bool] = None
    assignee_id: Optional[str] = None
    due_date: Optional[date] = None


class SubtaskOut(BaseModel):
    id: str
    title: str
    done: bool
    task_id: str
    assignee_id: Optional[str]
    due_date: Optional[date]
    created_at: datetime
    total_seconds: int = 0
    model_config = {"from_attributes": True}


class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    status: TaskStatus = TaskStatus.not_started
    priority: TaskPriority = TaskPriority.medium
    start_date: Optional[date] = None
    due_date: Optional[date] = None
    project_id: Optional[str] = None
    assignee_id: Optional[str] = None
    department_id: Optional[str] = None
    group_id: Optional[str] = None
    is_all_departments: bool = False
    notes: Optional[str] = None
    participant_ids: Optional[List[str]] = []   # Additional participants
    supporter_ids: Optional[List[str]] = []     # Cross-dept supporters


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[TaskStatus] = None
    priority: Optional[TaskPriority] = None
    start_date: Optional[date] = None
    due_date: Optional[date] = None
    project_id: Optional[str] = None
    assignee_id: Optional[str] = None
    department_id: Optional[str] = None
    notes: Optional[str] = None


class TaskOut(BaseModel):
    id: str
    title: str
    description: Optional[str]
    status: TaskStatus
    priority: TaskPriority
    start_date: Optional[date]
    due_date: Optional[date]
    project_id: Optional[str]
    assignee_id: Optional[str]
    assignee_name: Optional[str] = None
    department_id: Optional[str]
    department_name: Optional[str] = None
    is_all_departments: bool = False
    is_cross_department: bool = False
    acceptance_status: AcceptanceStatus
    rejection_reason: Optional[str] = None
    accepted_at: Optional[datetime] = None
    group_id: Optional[str] = None
    notes: Optional[str]
    created_at: datetime
    updated_at: Optional[datetime]
    subtasks: List[SubtaskOut] = []
    participants: List[ParticipantOut] = []
    total_seconds: int = 0
    model_config = {"from_attributes": True}


class TaskListOut(BaseModel):
    id: str
    title: str
    status: TaskStatus
    priority: TaskPriority
    start_date: Optional[date] = None
    due_date: Optional[date]
    assignee_id: Optional[str]
    assignee_name: Optional[str] = None
    project_id: Optional[str]
    department_id: Optional[str] = None
    is_cross_department: bool = False
    is_all_departments: bool = False
    acceptance_status: AcceptanceStatus = AcceptanceStatus.not_required
    subtask_count: int = 0
    subtask_done_count: int = 0
    participant_count: int = 0
    total_seconds: int = 0
    created_at: datetime
    model_config = {"from_attributes": True}

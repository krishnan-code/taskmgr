from pydantic import BaseModel
from typing import TypeVar, Generic, Optional, List, Any

T = TypeVar("T")


class PaginationMeta(BaseModel):
    total: int
    limit: int
    offset: int
    has_next: bool
    has_prev: bool


class ApiResponse(BaseModel, Generic[T]):
    """Standard single-item response envelope."""
    success: bool = True
    message: str = "OK"
    data: Optional[T] = None


class PaginatedResponse(BaseModel, Generic[T]):
    """Standard paginated list response envelope."""
    success: bool = True
    message: str = "OK"
    data: List[T]
    meta: PaginationMeta


class ErrorDetail(BaseModel):
    field: Optional[str] = None
    message: str


class ErrorResponse(BaseModel):
    """Standard error response envelope."""
    success: bool = False
    message: str
    errors: Optional[List[ErrorDetail]] = None


# ── Helper factories ──────────────────────────────────────────────────────────

def ok(data: Any = None, message: str = "OK") -> dict:
    return {"success": True, "message": message, "data": data}


def paginated(data: List, total: int, limit: int, offset: int, message: str = "OK") -> dict:
    return {
        "success": True,
        "message": message,
        "data": data,
        "meta": {
            "total": total,
            "limit": limit,
            "offset": offset,
            "has_next": offset + limit < total,
            "has_prev": offset > 0,
        },
    }

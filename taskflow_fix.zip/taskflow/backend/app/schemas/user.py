from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional, List
from datetime import datetime, date
from app.models.user import UserRole, EmploymentType, WorkLocation, Gender


# ── Shared profile fields ─────────────────────────────────────────────────────
class UserProfileUpdate(BaseModel):
    # Personal
    phone_number: Optional[str] = None
    mobile_number: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[Gender] = None
    address: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    emergency_contact_relation: Optional[str] = None
    profile_photo_url: Optional[str] = None
    blood_group: Optional[str] = None

    # Employment
    date_of_joining: Optional[date] = None
    employment_type: Optional[EmploymentType] = None
    work_location: Optional[WorkLocation] = None
    shift_timing: Optional[str] = None
    probation_end_date: Optional[date] = None
    last_working_date: Optional[date] = None

    # Professional
    skills: Optional[List[str]] = None
    certifications: Optional[List[str]] = None
    languages: Optional[List[str]] = None
    bio: Optional[str] = None

    # Org (admin only)
    job_title: Optional[str] = None
    department_id: Optional[str] = None
    designation_id: Optional[str] = None
    reporting_manager_id: Optional[str] = None
    reporting_head_id: Optional[str] = None
    hod_id: Optional[str] = None
    is_hod: Optional[bool] = None
    is_director: Optional[bool] = None


class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: UserRole = UserRole.member

    @field_validator("password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    role: UserRole
    is_active: bool

    # Org
    branch_id: Optional[str] = None
    employee_id: Optional[str] = None
    job_title: Optional[str] = None
    department_id: Optional[str] = None
    designation_id: Optional[str] = None
    reporting_manager_id: Optional[str] = None
    reporting_head_id: Optional[str] = None
    hod_id: Optional[str] = None
    is_hod: bool = False
    is_director: bool = False

    # Personal
    phone_number: Optional[str] = None
    mobile_number: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[Gender] = None
    address: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    emergency_contact_relation: Optional[str] = None
    profile_photo_url: Optional[str] = None
    blood_group: Optional[str] = None

    # Employment
    date_of_joining: Optional[date] = None
    employment_type: Optional[EmploymentType] = None
    work_location: Optional[WorkLocation] = None
    shift_timing: Optional[str] = None
    probation_end_date: Optional[date] = None
    last_working_date: Optional[date] = None

    # Professional
    skills: Optional[List[str]] = None
    certifications: Optional[List[str]] = None
    languages: Optional[List[str]] = None
    bio: Optional[str] = None

    # LDAP
    is_ldap_synced: bool = False

    created_at: datetime

    model_config = {"from_attributes": True}


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: UserOut


class RefreshRequest(BaseModel):
    refresh_token: str

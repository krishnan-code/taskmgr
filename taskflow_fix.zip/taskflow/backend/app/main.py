from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import time
import logging
import os

from sqlalchemy import text
from app.config import settings
from app.database import engine, Base, SessionLocal

import app.models  # noqa — registers all models

from app.utils.error_handlers import register_error_handlers
from app.utils.logging_middleware import LoggingMiddleware, setup_logging
from app.utils.rate_limit import limiter, rate_limit_exceeded_handler
from app.utils.seed import seed_org_structure
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

# ── Routers ───────────────────────────────────────────────────────────────────
from app.routers.auth          import router as auth_router
from app.routers.users         import router as users_router
from app.routers.verticals     import router as verticals_router
from app.routers.departments   import router as departments_router
from app.routers.designations  import router as designations_router
from app.routers.groups        import router as groups_router
from app.routers.sla_policies  import router as sla_router
from app.routers.notifications import router as notifications_router
from app.routers.branches      import router as branches_router
from app.routers.holidays      import router as holidays_router
from app.routers.projects      import router as projects_router
from app.routers.tasks         import router as tasks_router
from app.routers.time_logs     import router as time_logs_router
from app.routers.tickets       import router as tickets_router
from app.routers.comments      import router as comments_router

logger = logging.getLogger(__name__)
setup_logging(log_level="DEBUG" if settings.debug else "INFO")


def wait_for_db(retries: int = 10, delay: int = 3):
    for attempt in range(1, retries + 1):
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info("✅ Database connection established.")
            return
        except Exception as e:
            logger.warning(f"⏳ DB not ready (attempt {attempt}/{retries}): {e}")
            if attempt < retries:
                time.sleep(delay)
    raise RuntimeError("❌ Could not connect to database after multiple retries.")


def run_migrations():
    """Run Alembic migrations — safe to call on every startup."""
    try:
        from alembic.config import Config
        from alembic import command as alembic_command

        logger.info("🔄 Running Alembic migrations...")

        # Find alembic.ini — works both in Docker (/app) and locally
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        ini_path = os.path.join(base_dir, "alembic.ini")

        alembic_cfg = Config(ini_path)
        alembic_cfg.set_main_option("sqlalchemy.url", settings.database_url)
        alembic_cfg.set_main_option("script_location", os.path.join(base_dir, "alembic"))
        alembic_command.upgrade(alembic_cfg, "head")
        logger.info("✅ Migrations complete.")
    except Exception as e:
        logger.error(f"❌ Migration failed: {e}")
        raise


@asynccontextmanager
async def lifespan(app: FastAPI):
    wait_for_db()
    run_migrations()
    db = SessionLocal()
    try:
        seed_org_structure(db)
    finally:
        db.close()
    yield


app = FastAPI(
    title=settings.app_name,
    version="2.0.0",
    description="TaskFlow — Multi-dept Task, Time & Ticketing System",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.state.limiter = limiter
register_error_handlers(app)
app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)
app.add_middleware(LoggingMiddleware)
app.add_middleware(SlowAPIMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

API = "/api/v1"
app.include_router(auth_router,          prefix=API)
app.include_router(users_router,         prefix=API)
app.include_router(verticals_router,     prefix=API)
app.include_router(departments_router,   prefix=API)
app.include_router(designations_router,  prefix=API)
app.include_router(groups_router,        prefix=API)
app.include_router(sla_router,           prefix=API)
app.include_router(notifications_router, prefix=API)
app.include_router(branches_router,      prefix=API)
app.include_router(holidays_router,      prefix=API)
app.include_router(projects_router,      prefix=API)
app.include_router(tasks_router,         prefix=API)
app.include_router(time_logs_router,     prefix=API)
app.include_router(tickets_router,       prefix=API)
app.include_router(comments_router,      prefix=API)


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "version": "2.0.0"}

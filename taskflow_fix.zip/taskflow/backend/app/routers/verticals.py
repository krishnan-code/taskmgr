from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.database import get_db
from app.models.vertical import Vertical
from app.models.user import User
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user, require_admin
from app.utils.exceptions import NotFoundException, ConflictException
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/verticals", tags=["Org — Verticals"])


class VerticalCreate(BaseModel):
    name: str
    description: Optional[str] = None
    is_ticketing_enabled: bool = False


class VerticalUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_ticketing_enabled: Optional[bool] = None
    is_active: Optional[bool] = None


class VerticalOut(BaseModel):
    id: str
    name: str
    description: Optional[str]
    is_ticketing_enabled: bool
    is_active: bool
    created_at: datetime
    department_count: int = 0
    model_config = {"from_attributes": True}


@router.get("", response_model=PaginatedResponse[VerticalOut])
def list_verticals(db: Session = Depends(get_db), current_user: User = Depends(get_current_user), page: PaginationParams = Depends(pagination)):
    query = db.query(Vertical)
    total = query.count()
    verticals = query.order_by(Vertical.name).offset(page.offset).limit(page.limit).all()
    result = []
    for v in verticals:
        out = VerticalOut.model_validate(v)
        out.department_count = len(v.departments)
        result.append(out)
    return paginated(result, total, page.limit, page.offset)


@router.post("", response_model=ApiResponse[VerticalOut], status_code=status.HTTP_201_CREATED)
def create_vertical(payload: VerticalCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    if db.query(Vertical).filter(Vertical.name == payload.name).first():
        raise ConflictException(f"Vertical '{payload.name}' already exists")
    v = Vertical(**payload.model_dump())
    db.add(v); db.commit(); db.refresh(v)
    out = VerticalOut.model_validate(v); out.department_count = 0
    return ok(out, "Vertical created successfully")


@router.get("/{vertical_id}", response_model=ApiResponse[VerticalOut])
def get_vertical(vertical_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    v = db.query(Vertical).filter(Vertical.id == vertical_id).first()
    if not v: raise NotFoundException("Vertical")
    out = VerticalOut.model_validate(v); out.department_count = len(v.departments)
    return ok(out)


@router.put("/{vertical_id}", response_model=ApiResponse[VerticalOut])
def update_vertical(vertical_id: str, payload: VerticalUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    v = db.query(Vertical).filter(Vertical.id == vertical_id).first()
    if not v: raise NotFoundException("Vertical")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(v, field, value)
    db.commit(); db.refresh(v)
    out = VerticalOut.model_validate(v); out.department_count = len(v.departments)
    return ok(out, "Vertical updated")


@router.delete("/{vertical_id}", response_model=ApiResponse[None])
def delete_vertical(vertical_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    v = db.query(Vertical).filter(Vertical.id == vertical_id).first()
    if not v: raise NotFoundException("Vertical")
    active_depts = [d for d in v.departments if d.is_active]
    if active_depts:
        raise ConflictException(f"Cannot delete — {len(active_depts)} active department(s) exist. Deactivate them first.")
    v.is_active = False
    db.commit()
    return ok(None, "Vertical deactivated")

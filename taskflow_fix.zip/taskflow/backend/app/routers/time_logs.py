from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone

from app.database import get_db
from app.models.task import Task, Subtask
from app.models.time_log import TimeLog
from app.models.user import User
from app.utils.dependencies import get_current_user

router = APIRouter(prefix="/tasks", tags=["Time Tracking"])


class TimerStartRequest(BaseModel):
    subtask_id: Optional[str] = None
    note: Optional[str] = None


class TimerStopRequest(BaseModel):
    time_log_id: str
    note: Optional[str] = None


class TimeLogOut(BaseModel):
    id: str
    task_id: str
    subtask_id: Optional[str]
    user_id: Optional[str]
    started_at: datetime
    ended_at: Optional[datetime]
    duration_seconds: int
    note: Optional[str]

    model_config = {"from_attributes": True}


class TimeSummaryOut(BaseModel):
    task_id: str
    task_total_seconds: int
    subtask_breakdown: dict


@router.post("/{task_id}/timer/start", response_model=TimeLogOut, status_code=status.HTTP_201_CREATED)
def start_timer(
    task_id: str,
    payload: TimerStartRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    if payload.subtask_id:
        subtask = db.query(Subtask).filter(
            Subtask.id == payload.subtask_id, Subtask.task_id == task_id
        ).first()
        if not subtask:
            raise HTTPException(status_code=404, detail="Subtask not found")

    # Check if user already has an active timer on this task
    active = db.query(TimeLog).filter(
        TimeLog.task_id == task_id,
        TimeLog.user_id == current_user.id,
        TimeLog.ended_at == None,
    ).first()
    if active:
        raise HTTPException(status_code=400, detail="Timer already running. Stop it first.")

    log = TimeLog(
        task_id=task_id,
        subtask_id=payload.subtask_id,
        user_id=current_user.id,
        started_at=datetime.now(timezone.utc),
        note=payload.note,
        duration_seconds=0,
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log


@router.post("/{task_id}/timer/stop", response_model=TimeLogOut)
def stop_timer(
    task_id: str,
    payload: TimerStopRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    log = db.query(TimeLog).filter(
        TimeLog.id == payload.time_log_id,
        TimeLog.task_id == task_id,
        TimeLog.user_id == current_user.id,
        TimeLog.ended_at == None,
    ).first()
    if not log:
        raise HTTPException(status_code=404, detail="Active timer not found")

    now = datetime.now(timezone.utc)
    log.ended_at = now
    log.duration_seconds = int((now - log.started_at).total_seconds())
    if payload.note:
        log.note = payload.note
    db.commit()
    db.refresh(log)
    return log


@router.get("/{task_id}/time-logs", response_model=List[TimeLogOut])
def get_time_logs(
    task_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    logs = db.query(TimeLog).filter(TimeLog.task_id == task_id).order_by(TimeLog.started_at.desc()).all()
    return logs


@router.get("/{task_id}/time-summary", response_model=TimeSummaryOut)
def get_time_summary(
    task_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    total = db.query(func.sum(TimeLog.duration_seconds)).filter(
        TimeLog.task_id == task_id
    ).scalar() or 0

    breakdown = {}
    for subtask in task.subtasks:
        secs = db.query(func.sum(TimeLog.duration_seconds)).filter(
            TimeLog.subtask_id == subtask.id
        ).scalar() or 0
        breakdown[subtask.id] = {"title": subtask.title, "seconds": secs}

    return TimeSummaryOut(task_id=task_id, task_total_seconds=total, subtask_breakdown=breakdown)

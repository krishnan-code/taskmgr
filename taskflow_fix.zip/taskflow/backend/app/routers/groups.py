from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.database import get_db
from app.models.group import Group, GroupMember
from app.models.user import User
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user, require_manager
from app.utils.exceptions import NotFoundException, ConflictException
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/groups", tags=["Groups"])


class GroupCreate(BaseModel):
    name: str
    description: Optional[str] = None
    member_ids: List[str] = []


class GroupUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class MemberAdd(BaseModel):
    user_ids: List[str]


class GroupMemberOut(BaseModel):
    id: str
    user_id: str
    user_name: str = ""
    user_email: str = ""
    user_department: str = ""
    created_at: datetime
    model_config = {"from_attributes": True}


class GroupOut(BaseModel):
    id: str
    name: str
    description: Optional[str]
    created_by: Optional[str]
    is_active: bool
    member_count: int = 0
    created_at: datetime
    model_config = {"from_attributes": True}


class GroupDetailOut(GroupOut):
    members: List[GroupMemberOut] = []


@router.get("", response_model=PaginatedResponse[GroupOut])
def list_groups(db: Session = Depends(get_db), current_user: User = Depends(get_current_user), page: PaginationParams = Depends(pagination)):
    query = db.query(Group).filter(Group.is_active == True)
    total = query.count()
    groups = query.order_by(Group.name).offset(page.offset).limit(page.limit).all()
    result = []
    for g in groups:
        out = GroupOut.model_validate(g)
        out.member_count = len(g.members)
        result.append(out)
    return paginated(result, total, page.limit, page.offset)


@router.post("", response_model=ApiResponse[GroupDetailOut], status_code=status.HTTP_201_CREATED)
def create_group(payload: GroupCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    group = Group(name=payload.name, description=payload.description, created_by=current_user.id)
    db.add(group); db.commit(); db.refresh(group)
    for uid in payload.member_ids:
        user = db.query(User).filter(User.id == uid, User.is_active == True).first()
        if user:
            db.add(GroupMember(group_id=group.id, user_id=uid, added_by=current_user.id))
    db.commit(); db.refresh(group)
    return ok(_build_group_detail(group), "Group created")


@router.get("/{group_id}", response_model=ApiResponse[GroupDetailOut])
def get_group(group_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    group = db.query(Group).filter(Group.id == group_id, Group.is_active == True).first()
    if not group: raise NotFoundException("Group")
    return ok(_build_group_detail(group))


@router.put("/{group_id}", response_model=ApiResponse[GroupOut])
def update_group(group_id: str, payload: GroupUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    group = db.query(Group).filter(Group.id == group_id, Group.is_active == True).first()
    if not group: raise NotFoundException("Group")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(group, field, value)
    db.commit(); db.refresh(group)
    out = GroupOut.model_validate(group); out.member_count = len(group.members)
    return ok(out, "Group updated")


@router.post("/{group_id}/members", response_model=ApiResponse[GroupDetailOut])
def add_members(group_id: str, payload: MemberAdd, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    group = db.query(Group).filter(Group.id == group_id, Group.is_active == True).first()
    if not group: raise NotFoundException("Group")
    existing_ids = {m.user_id for m in group.members}
    for uid in payload.user_ids:
        if uid not in existing_ids:
            user = db.query(User).filter(User.id == uid, User.is_active == True).first()
            if user:
                db.add(GroupMember(group_id=group_id, user_id=uid, added_by=current_user.id))
    db.commit(); db.refresh(group)
    return ok(_build_group_detail(group), f"Members added")


@router.delete("/{group_id}/members/{user_id}", response_model=ApiResponse[None])
def remove_member(group_id: str, user_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    member = db.query(GroupMember).filter(GroupMember.group_id == group_id, GroupMember.user_id == user_id).first()
    if not member: raise NotFoundException("Group member")
    db.delete(member); db.commit()
    return ok(None, "Member removed")


@router.delete("/{group_id}", response_model=ApiResponse[None])
def delete_group(group_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    group = db.query(Group).filter(Group.id == group_id, Group.is_active == True).first()
    if not group: raise NotFoundException("Group")
    group.is_active = False; db.commit()
    return ok(None, "Group dissolved")


def _build_group_detail(group: Group) -> GroupDetailOut:
    out = GroupDetailOut.model_validate(group)
    out.member_count = len(group.members)
    members = []
    for m in group.members:
        mo = GroupMemberOut.model_validate(m)
        if m.user:
            mo.user_name = m.user.name
            mo.user_email = m.user.email
            mo.user_department = m.user.department.name if m.user.department else ""
        members.append(mo)
    out.members = members
    return out

from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.database import get_db
from app.models.designation import Designation
from app.models.user import User
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user, require_admin
from app.utils.exceptions import NotFoundException, ConflictException
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/designations", tags=["Org — Designations"])

LEVEL_NAMES = {1: "Director", 2: "HOD", 3: "Senior Manager", 4: "Manager", 5: "Team Lead", 6: "Engineer", 7: "Technician", 8: "Trainee"}


class DesignationCreate(BaseModel):
    title: str
    department_id: Optional[str] = None
    level_rank: int
    is_hod_level: bool = False
    is_director_level: bool = False


class DesignationUpdate(BaseModel):
    title: Optional[str] = None
    department_id: Optional[str] = None
    level_rank: Optional[int] = None
    is_hod_level: Optional[bool] = None
    is_director_level: Optional[bool] = None
    is_active: Optional[bool] = None


class DesignationOut(BaseModel):
    id: str
    title: str
    department_id: Optional[str]
    level_rank: int
    level_name: str = ""
    is_hod_level: bool
    is_director_level: bool
    is_active: bool
    created_at: datetime
    model_config = {"from_attributes": True}


@router.get("", response_model=PaginatedResponse[DesignationOut])
def list_designations(department_id: Optional[str] = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_user), page: PaginationParams = Depends(pagination)):
    query = db.query(Designation)
    if department_id:
        query = query.filter(Designation.department_id == department_id)
    total = query.count()
    items = query.order_by(Designation.level_rank).offset(page.offset).limit(page.limit).all()
    result = []
    for d in items:
        out = DesignationOut.model_validate(d)
        out.level_name = LEVEL_NAMES.get(d.level_rank, f"Level {d.level_rank}")
        result.append(out)
    return paginated(result, total, page.limit, page.offset)


@router.post("", response_model=ApiResponse[DesignationOut], status_code=status.HTTP_201_CREATED)
def create_designation(payload: DesignationCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    d = Designation(**payload.model_dump())
    db.add(d); db.commit(); db.refresh(d)
    out = DesignationOut.model_validate(d)
    out.level_name = LEVEL_NAMES.get(d.level_rank, f"Level {d.level_rank}")
    return ok(out, "Designation created")


@router.put("/{designation_id}", response_model=ApiResponse[DesignationOut])
def update_designation(designation_id: str, payload: DesignationUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    d = db.query(Designation).filter(Designation.id == designation_id).first()
    if not d: raise NotFoundException("Designation")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(d, field, value)
    db.commit(); db.refresh(d)
    out = DesignationOut.model_validate(d)
    out.level_name = LEVEL_NAMES.get(d.level_rank, f"Level {d.level_rank}")
    return ok(out, "Designation updated")


@router.delete("/{designation_id}", response_model=ApiResponse[None])
def delete_designation(designation_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    d = db.query(Designation).filter(Designation.id == designation_id).first()
    if not d: raise NotFoundException("Designation")
    users = db.query(User).filter(User.designation_id == designation_id, User.is_active == True).count()
    if users:
        raise ConflictException(f"Cannot delete — {users} active user(s) hold this designation.")
    d.is_active = False; db.commit()
    return ok(None, "Designation deactivated")

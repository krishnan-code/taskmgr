from fastapi import APIRouter, Depends, status, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime

from app.database import get_db
from app.models.holiday import Holiday, HolidayType
from app.models.branch import Branch
from app.models.user import User
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user, require_admin
from app.utils.exceptions import NotFoundException
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/holidays", tags=["Org — Holidays"])


class HolidayCreate(BaseModel):
    name: str
    date: date
    holiday_type: HolidayType = HolidayType.global_holiday
    branch_id: Optional[str] = None   # required if local
    description: Optional[str] = None
    is_recurring: bool = True


class HolidayUpdate(BaseModel):
    name: Optional[str] = None
    date: Optional[date] = None
    holiday_type: Optional[HolidayType] = None
    branch_id: Optional[str] = None
    description: Optional[str] = None
    is_recurring: Optional[bool] = None
    is_active: Optional[bool] = None


class HolidayOut(BaseModel):
    id: str
    name: str
    date: date
    holiday_type: HolidayType
    branch_id: Optional[str]
    branch_name: Optional[str] = None
    description: Optional[str]
    is_recurring: bool
    is_active: bool
    created_at: datetime
    model_config = {"from_attributes": True}


def _enrich(h: Holiday, db: Session) -> HolidayOut:
    out = HolidayOut.model_validate(h)
    if h.branch_id:
        branch = db.query(Branch).filter(Branch.id == h.branch_id).first()
        out.branch_name = branch.name if branch else None
    else:
        out.branch_name = "All Branches"
    return out


@router.get("", response_model=PaginatedResponse[HolidayOut])
def list_holidays(
    holiday_type: Optional[HolidayType] = Query(None),
    branch_id: Optional[str] = Query(None),
    year: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    page: PaginationParams = Depends(pagination),
):
    query = db.query(Holiday).filter(Holiday.is_active == True)
    if holiday_type:
        query = query.filter(Holiday.holiday_type == holiday_type)
    if branch_id:
        # Return global + branch-specific
        query = query.filter(
            (Holiday.branch_id == branch_id) | (Holiday.branch_id == None)
        )
    if year:
        from sqlalchemy import extract
        query = query.filter(extract('year', Holiday.date) == year)
    total = query.count()
    holidays = query.order_by(Holiday.date).offset(page.offset).limit(page.limit).all()
    return paginated([_enrich(h, db) for h in holidays], total, page.limit, page.offset)


@router.get("/upcoming", response_model=ApiResponse[List[HolidayOut]])
def upcoming_holidays(
    limit: int = Query(default=5, ge=1, le=20),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Next N holidays for the current user's branch."""
    today = date.today()
    branch_id = current_user.branch_id

    query = db.query(Holiday).filter(Holiday.is_active == True, Holiday.date >= today)
    if branch_id:
        query = query.filter(
            (Holiday.branch_id == branch_id) | (Holiday.branch_id == None)
        )
    else:
        query = query.filter(Holiday.branch_id == None)

    holidays = query.order_by(Holiday.date).limit(limit).all()
    return ok([_enrich(h, db) for h in holidays])


@router.get("/calendar/{year}", response_model=ApiResponse[List[HolidayOut]])
def holiday_calendar(
    year: int,
    branch_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Full year calendar view of holidays."""
    from sqlalchemy import extract
    query = db.query(Holiday).filter(Holiday.is_active == True, extract('year', Holiday.date) == year)
    if branch_id:
        query = query.filter((Holiday.branch_id == branch_id) | (Holiday.branch_id == None))
    holidays = query.order_by(Holiday.date).all()
    return ok([_enrich(h, db) for h in holidays])


@router.post("", response_model=ApiResponse[HolidayOut], status_code=status.HTTP_201_CREATED)
def create_holiday(
    payload: HolidayCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if payload.holiday_type == HolidayType.local_holiday and not payload.branch_id:
        from app.utils.exceptions import BadRequestException
        raise BadRequestException("branch_id is required for local holidays")
    if payload.branch_id and not db.query(Branch).filter(Branch.id == payload.branch_id).first():
        raise NotFoundException("Branch")
    holiday = Holiday(**payload.model_dump(), created_by=current_user.id)
    db.add(holiday)
    db.commit()
    db.refresh(holiday)
    return ok(_enrich(holiday, db), "Holiday created successfully")


@router.put("/{holiday_id}", response_model=ApiResponse[HolidayOut])
def update_holiday(
    holiday_id: str,
    payload: HolidayUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    holiday = db.query(Holiday).filter(Holiday.id == holiday_id).first()
    if not holiday: raise NotFoundException("Holiday")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(holiday, field, value)
    db.commit()
    db.refresh(holiday)
    return ok(_enrich(holiday, db), "Holiday updated")


@router.delete("/{holiday_id}", response_model=ApiResponse[None])
def delete_holiday(holiday_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    holiday = db.query(Holiday).filter(Holiday.id == holiday_id).first()
    if not holiday: raise NotFoundException("Holiday")
    holiday.is_active = False
    db.commit()
    return ok(None, "Holiday removed")

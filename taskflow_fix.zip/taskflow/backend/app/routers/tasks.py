from fastapi import APIRouter, Depends, status, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import or_, and_
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, date

from app.database import get_db
from app.models.task import Task, Subtask, TaskParticipant, TaskAcceptanceLog, TaskStatus, TaskPriority, AcceptanceStatus, ParticipantRole
from app.models.user import User, UserRole
from app.models.notification import Notification, NotificationType
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user
from app.utils.exceptions import NotFoundException, ForbiddenException, BadRequestException
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/tasks", tags=["Tasks"])


# ── Schemas ───────────────────────────────────────────────────────────────────
class ParticipantIn(BaseModel):
    user_id: str
    role: ParticipantRole = ParticipantRole.participant


class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    priority: TaskPriority = TaskPriority.medium
    start_date: Optional[date] = None
    due_date: Optional[date] = None
    notes: Optional[str] = None
    project_id: Optional[str] = None
    assignee_id: Optional[str] = None
    lead_user_id: Optional[str] = None
    department_id: Optional[str] = None
    vertical_id: Optional[str] = None
    is_all_departments: bool = False
    group_id: Optional[str] = None
    participants: List[ParticipantIn] = []


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[TaskStatus] = None
    priority: Optional[TaskPriority] = None
    start_date: Optional[date] = None
    due_date: Optional[date] = None
    notes: Optional[str] = None
    assignee_id: Optional[str] = None
    lead_user_id: Optional[str] = None
    department_id: Optional[str] = None
    vertical_id: Optional[str] = None
    is_all_departments: Optional[bool] = None
    group_id: Optional[str] = None


class AcceptRejectPayload(BaseModel):
    action: str  # "accept" or "reject"
    reason: Optional[str] = None


class SubtaskCreate(BaseModel):
    title: str
    assignee_id: Optional[str] = None
    due_date: Optional[date] = None


class SubtaskUpdate(BaseModel):
    title: Optional[str] = None
    done: Optional[bool] = None
    assignee_id: Optional[str] = None
    due_date: Optional[date] = None


class UserMini(BaseModel):
    id: str
    name: str
    email: str
    role: str
    job_title: Optional[str] = None
    department_id: Optional[str] = None
    profile_photo_url: Optional[str] = None
    model_config = {"from_attributes": True}


class ParticipantOut(BaseModel):
    id: str
    user_id: str
    role: ParticipantRole
    source_department_id: Optional[str] = None
    user: Optional[UserMini] = None
    created_at: datetime
    model_config = {"from_attributes": True}


class AcceptanceLogOut(BaseModel):
    id: str
    from_user_id: Optional[str]
    to_user_id: Optional[str]
    action: str
    reason: Optional[str]
    created_at: datetime
    from_user: Optional[UserMini] = None
    to_user: Optional[UserMini] = None
    model_config = {"from_attributes": True}


class SubtaskOut(BaseModel):
    id: str
    title: str
    done: bool
    task_id: str
    assignee_id: Optional[str]
    due_date: Optional[date]
    created_at: datetime
    assignee: Optional[UserMini] = None
    model_config = {"from_attributes": True}


class TaskOut(BaseModel):
    id: str
    title: str
    description: Optional[str]
    status: TaskStatus
    priority: TaskPriority
    start_date: Optional[date]
    due_date: Optional[date]
    notes: Optional[str]
    project_id: Optional[str]
    assignee_id: Optional[str]
    lead_user_id: Optional[str]
    created_by: Optional[str]
    department_id: Optional[str]
    vertical_id: Optional[str]
    is_all_departments: bool
    is_cross_department: bool
    group_id: Optional[str]
    acceptance_status: AcceptanceStatus
    accepted_by: Optional[str]
    accepted_at: Optional[datetime]
    rejection_reason: Optional[str]
    created_at: datetime
    updated_at: Optional[datetime]
    assignee: Optional[UserMini] = None
    lead: Optional[UserMini] = None
    creator: Optional[UserMini] = None
    participants: List[ParticipantOut] = []
    subtasks: List[SubtaskOut] = []
    model_config = {"from_attributes": True}


class TaskListOut(BaseModel):
    id: str
    title: str
    status: TaskStatus
    priority: TaskPriority
    due_date: Optional[date]
    start_date: Optional[date]
    assignee_id: Optional[str]
    lead_user_id: Optional[str]
    department_id: Optional[str]
    vertical_id: Optional[str]
    is_all_departments: bool
    is_cross_department: bool
    acceptance_status: AcceptanceStatus
    created_at: datetime
    assignee: Optional[UserMini] = None
    lead: Optional[UserMini] = None
    participant_count: int = 0
    subtask_count: int = 0
    done_subtask_count: int = 0
    model_config = {"from_attributes": True}


# ── Helpers ───────────────────────────────────────────────────────────────────
def _needs_acceptance(assigner: User, assignee: User) -> bool:
    """Check if assigning from assigner to assignee requires acceptance."""
    if not assignee or not assigner:
        return False
    # Director assigns to anyone below → needs acceptance
    if assigner.is_director and not assignee.is_director:
        return True
    # Any downward hierarchy assignment
    assigner_rank = assigner.designation.level_rank if assigner.designation else 99
    assignee_rank = assignee.designation.level_rank if assignee.designation else 99
    return assigner_rank < assignee_rank


def _send_notification(db: Session, user_id: str, notif_type: NotificationType,
                       title: str, body: str, ref_id: str):
    n = Notification(user_id=user_id, type=notif_type, title=title, body=body,
                     reference_type="task", reference_id=ref_id)
    db.add(n)


def _enrich_task_list(task: Task) -> TaskListOut:
    out = TaskListOut.model_validate(task)
    out.participant_count = len(task.participants)
    out.subtask_count = len(task.subtasks)
    out.done_subtask_count = sum(1 for s in task.subtasks if s.done)
    if task.assignee:
        out.assignee = UserMini.model_validate(task.assignee)
    if task.lead:
        out.lead = UserMini.model_validate(task.lead)
    return out


def _visibility_filter(query, current_user: User, db: Session):
    """Apply visibility filter based on user's role/designation level."""
    role = current_user.role
    if role in (UserRole.admin, UserRole.director) or current_user.is_director:
        return query  # See everything
    if current_user.is_hod or role == UserRole.hod:
        # See all tasks in own department
        return query.filter(
            or_(
                Task.created_by == current_user.id,
                Task.assignee_id == current_user.id,
                Task.lead_user_id == current_user.id,
                Task.department_id == current_user.department_id,
                Task.is_all_departments == True,
                Task.participants.any(TaskParticipant.user_id == current_user.id),
            )
        )
    if role == UserRole.manager:
        # See own tasks + direct reportees' tasks
        reportee_ids = [u.id for u in db.query(User).filter(
            or_(User.reporting_manager_id == current_user.id,
                User.reporting_head_id == current_user.id)
        ).all()]
        return query.filter(
            or_(
                Task.created_by == current_user.id,
                Task.assignee_id == current_user.id,
                Task.lead_user_id == current_user.id,
                Task.assignee_id.in_(reportee_ids),
                Task.is_all_departments == True,
                Task.participants.any(TaskParticipant.user_id == current_user.id),
            )
        )
    # Member — own tasks only
    return query.filter(
        or_(
            Task.created_by == current_user.id,
            Task.assignee_id == current_user.id,
            Task.lead_user_id == current_user.id,
            Task.is_all_departments == True,
            Task.participants.any(TaskParticipant.user_id == current_user.id),
        )
    )


# ── List Tasks ────────────────────────────────────────────────────────────────
@router.get("", response_model=PaginatedResponse[TaskListOut])
def list_tasks(
    status: Optional[TaskStatus] = Query(None),
    priority: Optional[TaskPriority] = Query(None),
    assignee_id: Optional[str] = Query(None),
    department_id: Optional[str] = Query(None),
    project_id: Optional[str] = Query(None),
    acceptance_status: Optional[AcceptanceStatus] = Query(None),
    my_tasks: bool = Query(False),
    pending_my_acceptance: bool = Query(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    page: PaginationParams = Depends(pagination),
):
    query = db.query(Task).options(
        joinedload(Task.assignee),
        joinedload(Task.lead),
        joinedload(Task.participants),
        joinedload(Task.subtasks),
    )
    query = _visibility_filter(query, current_user, db)

    if status:      query = query.filter(Task.status == status)
    if priority:    query = query.filter(Task.priority == priority)
    if assignee_id: query = query.filter(Task.assignee_id == assignee_id)
    if department_id: query = query.filter(Task.department_id == department_id)
    if project_id:  query = query.filter(Task.project_id == project_id)
    if acceptance_status: query = query.filter(Task.acceptance_status == acceptance_status)
    if my_tasks:
        query = query.filter(or_(
            Task.assignee_id == current_user.id,
            Task.lead_user_id == current_user.id,
            Task.participants.any(TaskParticipant.user_id == current_user.id),
        ))
    if pending_my_acceptance:
        query = query.filter(
            Task.assignee_id == current_user.id,
            Task.acceptance_status == AcceptanceStatus.pending,
        )

    total = query.count()
    tasks = query.order_by(Task.created_at.desc()).offset(page.offset).limit(page.limit).all()
    return paginated([_enrich_task_list(t) for t in tasks], total, page.limit, page.offset)


# ── Create Task ───────────────────────────────────────────────────────────────
@router.post("", response_model=ApiResponse[TaskOut], status_code=status.HTTP_201_CREATED)
def create_task(
    payload: TaskCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Determine acceptance requirement
    acceptance = AcceptanceStatus.not_required
    task_status = TaskStatus.not_started

    if payload.assignee_id and payload.assignee_id != current_user.id:
        assignee = db.query(User).filter(User.id == payload.assignee_id).first()
        if assignee and _needs_acceptance(current_user, assignee):
            acceptance = AcceptanceStatus.pending
            task_status = TaskStatus.pending_acceptance

    # Determine cross-department
    is_cross = False
    if payload.department_id and current_user.department_id:
        is_cross = payload.department_id != current_user.department_id

    task = Task(
        title=payload.title,
        description=payload.description,
        priority=payload.priority,
        start_date=payload.start_date,
        due_date=payload.due_date,
        notes=payload.notes,
        project_id=payload.project_id,
        assignee_id=payload.assignee_id,
        lead_user_id=payload.lead_user_id or current_user.id,
        created_by=current_user.id,
        department_id=payload.department_id or current_user.department_id,
        vertical_id=payload.vertical_id,
        is_all_departments=payload.is_all_departments,
        is_cross_department=is_cross,
        group_id=payload.group_id,
        acceptance_status=acceptance,
        status=task_status,
    )
    db.add(task)
    db.flush()

    # Add participants
    seen_users = set()
    for p in payload.participants:
        if p.user_id not in seen_users:
            user = db.query(User).filter(User.id == p.user_id).first()
            if user:
                source_dept = user.department_id if user.department_id != task.department_id else None
                db.add(TaskParticipant(
                    task_id=task.id, user_id=p.user_id, role=p.role,
                    source_department_id=source_dept, added_by=current_user.id,
                ))
                seen_users.add(p.user_id)

    # Log assignment
    if payload.assignee_id:
        db.add(TaskAcceptanceLog(
            task_id=task.id, from_user_id=current_user.id,
            to_user_id=payload.assignee_id, action="assigned",
        ))
        # Send notification
        _send_notification(db, payload.assignee_id, NotificationType.task_assigned,
                           f"New task assigned: {task.title}",
                           f"Assigned by {current_user.name}" + (" — requires your acceptance" if acceptance == AcceptanceStatus.pending else ""),
                           task.id)

    db.commit()
    db.refresh(task)
    return ok(_build_task_out(task), "Task created successfully")


# ── Get Task ──────────────────────────────────────────────────────────────────
@router.get("/{task_id}", response_model=ApiResponse[TaskOut])
def get_task(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(Task).options(
        joinedload(Task.assignee), joinedload(Task.lead), joinedload(Task.creator),
        joinedload(Task.participants).joinedload(TaskParticipant.user),
        joinedload(Task.subtasks).joinedload(Subtask.assignee),
        joinedload(Task.acceptance_logs),
    ).filter(Task.id == task_id).first()
    if not task: raise NotFoundException("Task")
    return ok(_build_task_out(task))


# ── Update Task ───────────────────────────────────────────────────────────────
@router.put("/{task_id}", response_model=ApiResponse[TaskOut])
def update_task(
    task_id: str,
    payload: TaskUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task: raise NotFoundException("Task")

    old_assignee = task.assignee_id

    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(task, field, value)

    # Re-evaluate acceptance if assignee changed
    if payload.assignee_id and payload.assignee_id != old_assignee:
        assignee = db.query(User).filter(User.id == payload.assignee_id).first()
        if assignee and _needs_acceptance(current_user, assignee):
            task.acceptance_status = AcceptanceStatus.pending
            task.status = TaskStatus.pending_acceptance
        else:
            task.acceptance_status = AcceptanceStatus.not_required

        db.add(TaskAcceptanceLog(
            task_id=task.id, from_user_id=current_user.id,
            to_user_id=payload.assignee_id, action="assigned",
        ))
        _send_notification(db, payload.assignee_id, NotificationType.task_assigned,
                           f"Task reassigned to you: {task.title}",
                           f"Reassigned by {current_user.name}", task.id)

    db.commit()
    db.refresh(task)
    return ok(_build_task_out(task), "Task updated")


# ── Accept / Reject Task ──────────────────────────────────────────────────────
@router.patch("/{task_id}/accept", response_model=ApiResponse[TaskOut])
def accept_reject_task(
    task_id: str,
    payload: AcceptRejectPayload,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task: raise NotFoundException("Task")
    if task.assignee_id != current_user.id:
        raise ForbiddenException("Only the assigned user can accept or reject this task")
    if task.acceptance_status != AcceptanceStatus.pending:
        raise BadRequestException("This task does not require acceptance")

    if payload.action == "accept":
        task.acceptance_status = AcceptanceStatus.accepted
        task.status = TaskStatus.in_progress
        task.accepted_by = current_user.id
        task.accepted_at = datetime.utcnow()
        action_label = "accepted"
        notif_type = NotificationType.task_accepted
    elif payload.action == "reject":
        if not payload.reason:
            raise BadRequestException("Rejection reason is required")
        task.acceptance_status = AcceptanceStatus.rejected
        task.status = TaskStatus.rejected
        task.rejection_reason = payload.reason
        action_label = "rejected"
        notif_type = NotificationType.task_rejected
    else:
        raise BadRequestException("action must be 'accept' or 'reject'")

    db.add(TaskAcceptanceLog(
        task_id=task.id, from_user_id=current_user.id,
        to_user_id=task.created_by, action=action_label, reason=payload.reason,
    ))

    if task.created_by:
        _send_notification(db, task.created_by, notif_type,
                           f"Task {action_label}: {task.title}",
                           f"{current_user.name} {action_label} the task" +
                           (f" — Reason: {payload.reason}" if payload.reason else ""),
                           task.id)

    db.commit()
    db.refresh(task)
    return ok(_build_task_out(task), f"Task {action_label} successfully")


# ── Participants ──────────────────────────────────────────────────────────────
@router.post("/{task_id}/participants", response_model=ApiResponse[TaskOut])
def add_participant(
    task_id: str,
    payload: ParticipantIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task: raise NotFoundException("Task")
    existing = db.query(TaskParticipant).filter(
        TaskParticipant.task_id == task_id,
        TaskParticipant.user_id == payload.user_id
    ).first()
    if existing:
        existing.role = payload.role
    else:
        user = db.query(User).filter(User.id == payload.user_id).first()
        if not user: raise NotFoundException("User")
        source_dept = user.department_id if user.department_id != task.department_id else None
        if source_dept:
            task.is_cross_department = True
        db.add(TaskParticipant(
            task_id=task_id, user_id=payload.user_id, role=payload.role,
            source_department_id=source_dept, added_by=current_user.id,
        ))
        _send_notification(db, payload.user_id, NotificationType.task_assigned,
                           f"You were added to task: {task.title}",
                           f"Added as {payload.role} by {current_user.name}", task.id)
    db.commit()
    db.refresh(task)
    return ok(_build_task_out(task), "Participant added")


@router.delete("/{task_id}/participants/{user_id}", response_model=ApiResponse[None])
def remove_participant(
    task_id: str, user_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    p = db.query(TaskParticipant).filter(
        TaskParticipant.task_id == task_id,
        TaskParticipant.user_id == user_id
    ).first()
    if not p: raise NotFoundException("Participant")
    db.delete(p)
    db.commit()
    return ok(None, "Participant removed")


# ── Subtasks ──────────────────────────────────────────────────────────────────
@router.get("/{task_id}/subtasks", response_model=ApiResponse[List[SubtaskOut]])
def list_subtasks(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task: raise NotFoundException("Task")
    return ok([SubtaskOut.model_validate(s) for s in task.subtasks])


@router.post("/{task_id}/subtasks", response_model=ApiResponse[SubtaskOut], status_code=status.HTTP_201_CREATED)
def create_subtask(task_id: str, payload: SubtaskCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task: raise NotFoundException("Task")
    s = Subtask(task_id=task_id, **payload.model_dump())
    db.add(s); db.commit(); db.refresh(s)
    return ok(SubtaskOut.model_validate(s), "Subtask created")


@router.put("/{task_id}/subtasks/{subtask_id}", response_model=ApiResponse[SubtaskOut])
def update_subtask(task_id: str, subtask_id: str, payload: SubtaskUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    s = db.query(Subtask).filter(Subtask.id == subtask_id, Subtask.task_id == task_id).first()
    if not s: raise NotFoundException("Subtask")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(s, field, value)
    db.commit(); db.refresh(s)
    return ok(SubtaskOut.model_validate(s))


@router.delete("/{task_id}/subtasks/{subtask_id}", response_model=ApiResponse[None])
def delete_subtask(task_id: str, subtask_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    s = db.query(Subtask).filter(Subtask.id == subtask_id, Subtask.task_id == task_id).first()
    if not s: raise NotFoundException("Subtask")
    db.delete(s); db.commit()
    return ok(None, "Subtask deleted")


# ── Delete Task ───────────────────────────────────────────────────────────────
@router.delete("/{task_id}", response_model=ApiResponse[None])
def delete_task(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task: raise NotFoundException("Task")
    if task.created_by != current_user.id and current_user.role not in (UserRole.admin, UserRole.director):
        raise ForbiddenException("Only the task creator or admin can delete this task")
    db.delete(task); db.commit()
    return ok(None, "Task deleted")


# ── Kanban Swim Lanes ─────────────────────────────────────────────────────────
@router.get("/kanban/lanes", response_model=ApiResponse[dict])
def get_kanban_lanes(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Return tasks grouped by swim lane for Kanban board."""
    base_query = db.query(Task).options(
        joinedload(Task.assignee), joinedload(Task.lead),
        joinedload(Task.participants).joinedload(TaskParticipant.user),
        joinedload(Task.subtasks),
    )
    base_query = _visibility_filter(base_query, current_user, db)
    all_tasks = base_query.all()

    lanes: dict = {}

    for task in all_tasks:
        # Determine swim lane
        if task.is_all_departments:
            lane_key = "🌐 All Departments"
        elif task.is_cross_department:
            # Find which dept this user is supporting from
            participant = next(
                (p for p in task.participants if p.user_id == current_user.id and p.source_department_id),
                None
            )
            if participant and participant.source_department and task.department:
                lane_key = f"↔ Cross-dept: {task.department.name}"
            else:
                lane_key = f"↔ Cross-dept"
        elif task.department_id:
            lane_key = task.department.name if task.department else "My Department"
        else:
            lane_key = "General"

        if lane_key not in lanes:
            lanes[lane_key] = {
                "not_started": [], "pending_acceptance": [], "rejected": [],
                "in_progress": [], "blocked": [], "on_hold": [], "done": []
            }

        task_data = _enrich_task_list(task).__dict__
        lanes[lane_key][task.status.value].append(task_data)

    return ok({"lanes": lanes, "lane_count": len(lanes)})


# ── Helper ────────────────────────────────────────────────────────────────────
def _build_task_out(task: Task) -> TaskOut:
    out = TaskOut.model_validate(task)
    if task.assignee: out.assignee = UserMini.model_validate(task.assignee)
    if task.lead:     out.lead     = UserMini.model_validate(task.lead)
    if task.creator:  out.creator  = UserMini.model_validate(task.creator)
    out.participants = []
    for p in task.participants:
        po = ParticipantOut.model_validate(p)
        if p.user: po.user = UserMini.model_validate(p.user)
        out.participants.append(po)
    out.subtasks = []
    for s in task.subtasks:
        so = SubtaskOut.model_validate(s)
        if s.assignee: so.assignee = UserMini.model_validate(s.assignee)
        out.subtasks.append(so)
    return out

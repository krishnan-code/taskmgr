from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

from app.database import get_db
from app.models.branch import Branch
from app.models.user import User
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user, require_admin
from app.utils.exceptions import NotFoundException, ConflictException
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/branches", tags=["Org — Branches"])


class BranchCreate(BaseModel):
    branch_code: str
    name: str
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: str = "India"
    pincode: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    timezone: str = "Asia/Kolkata"
    is_headquarters: bool = False


class BranchUpdate(BaseModel):
    branch_code: Optional[str] = None
    name: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    pincode: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    timezone: Optional[str] = None
    is_headquarters: Optional[bool] = None
    is_active: Optional[bool] = None


class BranchOut(BaseModel):
    id: str
    branch_code: str
    name: str
    address: Optional[str]
    city: Optional[str]
    state: Optional[str]
    country: Optional[str]
    pincode: Optional[str]
    phone: Optional[str]
    email: Optional[str]
    timezone: str
    is_headquarters: bool
    is_active: bool
    user_count: int = 0
    created_at: datetime
    model_config = {"from_attributes": True}


@router.get("", response_model=PaginatedResponse[BranchOut])
def list_branches(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    page: PaginationParams = Depends(pagination),
):
    query = db.query(Branch)
    total = query.count()
    branches = query.order_by(Branch.is_headquarters.desc(), Branch.name).offset(page.offset).limit(page.limit).all()
    result = []
    for b in branches:
        out = BranchOut.model_validate(b)
        out.user_count = db.query(User).filter(User.branch_id == b.id, User.is_active == True).count()
        result.append(out)
    return paginated(result, total, page.limit, page.offset)


@router.post("", response_model=ApiResponse[BranchOut], status_code=status.HTTP_201_CREATED)
def create_branch(
    payload: BranchCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if db.query(Branch).filter(Branch.branch_code == payload.branch_code.upper()).first():
        raise ConflictException(f"Branch code '{payload.branch_code}' already exists")
    # Ensure only one HQ
    if payload.is_headquarters:
        db.query(Branch).filter(Branch.is_headquarters == True).update({"is_headquarters": False})
    branch = Branch(**{**payload.model_dump(), "branch_code": payload.branch_code.upper()})
    db.add(branch)
    db.commit()
    db.refresh(branch)
    out = BranchOut.model_validate(branch)
    out.user_count = 0
    return ok(out, "Branch created successfully")


@router.get("/{branch_id}", response_model=ApiResponse[BranchOut])
def get_branch(branch_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch: raise NotFoundException("Branch")
    out = BranchOut.model_validate(branch)
    out.user_count = db.query(User).filter(User.branch_id == branch_id, User.is_active == True).count()
    return ok(out)


@router.put("/{branch_id}", response_model=ApiResponse[BranchOut])
def update_branch(
    branch_id: str,
    payload: BranchUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch: raise NotFoundException("Branch")
    if payload.is_headquarters:
        db.query(Branch).filter(Branch.is_headquarters == True, Branch.id != branch_id).update({"is_headquarters": False})
    if payload.branch_code:
        payload.branch_code = payload.branch_code.upper()
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(branch, field, value)
    db.commit()
    db.refresh(branch)
    out = BranchOut.model_validate(branch)
    out.user_count = db.query(User).filter(User.branch_id == branch_id, User.is_active == True).count()
    return ok(out, "Branch updated")


@router.delete("/{branch_id}", response_model=ApiResponse[None])
def delete_branch(branch_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch: raise NotFoundException("Branch")
    active_users = db.query(User).filter(User.branch_id == branch_id, User.is_active == True).count()
    if active_users:
        raise ConflictException(f"Cannot delete — {active_users} active user(s) assigned to this branch. Transfer them first.")
    branch.is_active = False
    db.commit()
    return ok(None, "Branch deactivated")

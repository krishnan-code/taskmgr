from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.database import get_db
from app.models.sla_policy import SLAPolicy, SLAPriority
from app.models.user import User
from app.schemas.response import ApiResponse, ok
from app.utils.dependencies import get_current_user, require_admin
from app.utils.exceptions import NotFoundException, ConflictException

router = APIRouter(prefix="/sla-policies", tags=["Org — SLA Policies"])

SLA_DEFAULTS = [
    {"name": "Critical", "priority": SLAPriority.P1, "response_minutes": 15,  "resolution_minutes": 240},
    {"name": "High",     "priority": SLAPriority.P2, "response_minutes": 60,  "resolution_minutes": 480},
    {"name": "Medium",   "priority": SLAPriority.P3, "response_minutes": 240, "resolution_minutes": 1440},
    {"name": "Low",      "priority": SLAPriority.P4, "response_minutes": 480, "resolution_minutes": 4320},
]


class SLAUpdate(BaseModel):
    name: Optional[str] = None
    response_minutes: Optional[int] = None
    resolution_minutes: Optional[int] = None


class SLAOut(BaseModel):
    id: str
    name: str
    priority: SLAPriority
    response_minutes: int
    resolution_minutes: int
    response_label: str = ""
    resolution_label: str = ""
    is_active: bool
    created_at: datetime
    model_config = {"from_attributes": True}


def _minutes_label(minutes: int) -> str:
    if minutes < 60: return f"{minutes} min"
    if minutes < 1440: return f"{minutes // 60} hr"
    return f"{minutes // 1440} day(s)"


@router.get("", response_model=ApiResponse[List[SLAOut]])
def list_sla_policies(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    policies = db.query(SLAPolicy).order_by(SLAPolicy.priority).all()
    result = []
    for p in policies:
        out = SLAOut.model_validate(p)
        out.response_label = _minutes_label(p.response_minutes)
        out.resolution_label = _minutes_label(p.resolution_minutes)
        result.append(out)
    return ok(result)


@router.put("/{policy_id}", response_model=ApiResponse[SLAOut])
def update_sla_policy(policy_id: str, payload: SLAUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    p = db.query(SLAPolicy).filter(SLAPolicy.id == policy_id).first()
    if not p: raise NotFoundException("SLA Policy")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(p, field, value)
    db.commit(); db.refresh(p)
    out = SLAOut.model_validate(p)
    out.response_label = _minutes_label(p.response_minutes)
    out.resolution_label = _minutes_label(p.resolution_minutes)
    return ok(out, "SLA Policy updated — affects new tickets only")

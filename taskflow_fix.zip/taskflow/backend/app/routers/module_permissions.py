from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List
from datetime import datetime

from app.database import get_db
from app.models.module_permission import ModulePermission, ModuleType
from app.models.user import User
from app.schemas.response import ApiResponse, ok
from app.utils.dependencies import get_current_user, require_admin
from app.utils.exceptions import NotFoundException

router = APIRouter(prefix="/module-permissions", tags=["Org - Module Permissions"])


class ModulePermissionUpdate(BaseModel):
    module: ModuleType
    is_enabled: bool


class ModulePermissionOut(BaseModel):
    id: str
    department_id: str
    module: ModuleType
    is_enabled: bool
    updated_at: datetime
    model_config = {"from_attributes": True}


@router.get("/{dept_id}", response_model=ApiResponse[List[ModulePermissionOut]])
def get_permissions(dept_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    perms = db.query(ModulePermission).filter(ModulePermission.department_id == dept_id).all()
    return ok([ModulePermissionOut.model_validate(p) for p in perms])


@router.patch("/{dept_id}", response_model=ApiResponse[ModulePermissionOut])
def update_permission(
    dept_id: str,
    payload: ModulePermissionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    perm = db.query(ModulePermission).filter(
        ModulePermission.department_id == dept_id,
        ModulePermission.module == payload.module
    ).first()
    if not perm:
        perm = ModulePermission(department_id=dept_id, module=payload.module, is_enabled=payload.is_enabled, updated_by=current_user.id)
        db.add(perm)
    else:
        perm.is_enabled = payload.is_enabled
        perm.updated_by = current_user.id
    db.commit(); db.refresh(perm)
    return ok(ModulePermissionOut.model_validate(perm), f"Module {payload.module} {'enabled' if payload.is_enabled else 'disabled'}")

from fastapi import APIRouter, Depends, status, Request
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.schemas.user import UserCreate, LoginRequest, TokenResponse, RefreshRequest, UserOut
from app.schemas.response import ApiResponse, ok
from app.utils.security import hash_password, verify_password, create_access_token, create_refresh_token, decode_token
from app.utils.dependencies import get_current_user
from app.utils.exceptions import ConflictException, UnauthorizedException
from app.utils.rate_limit import limiter

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=ApiResponse[UserOut], status_code=status.HTTP_201_CREATED)
@limiter.limit("10/minute")
def register(request: Request, payload: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == payload.email).first():
        raise ConflictException("Email already registered")
    user = User(
        name=payload.name,
        email=payload.email,
        password_hash=hash_password(payload.password),
        role=payload.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return ok(UserOut.model_validate(user), "User registered successfully")


@router.post("/login", response_model=ApiResponse[TokenResponse])
@limiter.limit("5/minute")
def login(request: Request, payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email, User.is_active == True).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise UnauthorizedException("Invalid email or password")
    access_token = create_access_token({"sub": user.id, "role": user.role})
    refresh_token = create_refresh_token({"sub": user.id})
    token_data = TokenResponse(access_token=access_token, refresh_token=refresh_token, user=UserOut.model_validate(user))
    return ok(token_data, "Login successful")


@router.post("/refresh", response_model=ApiResponse[TokenResponse])
@limiter.limit("10/minute")
def refresh_token(request: Request, payload: RefreshRequest, db: Session = Depends(get_db)):
    data = decode_token(payload.refresh_token)
    if not data or data.get("type") != "refresh":
        raise UnauthorizedException("Invalid or expired refresh token")
    user = db.query(User).filter(User.id == data["sub"], User.is_active == True).first()
    if not user:
        raise UnauthorizedException("User not found")
    access_token = create_access_token({"sub": user.id, "role": user.role})
    new_refresh = create_refresh_token({"sub": user.id})
    token_data = TokenResponse(access_token=access_token, refresh_token=new_refresh, user=UserOut.model_validate(user))
    return ok(token_data, "Token refreshed")


@router.get("/me", response_model=ApiResponse[UserOut])
def me(current_user: User = Depends(get_current_user)):
    return ok(UserOut.model_validate(current_user))

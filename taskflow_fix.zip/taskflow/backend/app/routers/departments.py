from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.database import get_db
from app.models.department import Department, DepartmentLevel
from app.models.vertical import Vertical
from app.models.module_permission import ModulePermission, ModuleType
from app.models.user import User
from app.schemas.response import ApiResponse, ok
from app.utils.dependencies import get_current_user, require_admin
from app.utils.exceptions import NotFoundException, ConflictException, BadRequestException

router = APIRouter(prefix="/departments", tags=["Org — Departments"])


class DepartmentCreate(BaseModel):
    name: str
    vertical_id: str
    parent_id: Optional[str] = None
    level: DepartmentLevel = DepartmentLevel.department
    head_user_id: Optional[str] = None
    is_ticketing_enabled: bool = False


class DepartmentUpdate(BaseModel):
    name: Optional[str] = None
    vertical_id: Optional[str] = None
    parent_id: Optional[str] = None
    level: Optional[DepartmentLevel] = None
    head_user_id: Optional[str] = None
    is_ticketing_enabled: Optional[bool] = None
    is_active: Optional[bool] = None


class ModuleToggle(BaseModel):
    module: ModuleType
    is_enabled: bool


class DepartmentOut(BaseModel):
    id: str
    name: str
    vertical_id: str
    parent_id: Optional[str]
    level: DepartmentLevel
    head_user_id: Optional[str]
    is_ticketing_enabled: bool
    is_active: bool
    created_at: datetime
    children: List["DepartmentOut"] = []
    model_config = {"from_attributes": True}


DepartmentOut.model_rebuild()


def build_tree(departments: List[Department], parent_id: Optional[str] = None) -> List[DepartmentOut]:
    result = []
    for d in departments:
        if d.parent_id == parent_id:
            out = DepartmentOut.model_validate(d)
            out.children = build_tree(departments, d.id)
            result.append(out)
    return result


@router.get("", response_model=ApiResponse[List[DepartmentOut]])
def list_departments(
    vertical_id: Optional[str] = None,
    tree: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Department)
    if vertical_id:
        query = query.filter(Department.vertical_id == vertical_id)
    departments = query.order_by(Department.sort_order, Department.name).all()
    if tree:
        return ok(build_tree(departments))
    return ok([DepartmentOut.model_validate(d) for d in departments])


@router.post("", response_model=ApiResponse[DepartmentOut], status_code=status.HTTP_201_CREATED)
def create_department(payload: DepartmentCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    if not db.query(Vertical).filter(Vertical.id == payload.vertical_id).first():
        raise NotFoundException("Vertical")
    dept = Department(**payload.model_dump())
    db.add(dept); db.commit(); db.refresh(dept)
    # Auto-create default module permissions
    for module in ModuleType:
        enabled = module == ModuleType.tickets and payload.is_ticketing_enabled
        if module != ModuleType.tickets:
            enabled = True
        mp = ModulePermission(department_id=dept.id, module=module, is_enabled=enabled)
        db.add(mp)
    db.commit()
    return ok(DepartmentOut.model_validate(dept), "Department created")


@router.get("/{dept_id}", response_model=ApiResponse[DepartmentOut])
def get_department(dept_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    dept = db.query(Department).filter(Department.id == dept_id).first()
    if not dept: raise NotFoundException("Department")
    out = DepartmentOut.model_validate(dept)
    out.children = [DepartmentOut.model_validate(c) for c in dept.children]
    return ok(out)


@router.put("/{dept_id}", response_model=ApiResponse[DepartmentOut])
def update_department(dept_id: str, payload: DepartmentUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    dept = db.query(Department).filter(Department.id == dept_id).first()
    if not dept: raise NotFoundException("Department")
    if payload.vertical_id and not db.query(Vertical).filter(Vertical.id == payload.vertical_id).first():
        raise NotFoundException("Vertical")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(dept, field, value)
    db.commit(); db.refresh(dept)
    return ok(DepartmentOut.model_validate(dept), "Department updated")


@router.patch("/{dept_id}/transfer", response_model=ApiResponse[DepartmentOut])
def transfer_department(dept_id: str, payload: DepartmentUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    dept = db.query(Department).filter(Department.id == dept_id).first()
    if not dept: raise NotFoundException("Department")
    if payload.vertical_id:
        if not db.query(Vertical).filter(Vertical.id == payload.vertical_id).first():
            raise NotFoundException("Vertical")
        dept.vertical_id = payload.vertical_id
    if payload.parent_id is not None:
        dept.parent_id = payload.parent_id
    db.commit(); db.refresh(dept)
    return ok(DepartmentOut.model_validate(dept), "Department transferred")


@router.patch("/{dept_id}/modules", response_model=ApiResponse[None])
def toggle_module(dept_id: str, payload: ModuleToggle, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    dept = db.query(Department).filter(Department.id == dept_id).first()
    if not dept: raise NotFoundException("Department")
    mp = db.query(ModulePermission).filter(
        ModulePermission.department_id == dept_id,
        ModulePermission.module == payload.module
    ).first()
    if not mp:
        mp = ModulePermission(department_id=dept_id, module=payload.module, is_enabled=payload.is_enabled)
        db.add(mp)
    else:
        mp.is_enabled = payload.is_enabled
        mp.updated_by = current_user.id
    db.commit()
    return ok(None, f"Module '{payload.module}' {'enabled' if payload.is_enabled else 'disabled'}")


@router.delete("/{dept_id}", response_model=ApiResponse[None])
def delete_department(dept_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    dept = db.query(Department).filter(Department.id == dept_id).first()
    if not dept: raise NotFoundException("Department")
    active_users = db.query(User).filter(User.department_id == dept_id, User.is_active == True).count()
    if active_users:
        raise ConflictException(f"Cannot delete — {active_users} active user(s) in this department. Transfer them first.")
    dept.is_active = False
    db.commit()
    return ok(None, "Department deactivated")

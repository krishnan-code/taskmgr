from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

from app.database import get_db
from app.models.user import User, UserRole
from app.schemas.user import UserCreate, UserUpdate, UserOut, UserProfileUpdate
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user, require_admin, require_manager
from app.utils.exceptions import NotFoundException, ForbiddenException, ConflictException
from app.utils.security import hash_password
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("", response_model=PaginatedResponse[UserOut])
def list_users(
    department_id: Optional[str] = None,
    role: Optional[UserRole] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_manager),
    page: PaginationParams = Depends(pagination),
):
    query = db.query(User)
    if department_id:
        query = query.filter(User.department_id == department_id)
    if role:
        query = query.filter(User.role == role)
    total = query.count()
    users = query.order_by(User.name).offset(page.offset).limit(page.limit).all()
    return paginated([UserOut.model_validate(u) for u in users], total, page.limit, page.offset)


@router.get("/me", response_model=ApiResponse[UserOut])
def get_me(current_user: User = Depends(get_current_user)):
    return ok(UserOut.model_validate(current_user))


@router.patch("/me", response_model=ApiResponse[UserOut])
def update_my_profile(
    payload: UserProfileUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Any user can update their own profile fields."""
    # Org fields (department, designation etc.) only admin can change
    org_only_fields = {'department_id', 'designation_id', 'reporting_manager_id',
                       'reporting_head_id', 'hod_id', 'is_hod', 'is_director'}
    update_data = payload.model_dump(exclude_none=True)

    if current_user.role != UserRole.admin:
        for field in org_only_fields:
            update_data.pop(field, None)

    for field, value in update_data.items():
        setattr(current_user, field, value)
    db.commit()
    db.refresh(current_user)
    return ok(UserOut.model_validate(current_user), "Profile updated successfully")


@router.get("/{user_id}", response_model=ApiResponse[UserOut])
def get_user(
    user_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException("User")
    return ok(UserOut.model_validate(user))


@router.post("", response_model=ApiResponse[UserOut], status_code=status.HTTP_201_CREATED)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if db.query(User).filter(User.email == payload.email).first():
        raise ConflictException("Email already registered")
    user = User(
        name=payload.name,
        email=payload.email,
        password_hash=hash_password(payload.password),
        role=payload.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return ok(UserOut.model_validate(user), "User created successfully")


@router.patch("/{user_id}/profile", response_model=ApiResponse[UserOut])
def update_user_profile(
    user_id: str,
    payload: UserProfileUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Admin can update any user's full profile including org fields."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException("User")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(user, field, value)
    db.commit()
    db.refresh(user)
    return ok(UserOut.model_validate(user), "User profile updated")


@router.patch("/{user_id}/role", response_model=ApiResponse[UserOut])
def update_user_role(
    user_id: str,
    payload: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException("User")
    if user.id == current_user.id:
        raise ForbiddenException("Cannot change your own role")
    if payload.role:
        user.role = payload.role
    db.commit()
    db.refresh(user)
    return ok(UserOut.model_validate(user), f"Role updated to {payload.role}")


@router.patch("/{user_id}/status", response_model=ApiResponse[UserOut])
def update_user_status(
    user_id: str,
    payload: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException("User")
    if user.id == current_user.id:
        raise ForbiddenException("Cannot deactivate yourself")
    if payload.is_active is not None:
        user.is_active = payload.is_active
    db.commit()
    db.refresh(user)
    action = "activated" if user.is_active else "deactivated"
    return ok(UserOut.model_validate(user), f"User {action} successfully")


@router.delete("/{user_id}", response_model=ApiResponse[None])
def delete_user(
    user_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException("User")
    if user.id == current_user.id:
        raise ForbiddenException("Cannot delete yourself")
    db.delete(user)
    db.commit()
    return ok(None, "User deleted successfully")

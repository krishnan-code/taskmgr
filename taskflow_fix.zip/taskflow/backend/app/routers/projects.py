from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

from app.database import get_db
from app.models.project import Project
from app.models.user import User
from app.schemas.response import ApiResponse, PaginatedResponse, ok, paginated
from app.utils.dependencies import get_current_user
from app.utils.exceptions import NotFoundException
from app.utils.pagination import pagination, PaginationParams

router = APIRouter(prefix="/projects", tags=["Projects"])


class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = None


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class ProjectOut(BaseModel):
    id: str
    name: str
    description: Optional[str]
    owner_id: Optional[str]
    created_at: datetime
    task_count: int = 0
    model_config = {"from_attributes": True}


@router.get("", response_model=PaginatedResponse[ProjectOut])
def list_projects(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    page: PaginationParams = Depends(pagination),
):
    query = db.query(Project)
    total = query.count()
    projects = query.offset(page.offset).limit(page.limit).all()
    result = []
    for p in projects:
        out = ProjectOut.model_validate(p)
        out.task_count = len(p.tasks)
        result.append(out)
    return paginated(result, total, page.limit, page.offset)


@router.post("", response_model=ApiResponse[ProjectOut], status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    project = Project(name=payload.name, description=payload.description, owner_id=current_user.id)
    db.add(project); db.commit(); db.refresh(project)
    out = ProjectOut.model_validate(project); out.task_count = 0
    return ok(out, "Project created successfully")


@router.get("/{project_id}", response_model=ApiResponse[ProjectOut])
def get_project(project_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project: raise NotFoundException("Project")
    out = ProjectOut.model_validate(project); out.task_count = len(project.tasks)
    return ok(out)


@router.put("/{project_id}", response_model=ApiResponse[ProjectOut])
def update_project(project_id: str, payload: ProjectUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project: raise NotFoundException("Project")
    if payload.name is not None: project.name = payload.name
    if payload.description is not None: project.description = payload.description
    db.commit(); db.refresh(project)
    out = ProjectOut.model_validate(project); out.task_count = len(project.tasks)
    return ok(out, "Project updated successfully")


@router.delete("/{project_id}", response_model=ApiResponse[None])
def delete_project(project_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project: raise NotFoundException("Project")
    db.delete(project); db.commit()
    return ok(None, "Project deleted successfully")

from fastapi import APIRouter, Depends, HTTPException, Header, Request, status
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
import hmac, hashlib, json

import httpx

from app.database import get_db
from app.models.task import Task
from app.models.ticket import Ticket, TicketStatus
from app.models.user import User
from app.utils.dependencies import get_current_user
from app.config import settings

router = APIRouter(prefix="/tickets", tags=["Tickets"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class TicketCreate(BaseModel):
    task_id: str
    title: Optional[str] = None          # defaults to task title
    priority: Optional[str] = "medium"
    extra_data: Optional[dict] = None    # custom fields for your ticket system


class TicketOut(BaseModel):
    id: str
    task_id: str
    external_ticket_id: str
    external_url: Optional[str]
    title: Optional[str]
    status: TicketStatus
    priority: Optional[str]
    reporter: Optional[str]
    synced_at: Optional[datetime]
    created_at: datetime

    model_config = {"from_attributes": True}


class WebhookPayload(BaseModel):
    ticket_id: str
    status: Optional[str] = None
    priority: Optional[str] = None
    title: Optional[str] = None
    extra_data: Optional[dict] = None


# ── Helpers ───────────────────────────────────────────────────────────────────

TICKET_STATUS_MAP = {
    "open":        TicketStatus.open,
    "in_progress": TicketStatus.in_progress,
    "resolved":    TicketStatus.resolved,
    "closed":      TicketStatus.closed,
}


async def _call_ticket_api(method: str, path: str, payload: dict = None) -> dict:
    """Generic HTTP client to talk to your custom ticket system."""
    if not settings.ticket_system_base_url:
        raise HTTPException(status_code=503, detail="Ticket system not configured")

    url = f"{settings.ticket_system_base_url.rstrip('/')}/{path.lstrip('/')}"
    headers = {"Authorization": f"Bearer {settings.ticket_system_api_key}", "Content-Type": "application/json"}

    async with httpx.AsyncClient(timeout=10) as client:
        try:
            resp = await getattr(client, method)(url, headers=headers, json=payload)
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=502, detail=f"Ticket system error: {e.response.text}")
        except httpx.RequestError as e:
            raise HTTPException(status_code=503, detail=f"Ticket system unreachable: {str(e)}")


def _verify_webhook_signature(body: bytes, signature: str) -> bool:
    """HMAC-SHA256 webhook verification."""
    expected = hmac.new(
        settings.ticket_webhook_secret.encode(),
        body,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(f"sha256={expected}", signature)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("", response_model=List[TicketOut])
def list_tickets(
    task_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Ticket)
    if task_id:
        query = query.filter(Ticket.task_id == task_id)
    return query.order_by(Ticket.created_at.desc()).all()


@router.post("", response_model=TicketOut, status_code=status.HTTP_201_CREATED)
async def create_ticket(
    payload: TicketCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = db.query(Task).filter(Task.id == payload.task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    title = payload.title or task.title

    # Call your ticket system API to create the ticket
    ticket_data = await _call_ticket_api("post", "/tickets", {
        "title": title,
        "priority": payload.priority,
        "description": task.description or "",
        "metadata": {"taskflow_task_id": task.id, **(payload.extra_data or {})},
    })

    ticket = Ticket(
        task_id=task.id,
        external_ticket_id=str(ticket_data.get("id", "")),
        external_url=ticket_data.get("url"),
        title=title,
        status=TicketStatus.open,
        priority=payload.priority,
        reporter=current_user.email,
        extra_data=json.dumps(payload.extra_data) if payload.extra_data else None,
        synced_at=datetime.now(timezone.utc),
    )
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    return ticket


@router.get("/{ticket_id}/sync", response_model=TicketOut)
async def sync_ticket(
    ticket_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Pull latest status from the ticket system and update locally."""
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")

    remote = await _call_ticket_api("get", f"/tickets/{ticket.external_ticket_id}")

    ticket.status = TICKET_STATUS_MAP.get(remote.get("status", "open"), TicketStatus.open)
    ticket.title = remote.get("title", ticket.title)
    ticket.priority = remote.get("priority", ticket.priority)
    ticket.synced_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(ticket)
    return ticket


@router.post("/webhook", status_code=status.HTTP_200_OK)
async def receive_webhook(
    request: Request,
    db: Session = Depends(get_db),
    x_signature: Optional[str] = Header(None, alias="X-Signature"),
):
    """
    Webhook endpoint — your ticket system calls this when a ticket changes.
    Expects header: X-Signature: sha256=<hmac>
    """
    body = await request.body()

    # Verify HMAC signature if secret is configured
    if settings.ticket_webhook_secret and x_signature:
        if not _verify_webhook_signature(body, x_signature):
            raise HTTPException(status_code=401, detail="Invalid webhook signature")

    try:
        data = WebhookPayload(**json.loads(body))
    except Exception:
        raise HTTPException(status_code=422, detail="Invalid webhook payload")

    ticket = db.query(Ticket).filter(Ticket.external_ticket_id == data.ticket_id).first()
    if not ticket:
        return {"detail": "Ticket not tracked in TaskFlow, ignoring"}

    if data.status:
        ticket.status = TICKET_STATUS_MAP.get(data.status, ticket.status)
    if data.title:
        ticket.title = data.title
    if data.priority:
        ticket.priority = data.priority

    ticket.synced_at = datetime.now(timezone.utc)
    db.commit()

    return {"detail": "Webhook processed", "ticket_id": ticket.id}


@router.delete("/{ticket_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_ticket(
    ticket_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    db.delete(ticket)
    db.commit()

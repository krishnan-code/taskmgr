from app.routers.auth import router as auth_router
from app.routers.projects import router as projects_router
from app.routers.tasks import router as tasks_router
from app.routers.time_logs import router as time_logs_router
from app.routers.tickets import router as tickets_router
from app.routers.comments import router as comments_router

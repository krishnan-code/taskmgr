-- MySQL initialization script
-- This runs once when the container is first created

CREATE DATABASE IF NOT EXISTS taskflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON taskflow.* TO 'taskflow_user'@'%';
FLUSH PRIVILEGES;

"""Initial schema — all tables

Revision ID: 001
Revises: 
Create Date: 2026-03-17

This migration creates ALL tables from scratch.
Safe to run on an empty database.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql

revision = '001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── verticals ──────────────────────────────────────────────────────────
    op.create_table('verticals',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('is_ticketing_enabled', sa.Boolean(), nullable=False, server_default='0'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name'),
    )

    # ── branches ───────────────────────────────────────────────────────────
    op.create_table('branches',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('branch_code', sa.String(20), nullable=False),
        sa.Column('name', sa.String(150), nullable=False),
        sa.Column('address', sa.Text(), nullable=True),
        sa.Column('city', sa.String(100), nullable=True),
        sa.Column('state', sa.String(100), nullable=True),
        sa.Column('country', sa.String(100), nullable=True, server_default='India'),
        sa.Column('pincode', sa.String(20), nullable=True),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('timezone', sa.String(100), nullable=False, server_default='Asia/Kolkata'),
        sa.Column('is_headquarters', sa.Boolean(), nullable=False, server_default='0'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('branch_code'),
    )
    op.create_index('ix_branches_branch_code', 'branches', ['branch_code'])

    # ── departments ────────────────────────────────────────────────────────
    op.create_table('departments',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('name', sa.String(150), nullable=False),
        sa.Column('vertical_id', sa.String(36), nullable=False),
        sa.Column('parent_id', sa.String(36), nullable=True),
        sa.Column('level', sa.Enum('department','sub_department','team'), nullable=False, server_default='department'),
        sa.Column('head_user_id', sa.String(36), nullable=True),
        sa.Column('is_ticketing_enabled', sa.Boolean(), nullable=False, server_default='0'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('sort_order', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['vertical_id'], ['verticals.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_departments_vertical_id', 'departments', ['vertical_id'])

    # ── designations ───────────────────────────────────────────────────────
    op.create_table('designations',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('title', sa.String(150), nullable=False),
        sa.Column('department_id', sa.String(36), nullable=True),
        sa.Column('level_rank', sa.Integer(), nullable=False),
        sa.Column('is_hod_level', sa.Boolean(), nullable=True, server_default='0'),
        sa.Column('is_director_level', sa.Boolean(), nullable=True, server_default='0'),
        sa.Column('is_active', sa.Boolean(), nullable=True, server_default='1'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── users ──────────────────────────────────────────────────────────────
    op.create_table('users',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('password_hash', sa.String(255), nullable=True),
        sa.Column('role', sa.Enum('admin','director','hod','manager','member'), nullable=False, server_default='member'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='1'),
        # Org fields
        sa.Column('branch_id', sa.String(36), nullable=True),
        sa.Column('employee_id', sa.String(50), nullable=True),
        sa.Column('job_title', sa.String(150), nullable=True),
        sa.Column('department_id', sa.String(36), nullable=True),
        sa.Column('designation_id', sa.String(36), nullable=True),
        sa.Column('reporting_manager_id', sa.String(36), nullable=True),
        sa.Column('reporting_head_id', sa.String(36), nullable=True),
        sa.Column('hod_id', sa.String(36), nullable=True),
        sa.Column('is_hod', sa.Boolean(), nullable=True, server_default='0'),
        sa.Column('is_director', sa.Boolean(), nullable=True, server_default='0'),
        # Personal fields
        sa.Column('phone_number', sa.String(20), nullable=True),
        sa.Column('mobile_number', sa.String(20), nullable=True),
        sa.Column('date_of_birth', sa.Date(), nullable=True),
        sa.Column('gender', sa.Enum('male','female','other','prefer_not_to_say'), nullable=True),
        sa.Column('address', sa.Text(), nullable=True),
        sa.Column('emergency_contact_name', sa.String(100), nullable=True),
        sa.Column('emergency_contact_phone', sa.String(20), nullable=True),
        sa.Column('emergency_contact_relation', sa.String(50), nullable=True),
        sa.Column('profile_photo_url', sa.String(500), nullable=True),
        sa.Column('blood_group', sa.String(10), nullable=True),
        # Employment fields
        sa.Column('date_of_joining', sa.Date(), nullable=True),
        sa.Column('employment_type', sa.Enum('full_time','contract','intern'), nullable=True),
        sa.Column('work_location', sa.Enum('office','remote','hybrid'), nullable=True),
        sa.Column('shift_timing', sa.String(100), nullable=True),
        sa.Column('probation_end_date', sa.Date(), nullable=True),
        sa.Column('last_working_date', sa.Date(), nullable=True),
        # Professional fields
        sa.Column('skills', sa.JSON(), nullable=True),
        sa.Column('certifications', sa.JSON(), nullable=True),
        sa.Column('languages', sa.JSON(), nullable=True),
        sa.Column('bio', sa.Text(), nullable=True),
        # LDAP fields
        sa.Column('is_ldap_synced', sa.Boolean(), nullable=True, server_default='0'),
        sa.Column('ldap_dn', sa.String(500), nullable=True),
        sa.Column('ldap_username', sa.String(100), nullable=True),
        sa.Column('last_ldap_sync', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['branch_id'], ['branches.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['department_id'], ['departments.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['designation_id'], ['designations.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('email'),
        sa.UniqueConstraint('employee_id'),
    )
    op.create_index('ix_users_email', 'users', ['email'])
    op.create_index('ix_users_department_id', 'users', ['department_id'])

    # ── module_permissions ─────────────────────────────────────────────────
    op.create_table('module_permissions',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('department_id', sa.String(36), nullable=False),
        sa.Column('module', sa.Enum('tasks','kanban','gantt','calendar','tickets'), nullable=False),
        sa.Column('is_enabled', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('updated_by', sa.String(36), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['department_id'], ['departments.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_module_permissions_department_id', 'module_permissions', ['department_id'])

    # ── sla_policies ───────────────────────────────────────────────────────
    op.create_table('sla_policies',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('priority', sa.Enum('P1','P2','P3','P4'), nullable=False),
        sa.Column('response_minutes', sa.Integer(), nullable=False),
        sa.Column('resolution_minutes', sa.Integer(), nullable=False),
        sa.Column('pause_on_holidays', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('working_hours_start', sa.String(10), nullable=True, server_default='09:00'),
        sa.Column('working_hours_end', sa.String(10), nullable=True, server_default='18:00'),
        sa.Column('is_active', sa.Boolean(), nullable=True, server_default='1'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('priority'),
    )

    # ── groups ─────────────────────────────────────────────────────────────
    op.create_table('groups',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('name', sa.String(150), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('created_by', sa.String(36), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True, server_default='1'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['created_by'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── group_members ──────────────────────────────────────────────────────
    op.create_table('group_members',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('group_id', sa.String(36), nullable=False),
        sa.Column('user_id', sa.String(36), nullable=False),
        sa.Column('added_by', sa.String(36), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['group_id'], ['groups.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── notifications ──────────────────────────────────────────────────────
    op.create_table('notifications',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('user_id', sa.String(36), nullable=False),
        sa.Column('type', sa.Enum('task_assigned','task_accepted','task_rejected','task_due_soon',
                                   'task_overdue','ticket_assigned','ticket_comment',
                                   'ticket_escalated','sla_warning','sla_breached',
                                   'group_added','general'), nullable=False),
        sa.Column('title', sa.String(255), nullable=False),
        sa.Column('body', sa.Text(), nullable=True),
        sa.Column('reference_type', sa.String(50), nullable=True),
        sa.Column('reference_id', sa.String(36), nullable=True),
        sa.Column('is_read', sa.Boolean(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_notifications_user_id', 'notifications', ['user_id'])

    # ── holidays ───────────────────────────────────────────────────────────
    op.create_table('holidays',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('name', sa.String(150), nullable=False),
        sa.Column('date', sa.Date(), nullable=False),
        sa.Column('holiday_type', sa.Enum('global','local'), nullable=False, server_default='global'),
        sa.Column('branch_id', sa.String(36), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('is_recurring', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('created_by', sa.String(36), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['branch_id'], ['branches.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['created_by'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_holidays_date', 'holidays', ['date'])
    op.create_index('ix_holidays_branch_id', 'holidays', ['branch_id'])

    # ── projects ───────────────────────────────────────────────────────────
    op.create_table('projects',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('owner_id', sa.String(36), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['owner_id'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── tasks ──────────────────────────────────────────────────────────────
    op.create_table('tasks',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('title', sa.String(300), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('status', sa.Enum('not_started','in_progress','blocked','done'), nullable=False, server_default='not_started'),
        sa.Column('priority', sa.Enum('low','medium','high'), nullable=False, server_default='medium'),
        sa.Column('start_date', sa.Date(), nullable=True),
        sa.Column('due_date', sa.Date(), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('project_id', sa.String(36), nullable=True),
        sa.Column('assignee_id', sa.String(36), nullable=True),
        sa.Column('created_by', sa.String(36), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['assignee_id'], ['users.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['created_by'], ['users.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['project_id'], ['projects.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_tasks_status', 'tasks', ['status'])
    op.create_index('ix_tasks_project_id', 'tasks', ['project_id'])
    op.create_index('ix_tasks_assignee_id', 'tasks', ['assignee_id'])

    # ── subtasks ───────────────────────────────────────────────────────────
    op.create_table('subtasks',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('title', sa.String(300), nullable=False),
        sa.Column('done', sa.Boolean(), nullable=False, server_default='0'),
        sa.Column('task_id', sa.String(36), nullable=False),
        sa.Column('assignee_id', sa.String(36), nullable=True),
        sa.Column('due_date', sa.Date(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['assignee_id'], ['users.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['task_id'], ['tasks.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_subtasks_task_id', 'subtasks', ['task_id'])

    # ── time_logs ──────────────────────────────────────────────────────────
    op.create_table('time_logs',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('task_id', sa.String(36), nullable=False),
        sa.Column('subtask_id', sa.String(36), nullable=True),
        sa.Column('user_id', sa.String(36), nullable=True),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('ended_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('duration_seconds', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('note', sa.String(500), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['subtask_id'], ['subtasks.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['task_id'], ['tasks.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_time_logs_task_id', 'time_logs', ['task_id'])

    # ── tickets ────────────────────────────────────────────────────────────
    op.create_table('tickets',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('task_id', sa.String(36), nullable=True),
        sa.Column('external_ticket_id', sa.String(200), nullable=False),
        sa.Column('external_url', sa.String(500), nullable=True),
        sa.Column('title', sa.String(300), nullable=True),
        sa.Column('status', sa.Enum('open','in_progress','resolved','closed'), nullable=False, server_default='open'),
        sa.Column('priority', sa.String(50), nullable=True),
        sa.Column('reporter', sa.String(200), nullable=True),
        sa.Column('extra_data', sa.Text(), nullable=True),
        sa.Column('synced_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['task_id'], ['tasks.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_tickets_task_id', 'tickets', ['task_id'])

    # ── comments ───────────────────────────────────────────────────────────
    op.create_table('comments',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('task_id', sa.String(36), nullable=False),
        sa.Column('user_id', sa.String(36), nullable=True),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['task_id'], ['tasks.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_comments_task_id', 'comments', ['task_id'])


def downgrade() -> None:
    # Drop in reverse order of creation (respecting FK dependencies)
    op.drop_table('comments')
    op.drop_table('tickets')
    op.drop_table('time_logs')
    op.drop_table('subtasks')
    op.drop_table('tasks')
    op.drop_table('projects')
    op.drop_table('holidays')
    op.drop_table('notifications')
    op.drop_table('group_members')
    op.drop_table('groups')
    op.drop_table('sla_policies')
    op.drop_table('module_permissions')
    op.drop_table('users')
    op.drop_table('designations')
    op.drop_table('departments')
    op.drop_table('branches')
    op.drop_table('verticals')

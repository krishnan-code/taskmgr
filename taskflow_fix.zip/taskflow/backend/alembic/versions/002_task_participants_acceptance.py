"""Add task participants, acceptance log, and new task fields

Revision ID: 002
Revises: 001
Create Date: 2026-03-18
"""
from alembic import op
import sqlalchemy as sa

revision = '002'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add new columns to tasks
    op.add_column('tasks', sa.Column('lead_user_id', sa.String(36), sa.ForeignKey('users.id', ondelete='SET NULL'), nullable=True))
    op.add_column('tasks', sa.Column('department_id', sa.String(36), sa.ForeignKey('departments.id', ondelete='SET NULL'), nullable=True))
    op.add_column('tasks', sa.Column('vertical_id', sa.String(36), sa.ForeignKey('verticals.id', ondelete='SET NULL'), nullable=True))
    op.add_column('tasks', sa.Column('is_all_departments', sa.Boolean(), nullable=True, server_default='0'))
    op.add_column('tasks', sa.Column('is_cross_department', sa.Boolean(), nullable=True, server_default='0'))
    op.add_column('tasks', sa.Column('group_id', sa.String(36), sa.ForeignKey('groups.id', ondelete='SET NULL'), nullable=True))
    op.add_column('tasks', sa.Column('acceptance_status', sa.Enum('not_required','pending','accepted','rejected'), nullable=True, server_default='not_required'))
    op.add_column('tasks', sa.Column('accepted_by', sa.String(36), sa.ForeignKey('users.id', ondelete='SET NULL'), nullable=True))
    op.add_column('tasks', sa.Column('accepted_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('tasks', sa.Column('rejection_reason', sa.Text(), nullable=True))
    op.add_column('tasks', sa.Column('created_by', sa.String(36), sa.ForeignKey('users.id', ondelete='SET NULL'), nullable=True))

    # Update status enum to include new statuses
    op.alter_column('tasks', 'status',
        type_=sa.Enum('not_started','pending_acceptance','accepted','rejected','in_progress','blocked','on_hold','done'),
        existing_nullable=False, server_default='not_started')

    # Update priority enum
    op.alter_column('tasks', 'priority',
        type_=sa.Enum('low','medium','high','critical'),
        existing_nullable=False, server_default='medium')

    # task_participants table
    op.create_table('task_participants',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('task_id', sa.String(36), nullable=False),
        sa.Column('user_id', sa.String(36), nullable=False),
        sa.Column('role', sa.Enum('lead','participant','supporter'), nullable=False, server_default='participant'),
        sa.Column('source_department_id', sa.String(36), nullable=True),
        sa.Column('added_by', sa.String(36), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['task_id'], ['tasks.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['source_department_id'], ['departments.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['added_by'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_task_participants_task_id', 'task_participants', ['task_id'])
    op.create_index('ix_task_participants_user_id', 'task_participants', ['user_id'])

    # task_acceptance_logs table
    op.create_table('task_acceptance_logs',
        sa.Column('id', sa.String(36), nullable=False),
        sa.Column('task_id', sa.String(36), nullable=False),
        sa.Column('from_user_id', sa.String(36), nullable=True),
        sa.Column('to_user_id', sa.String(36), nullable=True),
        sa.Column('action', sa.String(50), nullable=False),
        sa.Column('reason', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['task_id'], ['tasks.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['from_user_id'], ['users.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['to_user_id'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_task_acceptance_logs_task_id', 'task_acceptance_logs', ['task_id'])


def downgrade() -> None:
    op.drop_table('task_acceptance_logs')
    op.drop_table('task_participants')
    op.drop_column('tasks', 'created_by')
    op.drop_column('tasks', 'rejection_reason')
    op.drop_column('tasks', 'accepted_at')
    op.drop_column('tasks', 'accepted_by')
    op.drop_column('tasks', 'acceptance_status')
    op.drop_column('tasks', 'group_id')
    op.drop_column('tasks', 'is_cross_department')
    op.drop_column('tasks', 'is_all_departments')
    op.drop_column('tasks', 'vertical_id')
    op.drop_column('tasks', 'department_id')
    op.drop_column('tasks', 'lead_user_id')

# TaskFlow — Full Stack Task & Time Tracker

Built with **Python + FastAPI**, **MySQL**, and **React + TypeScript**.

---

## Quick Start

### 1. Clone & configure
```bash
git clone <repo>
cd taskflow
cp .env.example .env   # edit values as needed
```

### 2. Start all services
```bash
docker-compose up --build
```

### 3. Access
| Service       | URL                          |
|---------------|------------------------------|
| API Docs      | http://localhost:8000/docs   |
| ReDoc         | http://localhost:8000/redoc  |
| Health Check  | http://localhost:8000/health |

---

## Project Structure

```
taskflow/
├── backend/
│   ├── app/
│   │   ├── main.py          # FastAPI app entry point
│   │   ├── config.py        # Settings (pydantic-settings)
│   │   ├── database.py      # SQLAlchemy engine + session
│   │   ├── models/          # SQLAlchemy ORM models
│   │   ├── routers/         # FastAPI route handlers
│   │   ├── schemas/         # Pydantic request/response schemas
│   │   └── utils/           # JWT, password hashing, dependencies
│   ├── alembic/             # Database migrations
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                # (Phase 3 — React + TypeScript)
├── docker-compose.yml
└── .env
```

---

## API Endpoints

### Auth
| Method | Endpoint               | Description         |
|--------|------------------------|---------------------|
| POST   | /api/v1/auth/register  | Register new user   |
| POST   | /api/v1/auth/login     | Login, get JWT      |
| POST   | /api/v1/auth/refresh   | Refresh access token|
| GET    | /api/v1/auth/me        | Get current user    |

### Projects
| Method | Endpoint                    | Description      |
|--------|-----------------------------|------------------|
| GET    | /api/v1/projects            | List projects    |
| POST   | /api/v1/projects            | Create project   |
| GET    | /api/v1/projects/{id}       | Get project      |
| PUT    | /api/v1/projects/{id}       | Update project   |
| DELETE | /api/v1/projects/{id}       | Delete project   |

### Tasks
| Method | Endpoint                              | Description         |
|--------|---------------------------------------|---------------------|
| GET    | /api/v1/tasks                         | List tasks (filterable) |
| POST   | /api/v1/tasks                         | Create task         |
| GET    | /api/v1/tasks/{id}                    | Get task detail     |
| PUT    | /api/v1/tasks/{id}                    | Update task         |
| DELETE | /api/v1/tasks/{id}                    | Delete task         |
| GET    | /api/v1/tasks/{id}/subtasks           | List subtasks       |
| POST   | /api/v1/tasks/{id}/subtasks           | Add subtask         |
| PUT    | /api/v1/tasks/{id}/subtasks/{sid}     | Update subtask      |
| DELETE | /api/v1/tasks/{id}/subtasks/{sid}     | Delete subtask      |

### Time Tracking
| Method | Endpoint                          | Description         |
|--------|-----------------------------------|---------------------|
| POST   | /api/v1/tasks/{id}/timer/start    | Start timer         |
| POST   | /api/v1/tasks/{id}/timer/stop     | Stop timer          |
| GET    | /api/v1/tasks/{id}/time-logs      | Get all time logs   |
| GET    | /api/v1/tasks/{id}/time-summary   | Time summary        |

### Tickets (Custom System Integration)
| Method | Endpoint                      | Description              |
|--------|-------------------------------|--------------------------|
| GET    | /api/v1/tickets               | List tickets             |
| POST   | /api/v1/tickets               | Create & link ticket     |
| GET    | /api/v1/tickets/{id}/sync     | Pull latest from system  |
| POST   | /api/v1/tickets/webhook       | Receive webhook updates  |
| DELETE | /api/v1/tickets/{id}          | Unlink ticket            |

### Comments
| Method | Endpoint                              | Description      |
|--------|---------------------------------------|------------------|
| GET    | /api/v1/tasks/{id}/comments           | List comments    |
| POST   | /api/v1/tasks/{id}/comments           | Add comment      |
| DELETE | /api/v1/tasks/{id}/comments/{cid}     | Delete comment   |

---

## Running Migrations (Production)

```bash
# Inside backend container
docker-compose exec backend alembic revision --autogenerate -m "initial"
docker-compose exec backend alembic upgrade head
```

---

## Environment Variables

| Variable                   | Description                        |
|----------------------------|------------------------------------|
| MYSQL_DATABASE             | Database name                      |
| MYSQL_USER / PASSWORD      | DB credentials                     |
| SECRET_KEY                 | JWT signing secret (change this!)  |
| ACCESS_TOKEN_EXPIRE_MINUTES| JWT access token TTL               |
| TICKET_SYSTEM_BASE_URL     | Your ticket system API URL         |
| TICKET_SYSTEM_API_KEY      | Your ticket system API key         |
| TICKET_WEBHOOK_SECRET      | HMAC secret for webhook validation |

---

## Phase Roadmap

- [x] **Phase 1** — Backend scaffold (FastAPI + MySQL + Auth + All APIs)
- [ ] **Phase 2** — API hardening, pagination, tests
- [ ] **Phase 3** — React + TypeScript frontend
- [ ] **Phase 4** — Ticketing system deep integration
- [ ] **Phase 5** — WebSockets, Notion sync, reporting

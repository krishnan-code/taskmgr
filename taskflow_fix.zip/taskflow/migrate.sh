#!/bin/bash
# ── TaskFlow Migration Helper ──────────────────────────────────────────────
# Usage:
#   ./migrate.sh new "add phone field to users"   → generate new migration
#   ./migrate.sh up                               → apply all pending migrations
#   ./migrate.sh down                             → rollback one migration
#   ./migrate.sh status                           → show current migration state
#   ./migrate.sh history                          → show migration history

CONTAINER="taskflow_backend"

case "$1" in
  new)
    if [ -z "$2" ]; then
      echo "❌ Usage: ./migrate.sh new \"describe your change\""
      exit 1
    fi
    echo "🔄 Generating migration: $2"
    docker exec $CONTAINER alembic revision --autogenerate -m "$2"
    echo "✅ Migration file created in backend/alembic/versions/"
    ;;
  up)
    echo "🔄 Applying all pending migrations..."
    docker exec $CONTAINER alembic upgrade head
    echo "✅ All migrations applied"
    ;;
  down)
    echo "⏪ Rolling back one migration..."
    docker exec $CONTAINER alembic downgrade -1
    echo "✅ Rolled back"
    ;;
  status)
    echo "📋 Current migration status:"
    docker exec $CONTAINER alembic current
    ;;
  history)
    echo "📜 Migration history:"
    docker exec $CONTAINER alembic history --verbose
    ;;
  *)
    echo "Usage: ./migrate.sh [new|up|down|status|history]"
    echo "  new \"message\"  - Generate new migration from model changes"
    echo "  up             - Apply all pending migrations"
    echo "  down           - Rollback last migration"
    echo "  status         - Show current migration version"
    echo "  history        - Show all migrations"
    ;;
esac
